<?php

namespace Stevebauman\Location\Exceptions;

class DriverDoesNotExistException extends LocationException
{
    //
}
