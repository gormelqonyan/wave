<!doctype html>
<html class="no-js">
<head>
    <meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<title>JavaScript դասընթացներ | Wave-it.ru</title>
	<meta content="վեբ ծրագրավորման դասընթացներ, web ծրագրավորման դասընթացներ, վեբ կայքերի պատրաստման դասընթացներ, web կայքերի պատրաստման դասընթացներ" name="keywords">
	<meta content="JavaScript դասընթացներ | Wave-it.ru" name="title">
	<meta content="Wave-IT ընկերությունը կազմակերպում է javascript-ի խորացված դասընթացներ: Դասավանդում են որակավորված և  փորձառու մասնագետներ ☎ 374(95)789-786" name="description">


	<link rel="shortcut icon" href="/lessons/images/logo2.png" type="image/x-icon">
    <link rel="stylesheet" href="/lessons/css/assets/bootstrap.min.css">
    <link rel="stylesheet" href="/lessons/css/assets/font-awesome.min.css">
	<link href="https://fonts.googleapis.com/css?family=Montserrat:600,700%7COpen+Sans:400,600" rel="stylesheet">     
	<link href="/lessons/css/assets/magnific-popup.css" rel="stylesheet"> 
	<link href="/lessons/css/assets/slick.css" rel="stylesheet"> 	
	<link href="/lessons/css/assets/slick-theme.css" rel="stylesheet"> 	   
	<link href="/lessons/css/assets/owl.carousel.css" rel="stylesheet">
	<link href="/lessons/css/assets/owl.theme.css" rel="stylesheet">
	<link rel="stylesheet" href="/lessons/css/assets/meanmenu.css">   
	<link rel="stylesheet" href="/lessons/css/style.css">
	<link rel="stylesheet" href="/lessons/css/responsive.css">	
	<script type="text/javascript" src="/lessons/js/jquery-1.10.2.min.js"></script>
	<script type="text/javascript" src="/lessons/js/alphabet.js"></script>
	<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-134131256-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-134131256-1');
</script>

</head>
<body class="courses">
<div id="preloader">
	<div id="status">&nbsp;</div>
</div>
<header id="header">
	<div class="header-top">
		<div class="container">
			<div class="row">
				<div class="col-sm-6 col-xs-12 header-top-left">
					<ul class="list-unstyled">
						<li><i class="fa fa-phone top-icon"></i> +374 77789786</li>
						<li><i class="fa fa-phone top-icon"></i> +374 12789786</li>
						<li><i class="fa fa-envelope top-icon"></i>info@wave-it.ru</li>
					</ul>
				</div>
				<div class="col-sm-6 col-xs-12 header-top-right">
					<!-- <ul class="list-unstyled"> -->
						<!-- <li><a href="register.html"><i class="fa fa-user-plus top-icon"></i> Sing up</a></li> -->
						<!-- <li><a href="index.html"><i class="fa fa-lock top-icon"></i>Login</a></li> -->
					<!-- </ul> -->
				</div>
			</div>
		</div>
	</div>
	<div class="header-body">
		<nav class="navbar edu-navbar">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a href="/" class="navbar-brand  data-scroll"><img style="width: 250px;" src="/lessons/images/logo.png" alt=""></a>
				</div>
				<div class="collapse navbar-collapse edu-nav main-menu" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav pull-right">
						<li>
							<a data-scroll="" href="/courses">Դասընթացներ</a>
                        </li>
						
						
					</ul>
				</div>
			</div>
		</nav>
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="intro-text ">
						<h1>Վեբ ծրագրավորման դասընթացներ</h1>
						
					</div>
				</div>
			</div>
		</div>
	</div>
</header>
@yield('content')
<footer>
	<div class="footer-bottom">
		<div class="container">
			<div class="footer-bottom-inner">
				<div class="row">
					<div class="col-md-6 col-sm-12 footer-no-padding">
						<p>&copy; Copyright <?php echo date('Y');?> WAVE IT | All rights reserved</p>
					</div>
					<div class="col-md-6 col-sm-12 footer-no-padding">
						<ul class="list-unstyled footer-menu text-right">
							<li>Follow us:</li>
							<li><a href="#"><i class="fa fa-facebook facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-instagram instagram"></i></a></li>
							<li><a href=""><i class="fa fa-google-plus google"></i></a></li>
							<li><a href=""><i class="fa fa-skype skype"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</footer>

	<script src="/lessons/js/vendor/jquery-1.12.4.min.js"></script>
	<script src="/lessons/js/assets/bootstrap.min.js"></script>
	<script src="/lessons/js/assets/jquery.sticky.js"></script>
    <script src="/lessons/js/assets/jquery.magnific-popup.min.js"></script>
    <script src="/lessons/js/assets/jquery.counterup.min.js"></script>
    <script src="/lessons/js/assets/waypoints.min.js"></script>
    <script src="/lessons/js/assets/owl.carousel.min.js"></script>
    <script src="/lessons/js/assets/slick.min.js"></script>
	<script src="/lessons/js/assets/jquery.meanmenu.min.js"></script>

	<script src="/lessons/js/custom.js"></script>
</body>
</html>