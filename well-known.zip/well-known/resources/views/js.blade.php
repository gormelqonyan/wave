
@extends('layouts.jbase')

@section('content')

<section class="courses-1">
	<div class="container">	
				<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="{{route('index')}}">@lang('global.Home')</a>
    </li>
    <li class="breadcrumb-item"><a href="{{route('web')}}">@lang('global.Courses')</a></li>
	 <li class="breadcrumb-item active">JavaScript դասընթացներ</li>
</ol>
<div class="panel-group" id="accordion">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson1">
		  <span>Դաս 1</span>
            <p>Ի՞նչ է JavaScript – ը</p>
            <p>Ի՞նչ է JavaScript – ը, փոփոխականներ, տվյալների տիպեր, ֆունկցիաներ</p>
        </h4>
      </div>
      <div id="lesson1" class="panel-collapse collapse in">
        <div class="panel-body">
	<h2 class="npatak">JavaScript դասընթացի նպատակը</h2>
		<p class="web4">Այս դասի ընթացքում կուսումնասիրենք՝</p>
					<p class="web4">1. ի՞նչ է JavaScript-ը,</p>
					<p class="web4">2. տվյալների տիպեր, փոփոխականներ, հաստատուններ,</p>
					<p class="web4">3. ֆունկցիաներ, լոկալ և գլոբալ փոփոխականներ,</p>
					<p class="web4">4. օբյեկտներ:</p>
		</div>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson2">
		  <span>Դաս 2</span>
             <p>JavaScript ներածություն</p>
            <p>Alert(), prompt(), confirm() ֆունկցիաներ, document.write() մեթոդ, օպերատորներ DOM ներածություն (ի՞նչ է DOM – ը, ինչպես ստեղծել էլեմենտներ)</p>
          
		  </a>
        </h4>
      </div>
      <div id="lesson2" class="panel-collapse collapse">
        <div class="panel-body">
	<h2 class="npatak">JavaScript դասընթացի նպատակը</h2>
					<p class="web4">Այս դասի ընթացքում կուսումնասիրենք՝</p>
					<p class="web4">1. alert(), prompt(), confirm() ֆունկցիաներ,</p>
					<p class="web4">2. օպերատորներ,</p>
					<p class="web4">3. if, else, switch օպերատորներ,</p>
					<p class="web4">4. DOM - ներածություն:</p>
	</div>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson3">
		  <span>Դաս 3</span>
            <p>JavaScript ներածություն</p>
            <p>Զանգվածներ , ցիկլեր , SetTimeOut, SetInterval ֆունկցիաներ, ռեկուրսիա</p>
		  </a>
        </h4>
      </div>
      <div id="lesson3" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">JavaScript դասընթացի նպատակը</h2>
					<p class="web4">Այս դասի ընթացքում կուսումնասիրենք՝</p>
					<p class="web4">Զանգվածներ</p>
					<p class="web4">Ցիկլեր</p>
					<p class="web4">SetTimeout, setInterval ֆունկցիաներ</p>
					<p class="web4">Ռեկուրսիա</p>
		</div>
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson4">
		  <span>Դաս 4</span>
            <p>DOM ներածություն</p>
		  </a>
        </h4>
      </div>
      <div id="lesson4" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">JavaScript դասընթացի նպատակը</h2>
		<p class="web4">Այս դասի ընթացքում կուսումնասիրենք՝</p>
					<p class="web4">DOM գաղափարը</p>
					<p class="web4">DOM ներածություն</p>
		</div>
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson5">
		  <span>Դաս 5</span>
             <p>Պրակտիկ դաս՝ հաշվիչի և tic tac toe խաղի պատրաստում</p>
		  </a>
        </h4>
      </div>
      <div id="lesson5" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">JavaScript դասընթացի նպատակը</h2>
					<p class="web4">Ամրապնդել DOM գիտելիքները</p>
					<p class="web4">Զարգացնել ալգորիթմիկ մտածելակերպը</p>
		</div>
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson6">
		  <span>Դաս 6</span>
          <p>Jquery ներածություն</p>
            <p>Jquery ներածություն, սելեկտորներ , էլեմենտների ընտրություն, ․css(), .hide(), .show(), մեթոդներ;</p>
		  </a>
        </h4>
      </div>
      <div id="lesson6" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">JavaScript դասընթացի նպատակը</h2>
		<p class="web4">Ծանոթանալ գրադարանների ընդհանուր աշխատանքի հետ</p>
					<p class="web4">Ծանոթանալ JQuery գրադարանի ընդանուր աշխատանքի հետ</p>
					<p class="web4">Օգտվել JQuery գրադարանից</p>
		</div>
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson7">
		  <span>Դաս 7</span>
            <p>Jquery ներածություն</p>
            <p>Slideup(), slidedown(), text(), html(), val(), attr(), children(), parent(), prev(), next(), prepend(), append(), click(), submit(), .toggle(), fadeIn() , .fadeOut(), .fadeTo(), .fadeToggle(),
.stop(), find(), filter(), each() մեթոդներ։
</p>
		  </a>
        </h4>
      </div>
      <div id="lesson7" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">JavaScript դասընթացի նպատակը</h2>
		<p class="web4">Ծանոթանալ JQuery գրադարանի հաճախ կիրառվող մեթոդների հետ</p>
		</div>
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson8">
		  <span>Դաս 8</span>
          <p>Պրակտիկ դաս՝ հիշողությունը լավացնող խաղի ծրագրավորում</p>
		  </a>
        </h4>
      </div>
      <div id="lesson8" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">JavaScript դասընթացի նպատակը</h2>
			<p class="web4">Ամրապնդել DOM գիտելիքները</p>
					<p class="web4">Զարգացնել ալգորիթմիկ մտածելակերպը</p>
					<p class="web4">Աշխատել JQuery գրադարանի հետ</p>
		</div>
      </div>
    </div>
		<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson9">
		  <span>Դաս 9</span>
          <p>Json, ajax տեխնոլոգիա</p>
		  </a>
        </h4>
      </div>
      <div id="lesson9" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">JavaScript դասընթացի նպատակը</h2>
		<p class="web-development">Ծանոթություն json, ajax տեխնոլոգիաներ</p>
		</div>
      </div>
    </div>
		<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson10">
		  <span>Դաս 10</span>
           <p>API ներածություն,YouTube API</p>
		  </a>
        </h4>
      </div>
      <div id="lesson10" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">JavaScript դասընթացի նպատակը</h2>
	<p class="web4">Ծանոթանալ API տեխնոոգիաների հիմնական աշխատնքի հետ,</p>
					<p class="web4">Ծանոթանալ Google ընկերության API ծառայությունների հիմնական աշխատանքին</p>
					<p class="web4">Օգտվել YouTube API ծառայություններից</p>
		
		</div>
      </div>
    </div>
		<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson11">
		  <span>Դաս 11</span>
         <p>OOP ներածություն</p>
		  </a>
        </h4>
      </div>
      <div id="lesson11" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">JavaScript դասընթացի նպատակը</h2>
		<p class="web4">Ծանոթանալ OOP - ի հիմնական կոնցեպցիաների հետ</p>
		</div>
      </div>
    </div>
		<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson12">
		  <span>Դաս 12</span>
           <p>OOP շարունակություն</p>
		  </a>
        </h4>
      </div>
      <div id="lesson12" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">JavaScript դասընթացի նպատակը</h2>
		<p>OOP շարունակություն</p>
		</div>
      </div>
    </div>
	
	
	
	
	
  </div> 
</div>
</section>
@endsection