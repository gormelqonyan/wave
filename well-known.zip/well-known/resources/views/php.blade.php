
@extends('layouts.pbase')

@section('content')
<section class="courses-1">
	<div class="container">	
				<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="{{route('index')}}">@lang('global.Home')</a>
    </li>
    <li class="breadcrumb-item"><a href="{{route('web')}}">@lang('global.Courses')</a></li>
	 <li class="breadcrumb-item active">PHP դասընթացներ</li>
</ol>
<div class="panel-group" id="accordion">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson1">
		  <span>Դաս 1</span>
             <p>Ի՞նչ է PHP  ֊ ն</p>
            <p>Ինչպես գրել PHP կոդ , Փոփոխականներ, հաստատուններ , Տվյալների տիպեր</p>
			</a>
        </h4>
      </div>
      <div id="lesson1" class="panel-collapse collapse in">
        <div class="panel-body">
	<h2 class="npatak">PHP դասընթացի նպատակը</h2>
			<p class="web4">Այս դասի ընթացքում կուսումնասիրենք՝</p>
					<p class="web4">1. Ի՞նչ է PHP  ֊ ն,</p>
					<p class="web4">2. Փոփոխականներ, կոնստանտներ,</p>
					<p class="web4">3. Գործողություններ փոփոխականների հետ,</p>
					<p class="web4">4. Հղում փոփոխականներ</p>
		</div>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson2">
		  <span>Դաս 2</span>
            <p>Մաթեմատիկական գործողություններ ,If-else օպերատոր</p>
            <p>If-else պայմանական օպերատոր , Switch-case պայմանական օպերատոր</p>
		  </a>
        </h4>
      </div>
      <div id="lesson2" class="panel-collapse collapse">
        <div class="panel-body">
	<h2 class="npatak">PHP դասընթացի նպատակը</h2>
					<p class="web4">Այս դասի ընթացքում կուսումնասիրենք՝</p>
					<p class="web4">1. Մաթեմատիկական գործողություններ,</p>
					<p class="web4">2. Տողային գործողություններ,</p>
					<p class="web4">3. Տրամաբանական գործողություններ,</p>
					<p class="web4">4. If-else, switch-case օպերատորներ</p>
	</div>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson3">
		  <span>Դաս 3</span>
            <p>Ցիկլեր , Զանգվածներ , Ֆունկցիաներ</p>
            <p>Ի՞նչ է ցիկլը , Պարամետրական ցիկլ , Հետպայմանով ցիկլ</p>
		  </a>
        </h4>
      </div>
      <div id="lesson3" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">PHP դասընթացի նպատակը</h2>
					<p class="web4">Այս դասի ընթացքում կուսումնասիրենք՝</p>
					<p class="web4">1. Ցիկլեր,</p>
					<p class="web4">2. Զանգվածներ,</p>
					<p class="web4">3. Ֆունկցիաներ,</p>
					<p class="web4">4. Փոփոխականների տեսանելիության տիրույթ,</p>
					<p class="web4">4. Ռեկուրսիա,</p>
		</div>
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson4">
		  <span>Դաս 4</span>
            <p>Սուպերգլոբալ փոփոխականներ</p>
            <p>Ի՞նչ է սուպերգլոբալ փոփոխականը, Սուպերգլոբալ փոփոխականներ</p>
		  </a>
        </h4>
      </div>
      <div id="lesson4" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">PHP դասընթացի նպատակը</h2>
	<p class="web4">Այս դասի ընթացքում կուսումնասիրենք՝</p>
					<p class="web4">1. Սուպերգլոբալ փոփոխականներ,</p>
					<p class="web4">2. Քուքիներ, սեսսիաներ,</p>
		</div>
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson5">
		  <span>Դաս 5</span>
             <p>Include, require ֆունկցիաներ</p>
            <p>Include, include_once, require, require_once ֆունկցիաների տարբերությունը</p>
		  </a>
        </h4>
      </div>
      <div id="lesson5" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">PHP դասընթացի նպատակը</h2>
				<p class="web4">Այս դասի ընթացքում կուսումնասիրենք՝</p>
					<p class="web4">1. Include, require ֆունկցիաներ,</p>
					<p class="web4">2. շաբլոնավորում,</p>
		</div>
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson6">
		  <span>Դաս 6</span>
          <p>Տվյալների բազաներ, SQL հարամաններ</p>
            <p>Ի՞նչ է տվյալների բազան, Գործիքներ, որոնք աշխատում են MySql տվյալների բազայի հետ</p>
		  </a>
        </h4>
      </div>
      <div id="lesson6" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">PHP դասընթացի նպատակը</h2>
		<<p class="web4">Այս դասի ընթացքում կուսումնասիրենք՝</p>
					<p class="web4">1. Տվյալների բազաներ,</p>
					<p class="web4">2. SQL հարամաններ,</p>
					<p class="web4">3. PHP & MySql</p>
		</div>
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson7">
		  <span>Դաս 7</span>
           <p>Պրակտիկ դաս՝ ամրապնդել գիտելիքները</p>
            <p>Պատրաստել սոց․ցանց</p>
		  </a>
        </h4>
      </div>
      <div id="lesson7" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">PHP դասընթացի նպատակը</h2>
		<p class="web4">Պրակտիկ դաս՝ ամրապնդել գիտելիքները</p>
		</div>
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson8">
		  <span>Դաս 8</span>
           <p>Պրակտիկ դաս՝ հիշողությունը լավացնող խաղի ծրագրավորում</p>
		  </a>
        </h4>
      </div>
      <div id="lesson8" class="panel-collapse collapse">
        <div class="panel-body">
		<p>Պրակտիկ դաս՝ հիշողությունը լավացնող խաղի ծրագրավորում</p>
		</div>
      </div>
    </div>
		<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson9">
		  <span>Դաս 9</span>
          <p>Json, ajax տեխնոլոգիա</p>
		  </a>
        </h4>
      </div>
      <div id="lesson9" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">PHP դասընթացի նպատակը</h2>
		<p class="web-development">Ծանոթություն json, ajax տեխնոլոգիաներ</p>
		</div>
      </div>
    </div>
		<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson10">
		  <span>Դաս 10</span>
           <p>API ներածություն,YouTube API</p>
		  </a>
        </h4>
      </div>
      <div id="lesson10" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">PHP դասընթացի նպատակը</h2>
	<p class="web4">Ծանոթանալ API տեխնոոգիաների հիմնական աշխատնքի հետ,</p>
					<p class="web4">Ծանոթանալ Google ընկերության API ծառայությունների հիմնական աշխատանքին</p>
					<p class="web4">Օգտվել YouTube API ծառայություններից</p>
		
		</div>
      </div>
    </div>
		<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson11">
		  <span>Դաս 11</span>
         <p>OOP ներածություն</p>
		  </a>
        </h4>
      </div>
      <div id="lesson11" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">PHP դասընթացի նպատակը</h2>
		<p class="web4">Ծանոթանալ OOP - ի հիմնական կոնցեպցիաների հետ</p>
		</div>
      </div>
    </div>
		<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson12">
		  <span>Դաս 12</span>
           <p>OOP շարունակություն</p>
		  </a>
        </h4>
      </div>
      <div id="lesson12" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">PHP դասընթացի նպատակը</h2>
		<p>OOP շարունակություն</p>
		</div>
      </div>
    </div>
	
	
	
	
	
  </div> 
</div>
</section>

@endsection