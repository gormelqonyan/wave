
    <h3>Hy</h3>\
   
    <p>Անուն:  {{$token['name']}}</p>

    
    <br>
    <p>E-mail:  {{$token['email']}}</p>

    
    
    <br>
    <p>Հեռ․ Համար:  {{$token['subject']}}</p>
   
    <br>
    <p>Հաղորդագրություն:</p><p>  {{$token['message']}}</p>


