@extends('layouts.abase')

@section('content')


<!-- Start About area -->
<div id="about" class="about-area area-padding sectionMargin">
    <div class="container" style="sectionMargin">
        <div class="row">
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="{{route('index')}}">@lang('global.Home')</a>
    </li>
    <li class="breadcrumb-item active">@lang('global.About')</li>
</ol>
            <div class="col-md-12 col-sm-12 col-xs-12 text-center">
                <div class="section-headline text-center">
                    <h2>@lang('global.About_us')</h2>
                </div>
                <p class="about_p">
                    @lang('global.About_us_text1')
                </p>
                <p class="about_p">
                    @lang('global.About_us_text2')
                </p>
            </div>
        </div>
        <!--<div class="row">-->
        <!--    <div class="text-center col-md-12 col-sm-12 col-xs-12">-->
        <!--        <a href="#">-->
        <!--            <h1 class="sec-head">@lang('global.Project_maintenance')</h1>-->
        <!--        </a>-->
        <!--    </div>-->
        <!--    <div class="card-deck">-->
        <!--      <div class="card cardIcon col-md-4 col-sm-4 col-xs-10">-->
        <!--        <div class="card-body  text-center">-->
        <!--          <h5 class="card-title">Վեբ կայքերի մշակում CMS-ի միջոցով</h5>-->
        <!--          <div class="col-md-12 col-sm-12 col-xs-12 text-center">-->
        <!--              <div class="col-md-4 col-sm-4 col-xs-4">-->
        <!--                  <img class="" src="img/about/icons/WordPress.png" alt="Word Press">-->
        <!--                  <p class="">Word Press</p>-->
        <!--              </div>-->
        <!--              <div class="col-md-4 col-sm-4 col-xs-4">-->
        <!--                  <img class="" src="img/about/icons/opencart.png" alt="OpenCart">-->
        <!--                  <p>OpenCart</p>-->
        <!--              </div>-->
        <!--              <div class="col-md-4 col-sm-4 col-xs-4">-->
        <!--                  <img class="" src="img/about/icons/drupal.png" alt="Drupal">-->
        <!--                  <p>Drupal</p>-->
        <!--              </div>-->
        <!--          </div>-->
        <!--        </div>-->
        <!--      </div>-->
        <!--      <div class="card cardIcon col-md-4 col-sm-4 col-xs-12">-->
        <!--        <div class="card-body text-center">-->
        <!--          <h5 class="card-title">Վեբ կայքերի մշակում օգտագործելով</h5>-->
        <!--          <h5 class="card-title">Front-End</h5>-->
        <!--          <div class="col-md-12 col-sm-12 col-xs-12">-->
        <!--              <div class="col-md-4 col-sm-4 col-xs-4">-->
        <!--                  <img class="" src="img/about/icons/html5.png" alt="HTML5">-->
        <!--                  <p class="">HTML5</p>-->
        <!--              </div>-->
        <!--              <div class="col-md-4 col-sm-4 col-xs-4">-->
        <!--                  <img class="" src="img/about/icons/css3.png" alt="CSS3">-->
        <!--                  <p>CSS3</p>-->
        <!--              </div>-->
        <!--              <div class="col-md-4 col-sm-4 col-xs-4">-->
        <!--                  <img class="" src="img/about/icons/js.png" alt="CSS3">-->
        <!--                  <p>Java Script</p>-->
        <!--              </div>-->
        <!--              <div class="col-md-4 col-sm-4 col-xs-4">-->
        <!--                  <img class="" src="img/about/icons/jquery.png" alt="CSS3">-->
        <!--                  <p>jQuery</p>-->
        <!--              </div>-->
        <!--              <div class="col-md-4 col-sm-4 col-xs-4">-->
        <!--                  <img class="" src="img/about/icons/react.png" alt="CSS3">-->
        <!--                  <p>ReactJS</p>-->
        <!--              </div>-->
        <!--              <div class="col-md-4 col-sm-4 col-xs-4">-->
        <!--                  <img class="" src="img/about/icons/angular.png" alt="CSS3">-->
        <!--                  <p>Angular 6</p>-->
        <!--              </div>-->
        <!--          </div>-->
        <!--        </div>-->
        <!--      </div>-->
        <!--      <div class="card cardIcon col-md-4 col-sm-4 col-xs-10">-->
        <!--        <div class="card-body  text-center">-->
        <!--          <h5 class="card-title">Վեբ կայքերի մշակում</h5>-->
        <!--          <h5 class="card-title">PHP</h5>-->
                      <!--<div class="col-md-12 col-sm-12 col-xs-12">-->
                      <!--    <img class="" src="img/about/icons/php.png" alt="PHP">-->
                      <!--    <p>PHP</p>-->
                      <!--</div>-->
        <!--              <div class="col-md-4 col-sm-4 col-xs-4">-->
        <!--                  <img class="" src="img/about/icons/laravel.png" alt="Laravel">-->
        <!--                  <p class="">Laravel</p>-->
        <!--              </div>-->
        <!--              <div class="col-md-4 col-sm-4 col-xs-4">-->
        <!--                  <img class="" src="img/about/icons/yii.png" alt="Yii2">-->
        <!--                  <p>Yii2</p>-->
        <!--              </div>-->
        <!--              <div class="col-md-4 col-sm-4 col-xs-4">-->
        <!--                  <img class="" src="img/about/icons/codeigniter.png" alt="CodeIgniter">-->
        <!--                  <p>CodeIgniter</p>-->
        <!--              </div>-->
        <!--          </div>-->
        <!--        </div>-->
        <!--      </div>-->
        <!--    </div>-->
        <!-- <div class="row">   -->
        <!--    <div class="card-deck">-->
        <!--        <div class="card cardIcon col-md-4 col-sm-4 col-xs-10">-->
        <!--        <div class="card-body  text-center">-->
        <!--          <h5 class="card-title">Back-End</h5>-->
        <!--          <div class="col-md-12 col-sm-12 col-xs-12 text-center">-->
        <!--              <div class="col-md-4 col-sm-4 col-xs-4">-->
        <!--                  <img class="" src="img/about/icons/python.png" alt="Python">-->
        <!--                  <p class="">Python</p>-->
        <!--              </div>-->
        <!--              <div class="col-md-4 col-sm-4 col-xs-4">-->
        <!--                  <img class="" src="img/about/icons/django.png" alt="Django">-->
        <!--                  <p>Django</p>-->
        <!--              </div>-->
        <!--              <div class="col-md-4 col-sm-4 col-xs-4">-->
        <!--                  <img class="" src="img/about/icons/flask.png" alt="Flask">-->
        <!--                  <p>Flask</p>-->
        <!--              </div>-->
        <!--          </div>-->
        <!--        </div>-->
        <!--      </div>-->
        <!--      <div class="card cardIcon col-md-4 col-sm-4 col-xs-10">-->
        <!--        <div class="card-body  text-center">-->
        <!--          <h5 class="card-title">Back-End</h5>-->
        <!--          <div class="col-md-12 col-sm-12 col-xs-12 text-center">-->
        <!--              <div class="col-md-6 col-sm-6 col-xs-6">-->
        <!--                  <img class="" src="img/about/icons/java.png" alt="Java">-->
        <!--                  <p class="">Java</p>-->
        <!--              </div>-->
        <!--              <div class="col-md-6 col-sm-6 col-xs-6">-->
        <!--                  <img class="" src="img/about/icons/spring.png" alt="Spring">-->
        <!--                  <p>Spring</p>-->
        <!--              </div>-->
        <!--          </div>-->
        <!--        </div>-->
        <!--      </div>-->
        <!--      <div class="card cardIcon col-md-4 col-sm-4 col-xs-10">-->
        <!--        <div class="card-body  text-center">-->
        <!--          <h5 class="card-title">Բջջային հավելվածի նախագծում</h5>-->
        <!--          <div class="col-md-12 col-sm-12 col-xs-12 text-center">-->
        <!--              <div class="col-md-6 col-sm-6 col-xs-6">-->
        <!--                  <img class="" src="img/about/icons/android.png" alt="Android">-->
        <!--                  <p class="">Android</p>-->
        <!--              </div>-->
        <!--              <div class="col-md-6 col-sm-6 col-xs-6">-->
        <!--                  <img class="" src="img/about/icons/IOS.png" alt="IOS">-->
        <!--                  <p>IOS</p>-->
        <!--              </div>-->
        <!--          </div>-->
        <!--        </div>-->
        <!--      </div>-->
        <!--    </div>-->
        <!--    </div>-->
             <!--single-well start-->
            <!--<div class="col-md-4 col-sm-4 col-xs-10" id="aboutScrollLeft">-->
            <!--    <div class="well-left">-->
            <!--        <div class="single-well">-->
            <!--            <a href="#">-->
            <!--                <img src="img/about/web-manjeri1-min.jpg" alt="WEB MANJERI">-->
            <!--            </a>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--</div>-->
             <!--single-well end-->
            <!--<div class="col-md-6 col-sm-6 col-xs-12" id="aboutScrollRigth">-->
            <!--    <div class="well-middle">-->
            <!--        <div class="single-well">-->
                        

            <!--            <ul>-->
            <!--                <li>-->
            <!--                    <i class="fa fa-check"></i>-->
            <!--                    @lang('global.Proj')-->
            <!--                </li>-->
            <!--                <li>-->
            <!--                    <i class="fa fa-check"></i>-->
            <!--                    @lang('global.Proj_1')<i class="fa fa-arrow-right mx-3" style="margin-left: 10px;" aria-hidden="true"></i>@lang('global.Proj_1.1')-->
            <!--                </li>-->
            <!--                <li>-->
            <!--                    <i class="fa fa-check"></i>-->
            <!--                    @lang('global.Proj1.1')<i class="fa fa-arrow-right mx-3" style="margin-left: 10px;" aria-hidden="true"></i>@lang('global.Proj1.2')-->
            <!--                </li>-->
            <!--                <li>-->
            <!--                    <i class="fa fa-check"></i>-->
            <!--                    @lang('global.Proj2')-->
            <!--                </li>-->
            <!--                <li>-->
            <!--                    <i class="fa fa-check"></i>-->
            <!--                    @lang('global.Proj3')<i class="fa fa-arrow-right mx-3" style="margin-left: 10px;" aria-hidden="true"></i>@lang('global.Proj3.1')-->
            <!--                </li>-->
            <!--                <li>-->
            <!--                    <i class="fa fa-check"></i>-->
            <!--                    @lang('global.Proj4.1')<i class="fa fa-arrow-right mx-3" style="margin-left: 10px;" aria-hidden="true"></i>@lang('global.Proj4.1.1')-->
            <!--                </li>-->
            <!--                <li>-->
            <!--                    <i class="fa fa-check"></i>-->
            <!--                    @lang('global.Proj4.2')<i class="fa fa-arrow-right mx-3" style="margin-left: 10px;" aria-hidden="true"></i>@lang('global.Proj4.2.1')-->
            <!--                </li>-->
            <!--                <li>-->
            <!--                    <i class="fa fa-check"></i>-->
            <!--                    @lang('global.Proj5')-->
            <!--                </li>-->
            <!--                <li>-->
            <!--                    <i class="fa fa-check"></i>-->
            <!--                    @lang('global.Proj6')-->
            <!--                </li>-->
            <!--            </ul>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--</div>-->
             <!--End col-->
        </div>
    </div>
</div>
<!-- End About area -->

<!-- our-skill-area start -->
<div class="our-skill-area fix hidden-sm">
    <div class="test-overly"></div>
        <div class="container">
            <div class="col-xs-6 col-sm-6 col-md-4 about_info">
                <div class="about_item " >
                    <div class="about_radius">
                        @lang('global.From_days')
                    </div>
                    <h4>@lang('global.Project_creation')</h4>
                </div>
            </div>
            <!--<div class="col-xs-6 col-sm-6 col-md-3 about_info">
                <div class="about_item " >
                    <div class="about_radius prepay_30">
                        <p>30%</p>
                    </div>
                    <h4>@lang('global.Prepayment')</h4>
                </div>
            </div>-->
            <div class="col-xs-6 col-sm-6 col-md-4 about_info">
                <div class="about_item " >
                    <div class="about_radius">
                        @lang('global.Over_projects')
                    </div>
                    <h4>@lang('global.Performed')</h4>
                </div>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-4 about_info">
                <div class="about_item " >
                    <div class="about_radius">
                        24/7
                    </div>
                    <h4>@lang('global.Technical_support')</h4>
                </div>
            </div>
        </div>
</div>
<!-- our-skill-area end -->

<!-- Start Service area -->
<div id="services" class="services-area area-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline services-head text-center">
                    <h2>@lang('global.Our_services')</h2>
                </div>
            </div>
        </div>
        <div class="row text-center" id="servicesScrollLeft">
            <div class="services-contents">
                <!-- Start Left services -->
                <div class="col-md-4 col-sm-4 col-xs-12  py-5">
                    <div class="about-move">
                        <div class="services-details">
                            <div class="single-services">
                                <h2>@lang('global.Web_services')</h2>
                                <p>@lang('global.Web_dev')</p>
                                <p>@lang('global.Web_design')</p>
                              
                                <p>@lang('global.Technical_audit')</p>
                                <p>@lang('global.Site_service')</p>
                            </div>
                        </div>
                        <!-- end about-details -->
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12 my-4">
                    <div class="about-move">
                        <div class="services-details">
                            <div class="single-services">
                                <h2>@lang('global.SEO_optimization')</h2>
                                <p>@lang('global.Key_words')</p>
                                <p>@lang('global.Semantic_core')</p>
                                <p>@lang('global.Internal_optimization')</p>
                                <p>@lang('global.External_optimization')</p>
                            </div>
                        </div>
                        <!-- end about-details -->
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <!-- end col-md-4 -->
                    <div class=" about-move">
                        <div class="services-details">
                            <div class="single-services">
                                <h2>@lang('global.Internet_marketing')</h2>
                                <p>@lang('global.Social_media_marketing')</p>
                                <p>@lang('global.Marketing_analysis')</p>
                                <p>@lang('global.Internet_advertising')</p>
                                
                                <span><i class="fa fa-facebook"></i></span>
                                <span><i class="fa fa-instagram"></i></span>
                                <span><i class="fa fa-linkedin"></i></span>
                                <span><i class="fa fa-youtube"></i></span>
                                <span><i class="fa fa-vk"></i></span>
                            </div>
                        </div>
                        <!-- end about-details -->
                    </div>
                </div>
                <!-- end col-md-4 -->
            </div>
        </div>
        <div class="row text-center" id="servicesScrollRight">
            <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="about-move">
                    <div class="services-details">
                        <div class="single-services">
                            <h2>@lang('global.Time_monitoring')</h2>
                            <p>@lang('global.Host_server')</p>
                            <p>@lang('global.Site_recovery')</p>
                            <p>@lang('global.Domain_registration')</p>
                        </div>
                    </div>
                    <!-- end about-details -->
                </div>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="about-move">
                    <div class="services-details">
                        <div class="single-services">
                            <h2>@lang('global.Graphic_design')</h2>
                            <a href="{{route('logo')}}"><i class="fa fa-arrow-right"></i>@lang('global.logo')</a><br>
                            <a href="{{route('card')}}"><i class="fa fa-arrow-right"></i>@lang('global.card')</a><br>
							<a href="{{route('design')}}"><i class="fa fa-arrow-right"></i>@lang('global.3d')</a><br>
							<a href="{{route('banners')}}"><i class="fa fa-arrow-right"></i>@lang('global.Banner_creation')</a>
                        </div>
                    </div>
                    <!-- end about-details -->
                </div>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="about-move">
                    <div class="services-details">
                        <div class="single-services">
                            <h2><a href="#">@lang('global.IOS_Android')</a></h2>
                            <a href="https://play.google.com/store/apps/details?id=com.birthright" target="_blank"><i class="fa fa-arrow-right" aria-hidden="true"></i>Birthright Connect </a><br>
                            <a href="https://play.google.com/store/apps/details?id=com.hikearmenia" target="_blank"><i class="fa fa-arrow-right" aria-hidden="true"></i>HIKEArmenia</a><br>
                            <a href="https://play.google.com/store/apps/details?id=com.learnbat.showme" target="_blank"><i class="fa fa-arrow-right" aria-hidden="true"></i>ShowMe Interactive Whiteboard</a>
                        </div>
                    </div>
                    <!-- end about-details -->
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Service area -->

@endsection