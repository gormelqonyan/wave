<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Wave IT</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">
  <style>
      .carousel {
          /*max-height: 650px !important;*/
          width: 100% !important;
      }
  </style>

  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700|Raleway:300,400,400i,500,500i,700,800,900" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/nivo-slider/css/nivo-slider.css" rel="stylesheet">
  <link href="lib/owlcarousel/owl.carousel.css" rel="stylesheet">
  <link href="lib/owlcarousel/owl.transitions.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/swiper.min.css">
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/venobox/venobox.css" rel="stylesheet">

  <!-- Nivo Slider Theme -->
  <link href="css/nivo-slider-theme.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">

  <!-- Responsive Stylesheet File -->
  <link href="css/responsive.css" rel="stylesheet">

  <!-- =======================================================
    Theme Name: eBusiness
    Theme URL: https://bootstrapmade.com/ebusiness-bootstrap-corporate-template/
    Author: BootstrapMade.com
    License: https://bootstrapmade.com/license/
  ======================================================= -->
</head>

<body data-spy="scroll" data-target="#navbar-example">

  <div id="preloader"></div>

  <header>
    <!-- header-area start -->
    <div id="sticker" class="header-area">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12">

            <!-- Navigation -->
            <nav class="navbar navbar-default">
              <!-- Brand and toggle get grouped for better mobile display -->
              <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".bs-example-navbar-collapse-1" aria-expanded="false">
										<span class="sr-only">Toggle navigation</span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
									</button>
                <!-- Brand -->
                <a class="navbar-brand page-scroll sticky-logo" href="/">
                  <!--<h1><span>e</span>Business</h1>-->
                  <!-- Uncomment below if you prefer to use an image logo -->
                  <img src="img/logo.png" alt="LOGO" width="180" height="30" title="">
                </a>
              </div>
              <div class="dropdown language_drop">
                <button class="btn dropdown-toggle" type="button" data-toggle="dropdown">
                    <img style="width:18px;margin-top:-4px" src="img/about/en.png" alt="">
                    <span>Eng</span>
                    <span class="caret"></span>
                </button>
                <ul class="dropdown-menu language_menu ">
                    <li>
                        <a href="http://wave-it.ru/?lang=rus">
                            <img style="width:20px;margin-top:-4px" src="img/about/ru.png" alt="">
                            <span>Рус</span>
                        </a>
                    </li>
                </ul>
            </div>
              <!-- Collect the nav links, forms, and other content for toggling -->
              <div class="collapse navbar-collapse main-menu bs-example-navbar-collapse-1" id="navbar-example">
                <ul class="nav navbar-nav navbar-right">
                  <li class="active">
                    <a class="page-scroll" href="#home">Home</a>
                  </li>
                  <li>
                    <a class="page-scroll" href="#about">About</a>
                  </li>
                  <li>
                    <a class="page-scroll" href="#services">Services</a>
                  </li>
                  <li>
                    <a class="page-scroll" href="#team">Team</a>
                  </li>
                  <li>
                    <a class="page-scroll" href="#portfolio">Portfolio</a>
                  </li>
                  <li>
                    <a class="page-scroll" href="#blog">Blog</a>
                  </li>
                  <li>
                    <a class="page-scroll" href="#contact">Contact</a>
                  </li>
                  <li>

                  </li>
                </ul>
                <!--<div class="dropdown language_drop">-->
                <!--      <button class="btn dropdown-toggle" type="button" data-toggle="dropdown">-->
                <!--          <img style="width:18px;margin-top:-4px" src="img/about/en.png" alt="">-->
                <!--          <span>Eng</span>-->
                <!--          <span class="caret"></span>-->
                <!--      </button>-->
                <!--      <ul class="dropdown-menu language_menu ">-->
                <!--          <li>-->
                <!--              <a href="http://wave-it.ru/?lang=rus">-->
                <!--                  <img style="width:20px;margin-top:-4px" src="img/about/ru.png" alt="">-->
                <!--                  <span>Рус</span>-->
                <!--              </a>-->
                <!--          </li>-->
                <!--      </ul>-->
                <!--  </div>-->
              </div>
              <!-- navbar-collapse -->
            </nav>
            <!-- END: Navigation -->
          </div>
        </div>
      </div>
    </div>
    <!-- header-area end -->
  </header>
  <!-- header end -->

  <!-- Start Slider Area -->
  <div id="home" class="slider-area">
    <div class="bend niceties preview-2">
      <div id="ensign-nivoslider" class="slides carousel">
        <img src="img/final/01.jpg" alt="" height="750" title="#slider-direction-1" />
        <img src="img/final/02.jpg" alt="" height="750"  />
        <img src="img/final/03.jpg" alt="" height="750" title="#slider-direction-3" />
        <!--<img src="img/final/04.jpg" alt=""  height="750"  />-->
        <img src="img/final/05.jpg" alt=""  height="750"  />
        <!--<img src="img/final/08.jpg" alt=""  height="750"  />-->
        <!--<img src="img/final/slider9.png" alt=""  height="750"  />-->
        <!--<img src="img/final/slider10.png" alt="" height="750"  />-->
        <!--<img src="img/final/slider12.png" alt="" height="750"  />-->
      </div>

      <!-- direction 1 -->
      <div id="slider-direction-1" class="slider-direction slider-one">
        <!--<div class="container">-->
          <!--<div class="row">-->
            <!--<div class="col-md-12 col-sm-12 col-xs-12">-->
              <!--<div class="slider-content">-->
                <!--&lt;!&ndash; layer 1 &ndash;&gt;-->
                <!--<div class="layer-1-1 hidden-xs wow slideInDown" data-wow-duration="2s" data-wow-delay=".2s">-->
                  <!--<h2 class="title1">The Best Business Information </h2>-->
                <!--</div>-->
                <!--&lt;!&ndash; layer 2 &ndash;&gt;-->
                <!--<div class="layer-1-2 wow slideInUp" data-wow-duration="2s" data-wow-delay=".1s">-->
                  <!--<h1 class="title2">We're In The Business Of Helping You Start Your Business</h1>-->
                <!--</div>-->
                <!--&lt;!&ndash; layer 3 &ndash;&gt;-->
                <!--<div class="layer-1-3 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">-->
                  <!--<a class="ready-btn right-btn page-scroll" href="#services">See Services</a>-->
                  <!--<a class="ready-btn page-scroll" href="#about">Learn More</a>-->
                <!--</div>-->
              <!--</div>-->
            <!--</div>-->
          <!--</div>-->
        <!--</div>-->
      </div>

      <!-- direction 2 -->
      <div id="slider-direction-2" class="slider-direction slider-two">
        <!--<div class="container">-->
          <!--<div class="row">-->
            <!--<div class="col-md-12 col-sm-12 col-xs-12">-->
              <!--<div class="slider-content text-center">-->
                <!--&lt;!&ndash; layer 1 &ndash;&gt;-->
                <!--<div class="layer-1-1 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">-->
                  <!--<h2 class="title1">The Best Business Information </h2>-->
                <!--</div>-->
                <!--&lt;!&ndash; layer 2 &ndash;&gt;-->
                <!--<div class="layer-1-2 wow slideInUp" data-wow-duration="2s" data-wow-delay=".1s">-->
                  <!--<h1 class="title2">We're In The Business Of Get Quality Business Service</h1>-->
                <!--</div>-->
                <!--&lt;!&ndash; layer 3 &ndash;&gt;-->
                <!--<div class="layer-1-3 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">-->
                  <!--<a class="ready-btn right-btn page-scroll" href="#services">See Services</a>-->
                  <!--<a class="ready-btn page-scroll" href="#about">Learn More</a>-->
                <!--</div>-->
              <!--</div>-->
            <!--</div>-->
          <!--</div>-->
        <!--</div>-->
      </div>

      <!-- direction 3 -->
      <div id="slider-direction-3" class="slider-direction slider-two">
        <div class="container">
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="slider-content">
                <!-- layer 1 -->
                <div class="layer-1-1 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">
                  <h2 class="title1"> </h2>
                </div>
                <!-- layer 2 -->
                <div class="layer-1-2 wow slideInUp" data-wow-duration="2s" data-wow-delay=".1s">
                  <h1 class="title2"> </h1>
                </div>
                <!-- layer 3 -->
                <!--<div class="layer-1-3 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">
                  <a class="ready-btn right-btn page-scroll" href="#services">See Services</a>
                  <a class="ready-btn page-scroll" href="#about">Learn More</a>
                </div>-->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- direction 4 -->
  <div id="slider-direction-4" class="slider-direction slider-two">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="slider-content">
            <!-- layer 1 -->
            <div class="layer-1-1 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">
              <h2 class="title1">The Best business Information </h2>
            </div>
            <!-- layer 2 -->
            <div class="layer-1-2 wow slideInUp" data-wow-duration="2s" data-wow-delay=".1s">
              <h1 class="title2">Helping Business Security  & Peace of Mind for Your Family</h1>
            </div>
            <!-- layer 3 -->
            <div class="layer-1-3 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">
              <a class="ready-btn right-btn page-scroll" href="#services">See Services</a>
              <a class="ready-btn page-scroll" href="#about">Learn More</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- End Slider Area -->

  <!-- Start About area -->
  <div id="about" class="about-area area-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline text-center">
            <h2>About Us</h2>
          </div>
        </div>
          <div class="row about_part">
              <!-- single-well start-->
              <div class="col-md-6 col-sm-6 col-xs-12" id="aboutScrollLeft">
                  <div class="well-left">
                      <div class="single-well">
                          <a href="#">
                              <img src="img/about/web-manjeri1-min.jpg" alt="WEB MANJERI">
                          </a>
                      </div>
                  </div>
              </div>
              <!-- single-well end-->
              <div class="col-md-6 col-sm-6 col-xs-12" id="aboutScrollRigth">
                  <div class="well-middle">
                      <div class="single-well">
                          <a href="#">
                              <h4 class="sec-head">Project Maintenance</h4>
                          </a>
                          <p>
                              Performing various tasks for maintenance/modification of the site. Placement of information
                              (adding articles, news, products, pictures, videos, etc.)
                          </p>
                          <ul>
                              <li>
                                  <i class="fa fa-check"></i>
                                  We determine what assistance can be provided to your business
                              </li>
                              <li>
                                  <i class="fa fa-check"></i>
                                  We coordinate the fulfillment of tasks and set new goals with you,
                                  then issue an invoice and proceed to SEO-promotion.
                              </li>
                              <li>
                                  <i class="fa fa-check"></i>
                                  Make site and portal design using CMS
                              </li>
                              <li>
                                  <i class="fa fa-check"></i>
                                  Developing for web-projects with PHP, JavaScript, My SQL, jQuery, Angular 2-6, React JS and more
                              </li>
                              <li>
                                  <i class="fa fa-check"></i>
                                  We are making site by template, exclusive site, landing page, site showcase, online shop
                              </li>
                          </ul>
                      </div>
                  </div>
              </div>
              <!-- End col-->
          </div>
      </div>
    </div>
  </div>
  <!-- End About area -->

  <!-- Start Service area -->
  <div id="services" class="services-area area-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline services-head text-center">
            <h2>Our Services</h2>
          </div>
        </div>
      </div>
      <div class="row text-center" id="servicesScrollLeft">
        <div class="services-contents">
          <!-- Start Left services -->
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="about-move">
              <div class="services-details">
                <div class="single-services">
                  <h4>Web Services</h4>
                  <p>Website development</p>
                  <p>Web design</p>
                  <p>Banner creation</p>
                  <p>Technical audit of site</p>
                  <p>Site service</p>
                </div>
              </div>
              <!-- end about-details -->
            </div>
          </div>
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="about-move">
              <div class="services-details">
                <div class="single-services">
                  <h4>SEO optimization of sites</h4>
                  <p>Analysis of Key Words</p>
                  <p>Creating a semantic core</p>
                  <p>Internal optimization</p>
                  <p>External optimization</p>
                </div>
              </div>
              <!-- end about-details -->
            </div>
          </div>
          <div class="col-md-4 col-sm-4 col-xs-12">
            <!-- end col-md-4 -->
            <div class=" about-move">
              <div class="services-details">
                <div class="single-services">
                  <h4>Internet marketing</h4>
                  <p>Social Media Marketing</p>
                  <p>Marketing analysis</p>
                  <p>Internet advertising</p>
                </div>
              </div>
              <!-- end about-details -->
            </div>
          </div>
          <!-- end col-md-4 -->
        </div>
      </div>
      <div class="row text-center" id="servicesScrollRight">
        <div class="col-md-4 col-sm-4 col-xs-12">
          <div class="about-move">
            <div class="services-details">
              <div class="single-services">
                <h4>
                   24/7 Time
                  <br/>
                  Monitoring site performance
                </h4>
                <p>Host/server administration</p>
                <p>Site recovery</p>
                <p>Checking the expiration of domain registration </p>
                <p></p>
                <p></p>
              </div>
            </div>
            <!-- end about-details -->
          </div>
        </div>
        <div class="col-md-4 col-sm-4 col-xs-12">
          <div class="about-move">
            <div class="services-details">
              <div class="single-services">
                <h4>Social Media Marketing</h4>
                  <span><i class="fa fa-facebook"></i></span>
                  <span><i class="fa fa-instagram"></i></span>
                  <span><i class="fa fa-linkedin"></i></span>
                  <span><i class="fa fa-youtube"></i></span>
                  <span><i class="fa fa-vk"></i></span>

              </div>
            </div>
            <!-- end about-details -->
          </div>
      </div>
      <div class="col-md-4 col-sm-4 col-xs-12">
          <div class="about-move">
              <div class="services-details">
                  <div class="single-services">
                      <h4><a href="#">Development for iOS and Android</a></h4>
                      <a href="https://play.google.com/store/apps/details?id=com.birthright" target="_blank"><i class="fa fa-arrow-right" aria-hidden="true"></i>Birthright Connect </a><br>
                      <a href="https://play.google.com/store/apps/details?id=com.hikearmenia" target="_blank"><i class="fa fa-arrow-right" aria-hidden="true"></i>HIKEArmenia</a><br>
                      <a href="https://play.google.com/store/apps/details?id=com.learnbat.showme" target="_blank"><i class="fa fa-arrow-right" aria-hidden="true"></i>ShowMe Interactive Whiteboard</a>
                  </div>
              </div>
              <!-- end about-details -->
          </div>
      </div>
    </div>
  </div>
  </div>
  <!-- End Service area -->

  <!-- our-skill-area start -->
  <div class="our-skill-area fix hidden-sm">
    <div class="test-overly"></div>
      <div class="container">
          <div class="col-xs-12 col-sm-6 col-md-3 about_info">
              <div class="about_item " >
                  <div class="about_radius">
                      From<br> 10 days
                  </div>
                  <h4>Project creation</h4>
              </div>
          </div>
          <div class="col-xs-12 col-sm-6 col-md-3 about_info">
              <div class="about_item " >
                  <div class="about_radius">
                      30%
                  </div>
                  <h4>Prepayment</h4>
              </div>
          </div>
          <div class="col-xs-12 col-sm-6 col-md-3 about_info">
              <div class="about_item " >
                  <div class="about_radius">
                      Over<br> 60 Projects
                  </div>
                  <h4>Performed</h4>
              </div>
          </div>
          <div class="col-xs-12 col-sm-6 col-md-3 about_info">
              <div class="about_item " >
                  <div class="about_radius">
                      24/7
                  </div>
                  <h4>Technical support</h4>
              </div>
          </div>
      </div>

  </div>
  <!-- our-skill-area end -->

  <!-- Start team Area -->
  <div id="team" class="our-team-area area-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline text-center">
            <h2>Our special Team</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="team-top clearfix swiper-container">
            <div class="swiper-wrapper swiper_items">
              <div class="swiper-slide team_item">
                <div class="single-team-member">
                  <div class="team-img">
                    <a href="#">
                      <img src="img/team/1.jpg" alt="TEAM">
                    </a>
                    <div class="team-social-icon text-center">
                      <ul>
                        <li>
                          <a href="https://www.facebook.com/arshbabayan" target="_blank">
                            <i class="fa fa-facebook"></i>
                          </a>
                        </li>
                        <li>
                          <a href="https://vk.com/id307266562" target="_blank">
                            <i class="fa fa-vk"></i>
                          </a>
                        </li>
                        <li>
                          <a href="https://www.instagram.com/arshak_babayan91/?hl=ru" target="_blank">
                            <i class="fa fa-instagram"></i>
                          </a>
                        </li>
                        <li>
                          <a href="#" target="_blank">
                            <i class="fa fa-linkedin" ></i>
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="team-content text-center">
                    <h4>Arshak Babayan</h4>
                    <p>CEO</p>
                      <div class="team_description">
                          I control the general activities  of the company. It's important for me that everything works, as Swiss watches do.Had MA degree  in  (MIREA) university,
                          the faculty of  "Information systems and technologies" that gave me immense  opportunities for selection  the most qualified experts.
                      </div>
                  </div>
                </div>
              </div>
              <!-- End column -->
              <div class="swiper-slide team_item">
                <div class="single-team-member">
                  <div class="team-img">
                    <a href="#">
                      <img src="img/team/3.jpg" alt="">
                    </a>
                    <div class="team-social-icon text-center">
                      <ul>
                        <li>
                          <a href="https://www.facebook.com/vahagn.tadevosyan.71" target="_blank">
                            <i class="fa fa-facebook"></i>
                          </a>
                        </li>
                        <li>
                          <a href="#" target="_blank">
                            <i class="fa fa-vk"></i>
                          </a>
                        </li>
                        <li>
                          <a href="#" target="_blank">
                            <i class="fa fa-instagram"></i>
                          </a>
                        </li>
                        <li>
                          <a href="#" target="_blank">
                            <i class="fa fa-linkedin" ></i>
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="team-content text-center">
                    <h4>Vahagn Tadevosyan</h4>
                    <p>Deputy CEO</p>
                      <div class="team_description">
                         Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque delectus dolor numquam provident voluptatum. Alias at earum facilis fugit ipsam iusto,
                          nesciunt vel voluptas. Autem cumque eius error ipsa praesentium.
                      </div>
                  </div>
                </div>
              </div>
              <!-- End column -->
              <div class="swiper-slide team_item">
                <div class="single-team-member">
                  <div class="team-img">
                    <a href="#">
                      <img src="img/team/2.jpg" alt="">
                    </a>
                    <div class="team-social-icon text-center">
                      <ul>
                        <li>
                          <a href="https://www.facebook.com/violetta.urazaeva" target="_blank">
                            <i class="fa fa-facebook"></i>
                          </a>
                        </li>
                        <li>
                          <a href="https://vk.com/eweretti" target="_blank">
                            <i class="fa fa-vk"></i>
                          </a>
                        </li>
                        <li>
                          <a href="#" target="_blank">
                            <i class="fa fa-instagram"></i>
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="team-content text-center">
                    <h4>Violetta Urazaeva</h4>
                    <p>Head of Marketing</p>
                      <div class="team_description">
                          In WAVE IT company, my job is to promote client projects in social media, draft content-plans, write texts of various orientations,
                          set advertisements on various advertising boards, do everything for making our clients' projects as popular as possible
                      </div>
                  </div>
                </div>
              </div>
              <!-- End column -->
              <div class="swiper-slide team_item">
            <div class="single-team-member">
              <div class="team-img">
                <a href="#">
                  <img src="img/team/5.jpg" alt="">
                </a>
                <div class="team-social-icon text-center">
                  <ul>
                    <li>
                      <a href="https://www.facebook.com/may.movsisyan" target="_blank">
                        <i class="fa fa-facebook"></i>
                      </a>
                    </li>
                    <li>
                      <a href="#" target="_blank">
                        <i class="fa fa-vk"></i>
                      </a>
                    </li>
                    <li>
                      <a href="https://www.instagram.com/may_movsisyan/?hl=ru" target="_blank">
                        <i class="fa fa-instagram"></i>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="team-content text-center">
                <h4>Mariam Movsisyan</h4>
                <p>Front-End Developer</p>
                  <div class="team_description">
                      In WAVE IT company, I'm a user interface developer, and I also service ready-made websites.
                      I've got my bachelor's and master's degree in the faculty of Electronic Engineering of National Polytechnic University of Armenia
                  </div>
              </div>
            </div>
          </div>
            </div>
          <!-- End column -->
        </div>
      </div>
    </div>
  </div>
  <!-- End Team Area -->

  <!-- Start portfolio Area -->
  <div id="portfolio" class="portfolio-area area-padding fix">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline text-center">
            <h2>Our Portfolio</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <!-- Start Portfolio -page -->
        <div class="awesome-project-1 fix">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="awesome-menu ">
              <ul class="project-menu">
                <li>
                  <a href="#" class="active" data-filter="*">All</a>
                </li>
                <li>
                  <a href="#" data-filter=".development">Development</a>
                </li>
                <li>
                  <a href="#" data-filter=".design">Design</a>
                </li>
                <li>
                  <a href="#" data-filter=".photo">Photoshop</a>
                </li>
                <li>
                  <a href="#" data-filter=".seo">SEO</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="awesome-project-content">
          <!-- single-awesome-project start -->
          <div class="col-md-4 col-sm-4 col-xs-12 seo development">
            <div class="single-awesome-project">
              <div class="awesome-img">
                <a href="#"><img src="img/portfolio/syshevskiydvor-min-min.jpg" alt="SYSHEVSKIDVOR" height="600" /></a>
                <div class="add-actions text-center">
                  <div class="project-dec">
                    <!--<a class="venobox" data-gall="Syshevskiydvor" href="img/portfolio/syshevskiydvor.png">-->
                    <!--  <h4>Сущевский двор</h4>-->
                    <!--</a>-->
                    <a class="" data-gall="Syshevskiydvor" href="http://syshevskiydvor.ru/" target="_blank">
                      <h4>Сущевский двор</h4>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- single-awesome-project end -->
          <!-- single-awesome-project start -->
          <div class="col-md-4 col-sm-4 col-xs-12 photo">
            <div class="single-awesome-project">
              <div class="awesome-img">
                <a href="#"><img src="img/portfolio/screencapture-min-min.jpg" alt="" height="600" /></a>
                <div class="add-actions text-center">
                  <div class="project-dec">
                    <a class="venobox" data-gall="myGallery" href="img/portfolio/screencapture-min-min.jpg">
                      <h4>Car Rental In Germany</h4>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- single-awesome-project end -->
          <!-- single-awesome-project start -->
          <!--<div class="col-md-4 col-sm-4 col-xs-12 design">-->
          <!--  <div class="single-awesome-project">-->
          <!--    <div class="awesome-img">-->
          <!--      <a href="#"><img src="img/portfolio/evakuator.png" alt="" /></a>-->
          <!--      <div class="add-actions text-center">-->
          <!--        <div class="project-dec">-->
          <!--          <a class="venobox" data-gall="myGallery" href="img/portfolio/evakuator.png">-->
          <!--            <h4>Частный Эвакуатор</h4>-->
          <!--            <span>Web Design</span>-->
          <!--          </a>-->
          <!--        </div>-->
          <!--      </div>-->
          <!--    </div>-->
          <!--  </div>-->
          <!--</div>-->
          <!-- single-awesome-project end -->
          <!-- single-awesome-project start -->
          <!--<div class="col-md-4 col-sm-4 col-xs-12 photo development">-->
          <!--  <div class="single-awesome-project">-->
          <!--    <div class="awesome-img">-->
          <!--      <a href="#"><img src="img/portfolio/enfolink.png" alt="" /></a>-->
          <!--      <div class="add-actions text-center">-->
          <!--        <div class="project-dec">-->
          <!--          <a class="venobox" data-gall="myGallery" href="img/portfolio/enfolink.png">-->
          <!--            <h4>Enfolink</h4>-->
          <!--            <span>Web design</span>-->
          <!--          </a>-->
          <!--        </div>-->
          <!--      </div>-->
          <!--    </div>-->
          <!--  </div>-->
          <!--</div>-->
          <!-- single-awesome-project end -->
          <!-- single-awesome-project start -->
          <!--<div class="col-md-4 col-sm-4 col-xs-12 development">-->
          <!--  <div class="single-awesome-project">-->
          <!--    <div class="awesome-img">-->
          <!--      <a href="#"><img src="img/portfolio/cryptoversal.png" alt="" /></a>-->
          <!--      <div class="add-actions text-center text-center">-->
          <!--        <div class="project-dec">-->
          <!--          <a class="venobox" data-gall="myGallery" href="img/portfolio/cryptoversal.png">-->
          <!--            <h4>Cryptoversal</h4>-->
          <!--            <span>Web Development</span>-->
          <!--          </a>-->
          <!--        </div>-->
          <!--      </div>-->
          <!--    </div>-->
          <!--  </div>-->
          <!--</div>-->
          <!-- single-awesome-project end -->
          <!-- single-awesome-project start -->
          <div class="col-md-4 col-sm-4 col-xs-12 design photo">
            <div class="single-awesome-project">
              <div class="awesome-img">
                <a href="#"><img src="img/portfolio/ideal-min-min.jpg" alt="" /></a>
                <div class="add-actions text-center">
                  <div class="project-dec">
                    <a class="venobox" data-gall="myGallery" href="http://idealtrotuar.ru/">
                      <h4>Ideal Tratuar</h4>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- single-awesome-project end -->
          <!-- single-awesome-project start -->
          <div class="col-md-4 col-sm-4 col-xs-12 design photo">
            <div class="single-awesome-project">
              <div class="awesome-img">
                <a href="#"><img src="img/portfolio/anau-min-min.jpg" alt="" /></a>
                <div class="add-actions text-center">
                  <div class="project-dec">
                    <!--<a class="venobox" data-gall="myGallery" href="img/portfolio/anau.png">-->
                    <!--  <h4>ANAU</h4>-->
                    <!--  <span>Photoshop</span>-->
                    <!--</a>-->
                    <a class="" data-gall="myGallery" href="http://anau.am/" target="_blank">
                      <h4>ANAU</h4>
                      <span>Photoshop</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- single-awesome-project end -->
          <!-- single-awesome-project start -->
          <div class="col-md-4 col-sm-4 col-xs-12 design photo">
            <div class="single-awesome-project">
              <div class="awesome-img">
                <a href="#"><img src="img/portfolio/lesbijoux-min-min.jpg" alt="" /></a>
                <div class="add-actions text-center">
                  <div class="project-dec">
                    <!--<a class="venobox" data-gall="myGallery" href="img/portfolio/lesbijoux.png">-->
                    <!--  <h4>Les Bijoux</h4>-->
                    <!--  <span>Photoshop</span>-->
                    <!--</a>-->
                    <a class="" data-gall="myGallery" href="http://lesbijoux.ru/" target="_blank">
                      <h4>Les Bijoux</h4>
                      <span>Photoshop</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
            <div class="col-md-4 col-sm-4 col-xs-12 design photo">
                <div class="single-awesome-project">
                    <div class="awesome-img">
                        <a href="#"><img src="img/portfolio/tntesakan-min.jpg" alt=""/></a>
                        <div class="add-actions text-center">
                            <div class="project-dec">
                                <a class="" data-gall="myGallery" href="http://tntesakan.am/" target="_blank">
                                    <h4>Tntesakan</h4>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-12 design photo">
                <div class="single-awesome-project">
                    <div class="awesome-img">
                        <a href="#"><img src="img/portfolio/tata.jpg" alt=""/></a>
                        <div class="add-actions text-center">
                            <div class="project-dec">
                                <a class="" data-gall="myGallery" href="http://tata-parikmakherski.ru/?fbclid=IwAR3_tpKjz3kJQMODd-PW8DA8Sh7bGh7LXkcZE-yxfU-ZEo7M2asbdxm-PdE" target="_blank">
                                    <h4>tata-parikmakherski</h4>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          <!-- single-awesome-project end -->
        </div>
      </div>
    </div>
  </div>

  <!-- awesome-portfolio end -->
  <!-- start pricing area -->
  <!--<div id="pricing" class="pricing-area area-padding">-->
    <!--<div class="container">-->
      <!--<div class="row">-->
        <!--<div class="col-md-12 col-sm-12 col-xs-12">-->
          <!--<div class="section-headline text-center">-->
            <!--<h2>Pricing Table</h2>-->
          <!--</div>-->
        <!--</div>-->
      <!--</div>-->
      <!--<div class="row">-->
        <!--<div class="col-md-4 col-sm-4 col-xs-12">-->
          <!--<div class="pri_table_list">-->
            <!--<h3>basic <br/> <span>$80 / month</span></h3>-->
            <!--<ol>-->
              <!--<li class="check">Online system</li>-->
              <!--<li class="check cross">Full access</li>-->
              <!--<li class="check">Free apps</li>-->
              <!--<li class="check">Multiple slider</li>-->
              <!--<li class="check cross">Free domin</li>-->
              <!--<li class="check cross">Support unlimited</li>-->
              <!--<li class="check">Payment online</li>-->
              <!--<li class="check cross">Cash back</li>-->
            <!--</ol>-->
            <!--<button>sign up now</button>-->
          <!--</div>-->
        <!--</div>-->
        <!--<div class="col-md-4 col-sm-4 col-xs-12">-->
          <!--<div class="pri_table_list active">-->
            <!--<span class="saleon">top sale</span>-->
            <!--<h3>standard <br/> <span>$110 / month</span></h3>-->
            <!--<ol>-->
              <!--<li class="check">Online system</li>-->
              <!--<li class="check">Full access</li>-->
              <!--<li class="check">Free apps</li>-->
              <!--<li class="check">Multiple slider</li>-->
              <!--<li class="check cross">Free domin</li>-->
              <!--<li class="check">Support unlimited</li>-->
              <!--<li class="check">Payment online</li>-->
              <!--<li class="check cross">Cash back</li>-->
            <!--</ol>-->
            <!--<button>sign up now</button>-->
          <!--</div>-->
        <!--</div>-->
        <!--<div class="col-md-4 col-sm-4 col-xs-12">-->
          <!--<div class="pri_table_list">-->
            <!--<h3>premium <br/> <span>$150 / month</span></h3>-->
            <!--<ol>-->
              <!--<li class="check">Online system</li>-->
              <!--<li class="check">Full access</li>-->
              <!--<li class="check">Free apps</li>-->
              <!--<li class="check">Multiple slider</li>-->
              <!--<li class="check">Free domin</li>-->
              <!--<li class="check">Support unlimited</li>-->
              <!--<li class="check">Payment online</li>-->
              <!--<li class="check">Cash back</li>-->
            <!--</ol>-->
            <!--<button>sign up now</button>-->
          <!--</div>-->
        <!--</div>-->
      <!--</div>-->
    <!--</div>-->
  <!--</div>-->
  <!-- End pricing table area -->
  <!-- Start Testimonials -->

  <div class="testimonials-area">
    <div class="testi-inner area-padding">
      <div class="testi-overly"></div>
      <div class="container ">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <!-- Start testimonials Start -->
            <div class="testimonial-content text-center">
              <!--<a class="quate" href="#"><i class="fa fa-quote-right"></i></a>-->
              <!-- start testimonial carousel -->
              <div class="testimonial-carousel">
               <!-- <div class="single-testi">
                  <div class="testi-text">
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed pulvinar luctus est eget congue.<br>consectetur adipiscing elit. Sed pulvinar luctus est eget congue.
                    </p>
                    <h6>Boby</h6>
                  </div>
                </div> -->
                <!-- End single item -->
              <!--  <div class="single-testi">
                  <div class="testi-text">
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed pulvinar luctus est eget congue.<br>consectetur adipiscing elit. Sed pulvinar luctus est eget congue.
                    </p>
                    <h6>Jhon</h6>
                  </div>
                </div> -->
                <!-- End single item -->
              <!--  <div class="single-testi">
                  <div class="testi-text">
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed pulvinar luctus est eget congue.<br>consectetur adipiscing elit. Sed pulvinar luctus est eget congue.
                    </p>
                    <h6>Fleming</h6>
                  </div>
                </div> -->
                <!-- End single item -->
              </div>
            </div>
            <!-- End testimonials end -->
          </div>
          <!-- End Right Feature -->
        </div>
      </div>
    </div>
  </div>

  <!-- End Testimonials -->
  <!-- Start Blog Area -->
  <!--<div id="blog" class="blog-area">-->
    <!--<div class="blog-inner area-padding">-->
      <!--<div class="blog-overly"></div>-->
      <!--<div class="container ">-->
        <!--<div class="row">-->
          <!--<div class="col-md-12 col-sm-12 col-xs-12">-->
            <!--<div class="section-headline text-center">-->
              <!--<h2>Latest News</h2>-->
            <!--</div>-->
          <!--</div>-->
        <!--</div>-->
        <!--<div class="row">-->
          <!--&lt;!&ndash; Start Left Blog &ndash;&gt;-->
          <!--<div class="col-md-4 col-sm-4 col-xs-12">-->
            <!--<div class="single-blog">-->
              <!--<div class="single-blog-img">-->
                <!--<a href="blog.html">-->
										<!--<img src="img/blog/1.jpg" alt="">-->
									<!--</a>-->
              <!--</div>-->
              <!--<div class="blog-meta">-->
                <!--<span class="comments-type">-->
										<!--<i class="fa fa-comment-o"></i>-->
										<!--<a href="#">13 comments</a>-->
									<!--</span>-->
                <!--<span class="date-type">-->
										<!--<i class="fa fa-calendar"></i>2016-03-05 / 09:10:16-->
									<!--</span>-->
              <!--</div>-->
              <!--<div class="blog-text">-->
                <!--<h4>-->
                                        <!--<a href="blog.html">Assumenda repud eum veniam</a>-->
									<!--</h4>-->
                <!--<p>-->
                  <!--Lorem ipsum dolor sit amet conse adipis elit Assumenda repud eum veniam optio modi sit explicabo nisi magnam quibusdam.sit amet conse adipis elit Assumenda repud eum veniam optio modi sit explicabo nisi magnam quibusdam.-->
                <!--</p>-->
              <!--</div>-->
              <!--<span>-->
									<!--<a href="blog.html" class="ready-btn">Read more</a>-->
								<!--</span>-->
            <!--</div>-->
            <!--&lt;!&ndash; Start single blog &ndash;&gt;-->
          <!--</div>-->
          <!--&lt;!&ndash; End Left Blog&ndash;&gt;-->
          <!--&lt;!&ndash; Start Left Blog &ndash;&gt;-->
          <!--<div class="col-md-4 col-sm-4 col-xs-12">-->
            <!--<div class="single-blog">-->
              <!--<div class="single-blog-img">-->
                <!--<a href="blog.html">-->
										<!--<img src="img/blog/2.jpg" alt="">-->
									<!--</a>-->
              <!--</div>-->
              <!--<div class="blog-meta">-->
                <!--<span class="comments-type">-->
										<!--<i class="fa fa-comment-o"></i>-->
										<!--<a href="#">130 comments</a>-->
									<!--</span>-->
                <!--<span class="date-type">-->
										<!--<i class="fa fa-calendar"></i>2016-03-05 / 09:10:16-->
									<!--</span>-->
              <!--</div>-->
              <!--<div class="blog-text">-->
                <!--<h4>-->
                                        <!--<a href="blog.html">Explicabo magnam quibusdam.</a>-->
									<!--</h4>-->
                <!--<p>-->
                  <!--Lorem ipsum dolor sit amet conse adipis elit Assumenda repud eum veniam optio modi sit explicabo nisi magnam quibusdam.sit amet conse adipis elit Assumenda repud eum veniam optio modi sit explicabo nisi magnam quibusdam.-->
                <!--</p>-->
              <!--</div>-->
              <!--<span>-->
									<!--<a href="blog.html" class="ready-btn">Read more</a>-->
								<!--</span>-->
            <!--</div>-->
            <!--&lt;!&ndash; Start single blog &ndash;&gt;-->
          <!--</div>-->
          <!--&lt;!&ndash; End Left Blog&ndash;&gt;-->
          <!--&lt;!&ndash; Start Right Blog&ndash;&gt;-->
          <!--<div class="col-md-4 col-sm-4 col-xs-12">-->
            <!--<div class="single-blog">-->
              <!--<div class="single-blog-img">-->
                <!--<a href="blog.html">-->
										<!--<img src="img/blog/3.jpg" alt="">-->
									<!--</a>-->
              <!--</div>-->
              <!--<div class="blog-meta">-->
                <!--<span class="comments-type">-->
										<!--<i class="fa fa-comment-o"></i>-->
										<!--<a href="#">10 comments</a>-->
									<!--</span>-->
                <!--<span class="date-type">-->
										<!--<i class="fa fa-calendar"></i>2016-03-05 / 09:10:16-->
									<!--</span>-->
              <!--</div>-->
              <!--<div class="blog-text">-->
                <!--<h4>-->
                                        <!--<a href="blog.html">Lorem ipsum dolor sit amet</a>-->
									<!--</h4>-->
                <!--<p>-->
                  <!--Lorem ipsum dolor sit amet conse adipis elit Assumenda repud eum veniam optio modi sit explicabo nisi magnam quibusdam.sit amet conse adipis elit Assumenda repud eum veniam optio modi sit explicabo nisi magnam quibusdam.-->
                <!--</p>-->
              <!--</div>-->
              <!--<span>-->
									<!--<a href="blog.html" class="ready-btn">Read more</a>-->
								<!--</span>-->
            <!--</div>-->
          <!--</div>-->
          <!--&lt;!&ndash; End Right Blog&ndash;&gt;-->
        <!--</div>-->
      <!--</div>-->
    <!--</div>-->
  <!--</div>-->
  <!-- End Blog -->
  <!-- Start Suscrive Area -->
  <!--<div class="suscribe-area">-->
    <!--<div class="container">-->
      <!--<div class="row">-->
        <!--<div class="col-lg-12 col-md-12 col-sm-12 col-xs=12">-->
          <!--<div class="suscribe-text text-center">-->
            <!--<h3>Welcome to our eBusiness company</h3>-->
            <!--<a class="sus-btn" href="#">Get A quate</a>-->
          <!--</div>-->
        <!--</div>-->
      <!--</div>-->
    <!--</div>-->
  <!--</div>-->
  <!-- End Suscrive Area -->
  <!-- Start contact Area -->
  <div id="contact" class="contact-area">
    <div class="contact-inner area-padding">
      <div class="contact-overly"></div>
      <div class="container ">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="section-headline text-center">
              <h2>Contact us</h2>
            </div>
          </div>
        </div>
        <div class="row">
          <!-- Start contact icon column -->
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="contact-icon text-center">
              <div class="single-icon">
                <i class="fa fa-mobile"></i>
                <p>
                  Call (Owner) : +374 77 78 97 86<br>
                  Call (Manager) : +7 915 023 88 00
                </p>
              </div>
            </div>
          </div>
          <!-- Start contact icon column -->
           <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="contact-icon text-center">
              <div class="single-icon">
                <i class="fa fa-envelope-o"></i>
                <p>
                  Email: info@wave-it.ru<br>
                  <span>Web: www.wave-it.ru</span>
                </p>
              </div>
            </div>
          </div>
          <!-- Start contact icon column -->
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="contact-icon text-center">
              <div class="single-icon">
                <i class="fa fa-map-marker"></i>
                <p>
                  Location: Hakob Hakobyan Street 3<br>
                  <span>Yerevan, Armenia</span>
                </p>
              </div>
            </div>
          </div>
        </div>
        <div class="row">

          <!-- Start Google Map -->
          <div class="col-md-6 col-sm-6 col-xs-12 location">
            <!-- Start Map -->
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3047.459778275848!2d44.4885341153893!3d40.19883437939109!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x406abd6beca25551%3A0x9192912c6f698e91!2s3+Hakob+Hakobyan+St%2C+Yerevan+0033!5e0!3m2!1sru!2s!4v1542179406201" style="border:0" allowfullscreen></iframe>
            <!--Google map-->
            <div id="map-container" class="z-depth-1-half map-container mb-5" >
                <!--<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3047.3832299675355!2d44.533456715545874!3d40.20053747939076!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x406abd2b1a589109%3A0x3b524ed217ab2cbb!2zMjMg1LTVodW-1avVqSDUsdW21bDVodWy1anVqyDWg9W41bLVuNaBLCDUtdaA1ofVodW2LCDVgNWh1bXVodW91b_VodW2!5e0!3m2!1shy!2s!4v1539942725022" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>-->
            </div>
            <!-- Uncomment below if you wan to use dynamic maps -->
            <!-- End Map -->
          </div>
          <!-- End Google Map -->

          <!-- Start  contact -->
          <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="form contact-form">

                <form action="<?php echo e(action('ContactController@store')); ?>" method="post" role="form" class="">
                  <?php echo e(csrf_field()); ?>

                  <div class="form-group">
                    <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                    <!-- <div class="validation"></div> -->
                  </div>
                  <div class="form-group">
                    <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" />
                    <!-- <div class="validation"></div> -->
                  </div>
                  <div class="form-group">
                    <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
                    <!-- <div class="validation"></div> -->
                  </div>
                  <div class="form-group">
                    <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
                    <!-- <div class="validation"></div> -->
                  </div>
                  <div class="text-center"><button type="submit">Send Message</button></div>
                </form>

              <!--<div id="sendmessage">Your message has been sent. Thank you!</div>-->
              <!--<div id="errormessage"></div>-->
              <!--<form action="myform.php" method="post" role="form" class="contactForm">-->
              <!--  <div class="form-group">-->
              <!--    <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />-->
              <!--    <div class="validation"></div>-->
              <!--  </div>-->
              <!--  <div class="form-group">-->
              <!--    <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" />-->
              <!--    <div class="validation"></div>-->
              <!--  </div>-->
              <!--  <div class="form-group">-->
              <!--    <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />-->
              <!--    <div class="validation"></div>-->
              <!--  </div>-->
              <!--  <div class="form-group">-->
              <!--    <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>-->
              <!--    <div class="validation"></div>-->
              <!--  </div>-->
              <!--  <div class="text-center"><button type="submit">Send Message</button></div>-->
              <!--</form>-->
            </div>
          </div>
          <!-- End Left contact -->
        </div>
      </div>
    </div>
  </div>
  <!-- End Contact Area -->

  <!-- Start Footer bottom Area -->
  <footer>
    <!--<div class="footer-area">-->
    <!--  <div class="container">-->
    <!--    <div class="row">-->
    <!--      <div class="col-md-4 col-sm-4 col-xs-12">-->
    <!--        <div class="footer-content">-->
    <!--          <div class="footer-head">-->
    <!--            <div class="footer-logo">-->
    <!--              <h2>Wave IT</h2>-->
    <!--            </div>-->
    <!--            <p></p>-->

    <!--          </div>-->
    <!--        </div>-->
    <!--      </div>-->
    <!--      <div class="col-md-4 col-md-offset-4 col-sm-4 col-sm-offset-4 col-xs-12">-->
    <!--        <div class="footer-content">-->
    <!--          <div class="footer-head">-->
    <!--            <h4>information</h4>-->
    <!--            <p>-->
    <!--              The price can always be negotiated. Excellent quality is guaranteed. All sites are exclusive.-->
    <!--              We use only unique developments and tools.-->
    <!--            </p>-->
    <!--            <div class="footer-contacts">-->
    <!--              <p><span>Tel:</span> +374 77 78 97 86</p>-->
    <!--              <p><span>Tel:</span> +7 915 023 88 00 </p>-->

    <!--              <p><span>Email:</span> waveitinbox@gmail.com</p>-->
    <!--              <p><span>Working Hours:</span> 10am-00pm</p>-->
    <!--            </div>-->
    <!--          </div>-->
    <!--        </div>-->
    <!--      </div>-->
    <!--    </div>-->
    <!--  </div>-->
    <!--</div>-->
    <div class="footer-area-bottom">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="footer-icons">
                  <ul>
                      <li>
                          <a href="https://www.facebook.com/Wave-It-180752426136908/" target="_blank"><i class="fa fa-facebook"></i></a>
                      </li>
                      <li>
                          <a href="https://www.instagram.com/wave_it.ru/?hl=ru" target="_blank"><i class="fa fa-instagram"></i></a>
                      </li>
                      <li>
                          <a href="#" target="_blank"><i class="fa fa-google"></i></a>
                      </li>
                      <li>
                          <a href="https://vk.com/it_wave_it" target="_blank"><i class="fa fa-vk"></i></a>
                      </li>
                  </ul>
              </div>
            <div class="copyright text-center">
              <p>
                &copy;2018 Company<strong> <a href="#">Wave IT</a> </strong>
              </p>
            </div>
            <div class="credits">
              <!--
                All the links in the footer should remain intact.
                You can delete the links only if you purchased the pro version.
                Licensing information: https://bootstrapmade.com/license/
                Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=eBusiness
              -->

            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

      <!-- JavaScript Libraries -->
     <!--Start of Tawk.to Script-->
    <script type="text/javascript">
    var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
    (function(){
    var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
    s1.async=true;
    s1.src='https://embed.tawk.to/5bfa83cc40105007f3797c5e/default';
    s1.charset='UTF-8';
    s1.setAttribute('crossorigin','*');
    s0.parentNode.insertBefore(s1,s0);
    })();
    </script>
    <!--End of Tawk.to Script-->
    <!--End of Tawk.to Script-->

  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/venobox/venobox.min.js"></script>
  <script src="lib/knob/jquery.knob.js"></script>
  <script type="text/javascript" src="js/swiper.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/parallax/parallax.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/nivo-slider/js/jquery.nivo.slider.js"></script>
  <script src="lib/appear/jquery.appear.js"></script>
  <script src="lib/isotope/isotope.pkgd.min.js"></script>
  <!-- MDB core JavaScript -->
  <script src="js/mdb.js"></script>
  <!-- Uncomment below if you want to use dynamic Google Maps -->
  <script src="https://maps.google.com/maps/api/js"></script>
   <!--<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD8HeI8o-c1NppZA-92oYlXakhDPYR7XMY"></script>-->

  <!-- Contact Form JavaScript File -->
  <!-- <script src="contactform/contactform.js"></script> -->
  <script type="text/javascript">

      var aboutScrollLeft = document.getElementById('aboutScrollLeft');
      var aboutScrollRigth = document.getElementById('aboutScrollRigth');
      var servicesScrollLeft = document.getElementById('servicesScrollLeft');
      var servicesScrollRight = document.getElementById('servicesScrollRight');

      aboutScrollLeft.style.opacity = '0';
      aboutScrollLeft.style.paddingTop = '80px';
      aboutScrollLeft.style.paddingLeft = '40px';

      aboutScrollRigth.style.opacity = '0';
      aboutScrollRigth.style.paddingTop = '80px';
      aboutScrollRigth.style.paddingLeft = '40px';

      servicesScrollLeft.style.opacity = '0';
      servicesScrollLeft.style.paddingTop = '80px';
      servicesScrollLeft.style.paddingLeft = '40px';

      servicesScrollRight.style.opacity = '0';
      servicesScrollRight.style.paddingTop = '80px';
      servicesScrollRight.style.paddingLeft = '40px';

  function about_scroll(){
      var aboutImg = document.getElementById('aboutScrollLeft');
      var aboutMaintenance = document.getElementById('aboutScrollRigth');
      var ypos = window.pageYOffset;
      if(ypos > 250){
          aboutImg.style.opacity = '1';
          aboutImg.style.paddingTop  = '0';
          aboutImg.style.paddingLeft  = '0';
          aboutImg.style.transitionDuration = '0.5s';
          aboutMaintenance.style.opacity = '1';
          aboutMaintenance.style.paddingTop  = '0';
          aboutMaintenance.style.paddingLeft  = '0';
          aboutMaintenance.style.transitionDuration = '0.5s';
      }
      // else {
      //     aboutImg.style.opacity = '0';
      //     aboutImg.style.paddingTop  = '50px';
      //     aboutImg.style.paddingLeft  = '30px';
      //     aboutImg.style.transitionDuration = '0.2s';
      //     aboutMaintenance.style.opacity = '0';
      //     aboutMaintenance.style.paddingTop  = '50px';
      //     aboutMaintenance.style.paddingLeft  = '30px';
      //     aboutMaintenance.style.transitionDuration = '0.2s';
      // }
  }
  window.addEventListener("scroll", about_scroll);
  
  function service_scroll(){
      var servicesLeft = document.getElementById('servicesScrollLeft');
      var servicesRight = document.getElementById('servicesScrollRight');
      var yposs = window.pageYOffset;
      if(yposs > 850){
          servicesLeft.style.opacity = '1';
          servicesLeft.style.paddingTop  = '0';
          servicesLeft.style.paddingLeft  = '0';
          servicesLeft.style.transitionDuration = '0.5s';
          servicesRight.style.opacity = '1';
          servicesRight.style.paddingTop  = '0';
          servicesRight.style.paddingLeft  = '0';
          servicesRight.style.transitionDuration = '0.s';
      }
      // else {
      //     servicesLeft.style.opacity = '0';
      //     servicesLeft.style.paddingTop  = '50px';
      //     servicesLeft.style.paddingLeft  = '30px';
      //     servicesLeft.style.transitionDuration = '0.2s';
      //     servicesRight.style.opacity = '0';
      //     servicesRight.style.paddingTop  = '50px';
      //     servicesRight.style.paddingLeft  = '30px';
      //     servicesRight.style.transitionDuration = '0.2s';
      // }
  }
  window.addEventListener("scroll", service_scroll);

  </script>
  <script src="js/main.js"></script>
</body>

</html>
