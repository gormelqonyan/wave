<!-- Favicons -->
<link href="<?php echo e(asset('img/favicon.png')); ?>" rel="icon">
<link href="<?php echo e(asset('img/apple-touch-icon.png')); ?>" rel="apple-touch-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700|Raleway:300,400,400i,500,500i,700,800,900"
      rel="stylesheet">

<!-- Bootstrap CSS File -->
<link href="<?php echo e(asset('lib/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

<!-- Libraries CSS Files -->
<link href="<?php echo e(asset('lib/nivo-slider/css/nivo-slider.css')); ?>" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/swiper.min.css')); ?>">
<link href="<?php echo e(asset('lib/owlcarousel/owl.carousel.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('lib/owlcarousel/owl.transitions.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('lib/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('lib/animate/animate.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('lib/venobox/venobox.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/simpleLightbox.css')); ?>" rel="stylesheet">

<!-- Nivo Slider Theme -->
<link href="<?php echo e(asset('css/nivo-slider-theme.css')); ?>" rel="stylesheet">

<!-- Main Stylesheet File -->
<link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">

<!-- Responsive Stylesheet File -->
<link href="<?php echo e(asset('css/responsive.css')); ?>" rel="stylesheet">
