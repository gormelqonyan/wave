<?php $__env->startSection('admin_content'); ?>
<a href="<?php echo e(action('ContactController@index')); ?>"><h5>Հաղորդագրություններ</h5></a>
<br>
<?php if(count($contacts) > 0): ?>
    <table class="table table-striped">
        <tr>
            <!-- <th>No</th> -->
            <th>Անուն, Ազգանուն</th>
            <th>Էլ․ հասցե</th>
            <th>Հաղորդագրություն</th>
            <th>Հիշել</th>
            <th></th>
            <th></th>
        </tr>
        <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($contact->name); ?></td>
                <td><?php echo e($contact->email); ?></td>
                <td><?php echo e($contact->message); ?></td>
                <td>
                  <input type="checkbox" class="rem" name="rem" data-id="<?php echo e($contact->id); ?>" value="<?php echo e($contact->rem); ?>"/>
                </td>
                <td><a href="<?php echo e(action('ContactController@show', $contact->id)); ?>" class="btn btn-default">Տեսնել</a></td>
                <td>
                    <?php echo Form::open(['action' => ['ContactController@destroy', $contact->id], 'method' => 'POST', 'class' => 'pull-right', 'onclick'=>'return confirm("Դուք համոզվա՞ծ եք։")']); ?>

                        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                        <?php echo e(Form::submit('Ջնջել', ['class' => 'btn btn-danger'])); ?>

                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php else: ?>
 <p>Ոչ մի հաղորդագրություն</p>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>