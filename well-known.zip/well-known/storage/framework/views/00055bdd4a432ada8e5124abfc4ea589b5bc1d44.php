

<?php $__env->startSection('content'); ?>



<!-- Start About area -->
<div id="about" class="about-area area-padding sectionMargin">
    <div class="container" style="sectionMargin">
        <div class="row">

            <div class="col-md-12 col-sm-12 col-xs-12 text-center">
                <div class="section-headline text-center">
                    <h2>Error 404</h2>
                </div>
                <p>
                   Sorry, the page you are looking for could not be found.
                </p>
                <a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('global.Home'); ?></a>
            </div>
        </div>

        </div>
    </div>
</div>
<!-- End About area -->





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>