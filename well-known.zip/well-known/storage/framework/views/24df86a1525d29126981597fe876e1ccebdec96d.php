<?php $__env->startSection('content'); ?>
<section class="courses-1">
	<div class="container">	
		<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('global.Home'); ?></a>
    </li>
    <li class="breadcrumb-item active">Վեբ ծրագրավորման դասընթացներ</li>
</ol>
		<div class="row courses-r-margin-bottom">
			<div class="col-sm-4 single-courses-box">
			    <div class="single-courses">
					<figure>
						<div class="figure-img"><img src="/lessons/images/courses-01.png" alt="html bootstrap դասընթացներ" class="img-responsive"></div>
						<figcaption>
							<div><a href="<?php echo e(route('html')); ?>" class="read_more-btn">Տեսնել դասերը</a></div>
						</figcaption>
					</figure>
					<div class="courses-content-box">
						<div class="courses-content">
							<h3><a href="<?php echo e(route('html')); ?>">HTML & CSS & Bootstrap</a></h3>
							<div class="rank-icons">
								
							</div>	
						</div>
					</div>
				</div>
			</div>
			<div class="col-sm-4 single-courses-box">
			    <div class="single-courses">
					<figure>
						<div class="figure-img"><img src="/lessons/images/courses-02.jpg" alt="վեբ ծրագրավորման դասընթացներ" class="img-responsive"></div>
						<figcaption>
							<div><a href="<?php echo e(route('js')); ?>" class="read_more-btn">Տեսնել դասերը</a></div>
						</figcaption>
					</figure>
					<div class="courses-content-box">
						<div class="courses-content">
							<h3><a href="<?php echo e(route('js')); ?>">JavaScript & Jquery & Ajax</a></h3>
							<div class="rank-icons">
								
							</div>	
						</div>
					</div>
				</div>
			</div>
			<div class="col-sm-4 single-courses-box">
			    <div class="single-courses">
					<figure>
						<div class="figure-img"><img src="/lessons/images/courses-03.png" alt="php դասընթացներ" class="img-responsive"></div>
						<figcaption>
							<div><a href="<?php echo e(route('php')); ?>" class="read_more-btn">Տեսնել դասերը</a></div>
						</figcaption>
					</figure>
					<div class="courses-content-box">
						<div class="courses-content">
							<h3><a href="<?php echo e(route('php')); ?>">PHP MySQL</a></h3>
							<div class="rank-icons">
								
							</div>	
						</div>
					</div>
				</div>
			</div>
		</div>

	</div>
	</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base1', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>