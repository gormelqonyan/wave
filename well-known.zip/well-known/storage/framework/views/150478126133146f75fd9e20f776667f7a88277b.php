<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
<title>Մեր պատրաստած կայքերը, լոգոները | Wave-it.ru</title>
	<meta content="web կայքեր մատչելի գներով, web կայքերի պատրաստում  և սպասարկում, web կայքերի նախագծում և դիզայն" name="keywords">
	<meta content="Մեր պատրաստած կայքերը, լոգոները | Wave-it.ru" name="title">
	<meta content="Մենք պատրաստել ենք վեբ կայքեր, լոգոներ, ֆլեշ բաններներ Հայաստանյան և արտերկրյա գործընկերների համար ☎374(95)789-786" name="description">


    <!--<meta content="разработчик, Развитие бизнеса, сайты, интернет-магазины, порталы, лэндинги, разработка сайтов,  продвижение в интернете, SEO – продвижение" name="keywords">
    <meta content="Нужен эксклюзивный сайт, интернет-магазин, блог или лендинг? Наша команда IT-специалистов Wave IT с удовольствием поможет Вам!
Мы разработаем уникальный дизайн для вашего сайта и сверстаем его, используя такие технологии, как HTML5, CSS3, Java Script + jQuery, PHP и базы данных MySQL. Далее последует оптимизация для различных устройств и продвижение вашего сайта в интернете на первый строки поисковых систем - эти действия принесут много лидов (заинтересованных людей) для вашей компании. Приятный бонус: вы всегда можете наблюдать онлайн за выполнением нашей работы и получать ежемесячную отчетность в Личном кабинете." name="description">
	
	<meta content="վեբ կայքերի պատրաստում, վեբ կայքերի սպասարկում, վեբ դիզայն,վեբ ծրագրավորում" name="keywords">
	<meta content="Wave-IT ընկերության որակավորված մասնագետներն իրականացնում են վեբ կայքերի պատրաստում և սպասարկում, վեբ դիզայն, SEO, SMM մարքեթինգ ☎374(95)789-786
" name="description">-->

   <style>
        .carousel {
            /*max-height: 650px !important;*/
            width: 100% !important;
        }
    </style>
    <!-- Favicons -->
    <link href="<?php echo e(asset('img/favicon.png')); ?>" rel="icon">

    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700|Raleway:300,400,400i,500,500i,700,800,900"
          rel="stylesheet">
    
    <!-- Bootstrap CSS File -->
    <link href="<?php echo e(asset('lib/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    
    <!-- Libraries CSS Files -->
    <link href="<?php echo e(asset('lib/nivo-slider/css/nivo-slider.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/swiper.min.css')); ?>">
    <link href="<?php echo e(asset('lib/owlcarousel/owl.carousel.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('lib/owlcarousel/owl.transitions.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('lib/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('lib/animate/animate.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('lib/venobox/venobox.css')); ?>" rel="stylesheet">

    <!-- Nivo Slider Theme -->
    <link href="<?php echo e(asset('css/nivo-slider-theme.css')); ?>" rel="stylesheet">
    
    <!-- Main Stylesheet File -->
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/snowflake.css')); ?>" rel="stylesheet">
    <!-- Responsive Stylesheet File -->
    <link href="<?php echo e(asset('css/responsive.css')); ?>" rel="stylesheet">
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-134131256-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-134131256-1');
</script>

</head>

<body data-spy="scroll" data-target="#navbar-example">

<!--<div id="preloader"></div>-->

<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php echo $__env->yieldContent('content'); ?>

<?php if(!request()->is('/')): ?>
<div class="testimonials-area">
    <div class="testi-inner area-padding">
        <div class="testi-overly"></div>
        <div class="container ">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <!-- Start testimonials Start -->
                    <div class="testimonial-content text-center">
                        <!--<a class="quate" href="#"><i class="fa fa-quote-right"></i></a>-->
                        <!-- start testimonial carousel -->
                        <div class="testimonial-carousel">
                            <!-- <div class="single-testi">
                               <div class="testi-text">
                                 <p>
                                   Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed pulvinar luctus est eget congue.<br>consectetur adipiscing elit. Sed pulvinar luctus est eget congue.
                                 </p>
                                 <h6>Boby</h6>
                               </div>
                             </div> -->
                            <!-- End single item -->
                            <!--  <div class="single-testi">
                                <div class="testi-text">
                                  <p>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed pulvinar luctus est eget congue.<br>consectetur adipiscing elit. Sed pulvinar luctus est eget congue.
                                  </p>
                                  <h6>Jhon</h6>
                                </div>
                              </div> -->
                            <!-- End single item -->
                            <!--  <div class="single-testi">
                                <div class="testi-text">
                                  <p>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed pulvinar luctus est eget congue.<br>consectetur adipiscing elit. Sed pulvinar luctus est eget congue.
                                  </p>
                                  <h6>Fleming</h6>
                                </div>
                              </div> -->
                            <!-- End single item -->
                        </div>
                    </div>
                    <!-- End testimonials end -->
                </div>
                <!-- End Right Feature -->
            </div>
        </div>
    </div>
</div>
<?php endif; ?>


<!-- End Testimonials -->
<!-- Start Blog Area -->
<!--<div id="blog" class="blog-area">-->
<!--<div class="blog-inner area-padding">-->
<!--<div class="blog-overly"></div>-->
<!--<div class="container ">-->
<!--<div class="row">-->
<!--<div class="col-md-12 col-sm-12 col-xs-12">-->
<!--<div class="section-headline text-center">-->
<!--<h2>Latest News</h2>-->
<!--</div>-->
<!--</div>-->
<!--</div>-->
<!--<div class="row">-->
<!--&lt;!&ndash; Start Left Blog &ndash;&gt;-->
<!--<div class="col-md-4 col-sm-4 col-xs-12">-->
<!--<div class="single-blog">-->
<!--<div class="single-blog-img">-->
<!--<a href="blog.html">-->
<!--<img src="img/blog/1.jpg" alt="">-->
<!--</a>-->
<!--</div>-->
<!--<div class="blog-meta">-->
<!--<span class="comments-type">-->
<!--<i class="fa fa-comment-o"></i>-->
<!--<a href="#">13 comments</a>-->
<!--</span>-->
<!--<span class="date-type">-->
<!--<i class="fa fa-calendar"></i>2016-03-05 / 09:10:16-->
<!--</span>-->
<!--</div>-->
<!--<div class="blog-text">-->
<!--<h4>-->
<!--<a href="blog.html">Assumenda repud eum veniam</a>-->
<!--</h4>-->
<!--<p>-->
<!--Lorem ipsum dolor sit amet conse adipis elit Assumenda repud eum veniam optio modi sit explicabo nisi magnam quibusdam.sit amet conse adipis elit Assumenda repud eum veniam optio modi sit explicabo nisi magnam quibusdam.-->
<!--</p>-->
<!--</div>-->
<!--<span>-->
<!--<a href="blog.html" class="ready-btn">Read more</a>-->
<!--</span>-->
<!--</div>-->
<!--&lt;!&ndash; Start single blog &ndash;&gt;-->
<!--</div>-->
<!--&lt;!&ndash; End Left Blog&ndash;&gt;-->
<!--&lt;!&ndash; Start Left Blog &ndash;&gt;-->
<!--<div class="col-md-4 col-sm-4 col-xs-12">-->
<!--<div class="single-blog">-->
<!--<div class="single-blog-img">-->
<!--<a href="blog.html">-->
<!--<img src="img/blog/2.jpg" alt="">-->
<!--</a>-->
<!--</div>-->
<!--<div class="blog-meta">-->
<!--<span class="comments-type">-->
<!--<i class="fa fa-comment-o"></i>-->
<!--<a href="#">130 comments</a>-->
<!--</span>-->
<!--<span class="date-type">-->
<!--<i class="fa fa-calendar"></i>2016-03-05 / 09:10:16-->
<!--</span>-->
<!--</div>-->
<!--<div class="blog-text">-->
<!--<h4>-->
<!--<a href="blog.html">Explicabo magnam quibusdam.</a>-->
<!--</h4>-->
<!--<p>-->
<!--Lorem ipsum dolor sit amet conse adipis elit Assumenda repud eum veniam optio modi sit explicabo nisi magnam quibusdam.sit amet conse adipis elit Assumenda repud eum veniam optio modi sit explicabo nisi magnam quibusdam.-->
<!--</p>-->
<!--</div>-->
<!--<span>-->
<!--<a href="blog.html" class="ready-btn">Read more</a>-->
<!--</span>-->
<!--</div>-->
<!--&lt;!&ndash; Start single blog &ndash;&gt;-->
<!--</div>-->
<!--&lt;!&ndash; End Left Blog&ndash;&gt;-->
<!--&lt;!&ndash; Start Right Blog&ndash;&gt;-->
<!--<div class="col-md-4 col-sm-4 col-xs-12">-->
<!--<div class="single-blog">-->
<!--<div class="single-blog-img">-->
<!--<a href="blog.html">-->
<!--<img src="img/blog/3.jpg" alt="">-->
<!--</a>-->
<!--</div>-->
<!--<div class="blog-meta">-->
<!--<span class="comments-type">-->
<!--<i class="fa fa-comment-o"></i>-->
<!--<a href="#">10 comments</a>-->
<!--</span>-->
<!--<span class="date-type">-->
<!--<i class="fa fa-calendar"></i>2016-03-05 / 09:10:16-->
<!--</span>-->
<!--</div>-->
<!--<div class="blog-text">-->
<!--<h4>-->
<!--<a href="blog.html">Lorem ipsum dolor sit amet</a>-->
<!--</h4>-->
<!--<p>-->
<!--Lorem ipsum dolor sit amet conse adipis elit Assumenda repud eum veniam optio modi sit explicabo nisi magnam quibusdam.sit amet conse adipis elit Assumenda repud eum veniam optio modi sit explicabo nisi magnam quibusdam.-->
<!--</p>-->
<!--</div>-->
<!--<span>-->
<!--<a href="blog.html" class="ready-btn">Read more</a>-->
<!--</span>-->
<!--</div>-->
<!--</div>-->
<!--&lt;!&ndash; End Right Blog&ndash;&gt;-->
<!--</div>-->
<!--</div>-->
<!--</div>-->
<!--</div>-->
<!-- End Blog -->
<!-- Start Suscrive Area -->
<!--<div class="suscribe-area">-->
<!--<div class="container">-->
<!--<div class="row">-->
<!--<div class="col-lg-12 col-md-12 col-sm-12 col-xs=12">-->
<!--<div class="suscribe-text text-center">-->
<!--<h3>Welcome to our eBusiness company</h3>-->
<!--<a class="sus-btn" href="#">Get A quate</a>-->
<!--</div>-->
<!--</div>-->
<!--</div>-->
<!--</div>-->
<!--</div>-->
<!-- End Suscrive Area -->
<!-- Start contact Area -->


<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--Start of Tawk.to Script-->

<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5bfa83cc40105007f3797c5e/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>


<!--End of Tawk.to Script-->

<script src="<?php echo e(asset('lib/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('lib/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('lib/owlcarousel/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('lib/venobox/venobox.min.js')); ?>"></script>
<script src="<?php echo e(asset('lib/knob/jquery.knob.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/swiper.min.js')); ?>"></script>
<script src="<?php echo e(asset('lib/wow/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('lib/parallax/parallax.js')); ?>"></script>
<script src="<?php echo e(asset('lib/easing/easing.min.js')); ?>"></script>
<script src="<?php echo e(asset('lib/nivo-slider/js/jquery.nivo.slider.js')); ?>"></script>
<script src="<?php echo e(asset('lib/appear/jquery.appear.js')); ?>"></script>
<script src="<?php echo e(asset('lib/isotope/isotope.pkgd.min.js')); ?>"></script>


<!-- MDB core JavaScript -->
<!--<script src="<?php echo e(asset('js/mdb.js')); ?>"></script>-->
<!-- Uncomment below if you want to use dynamic Google Maps -->
<!--<script src="https://maps.google.com/maps/api/js"></script>-->
<!--<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD8HeI8o-c1NppZA-92oYlXakhDPYR7XMY"></script>-->

<!-- Contact Form JavaScript File -->
<!-- <script src="<?php echo e(asset('contactform/contactform.js')); ?>"></script> -->

<script src="<?php echo e(asset('js/main.js')); ?>"></script>

<?php echo $__env->yieldContent('altlinks'); ?>
</body>

</html>
