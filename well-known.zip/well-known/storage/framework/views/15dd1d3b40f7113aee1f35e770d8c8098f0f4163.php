<?php $__env->startSection('content'); ?>

    <div class="sectionMargin row">
        <?php echo $__env->make('errors/validation_error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>

        <div class="reg-form">
            <form action="<?php echo e(route('order.index')); ?>" method="post" role="form" class="reg">
                <?php echo e(csrf_field()); ?>


                <h1><?php echo app('translator')->getFromJson('global.General_inform'); ?></h1>

                <div class="form-group">
                    <label><?php echo app('translator')->getFromJson('global.Your_name'); ?></label><br>
                    <input type="text" name="name" class="form-control" id="name"
                           placeholder="<?php echo app('translator')->getFromJson('global.Your_name'); ?>"
                           data-rule="minlen:4" data-msg="Please enter at least 4 chars" required />
                </div>

                <div class="form-group">
                    <label><?php echo app('translator')->getFromJson('global.Your_email'); ?></label><br>
                    <input type="email" class="form-control" name="mail" id="email"
                           placeholder="<?php echo app('translator')->getFromJson('global.Your_email'); ?>" data-rule="email"
                           data-msg="Please enter a valid email" required/>
                </div>

                <div class="form-group">
                    <label><?php echo app('translator')->getFromJson('global.Glb_phon'); ?></label><br>
                    <input type="text" class="form-control" name="phone" id="phone"
                           placeholder="<?php echo app('translator')->getFromJson('global.Glb_phon'); ?>"
                           data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" required/>
                </div>

                <div class="form-group">
                    <label><?php echo app('translator')->getFromJson('global.Company_name'); ?></label><br>
                    <input type="text" name="company_name" class="form-control" id="name"/>
                </div>


                <div class="form-group">
                    <label><?php echo app('translator')->getFromJson('global.Work_areas'); ?></label><br>
                    <span><?php echo app('translator')->getFromJson('global.Work_areascontent'); ?></span>
                    <input type="text" name="business" class="form-control" id="workarea" />
                </div>

                <h1><?php echo app('translator')->getFromJson('global.Site_design'); ?></h1>

                <div class="form-group">
                    <label><?php echo app('translator')->getFromJson('global.Examp_likedesign'); ?></label><br>
                    <span><?php echo app('translator')->getFromJson('global.Ardess_likedesign'); ?></span>
                    <input type="text" name="design" class="form-control" id="name"/>
                </div>


                <h1><?php echo app('translator')->getFromJson('global.Site_function'); ?></h1>


                <div class="form-group">
                    <label><?php echo app('translator')->getFromJson('global.Type_site'); ?></label><br>
                    <span><?php echo app('translator')->getFromJson('global.Choose_site'); ?></span><br>

                    <input type="radio" name="type"
                           value="<?php echo app('translator')->getFromJson('global.Corpor_site'); ?>"><label><?php echo app('translator')->getFromJson('global.Corpor_site'); ?></label> <br>
                    <input type="radio" name="type"
                           value="<?php echo app('translator')->getFromJson('global.Corpor_catalog'); ?>"><label><?php echo app('translator')->getFromJson('global.Corpor_catalog'); ?></label> <br>
                    <input type="radio" name="type"
                           value="<?php echo app('translator')->getFromJson('global.Shop_online'); ?>"><label><?php echo app('translator')->getFromJson('global.Shop_online'); ?></label> <br>
                    <input type="radio" name="type"
                           value="<?php echo app('translator')->getFromJson('global.Lending'); ?>"><label><?php echo app('translator')->getFromJson('global.Lending'); ?></label> <br>
                    <input type="radio" name="type" value="<?php echo app('translator')->getFromJson('global.Other'); ?>"><label><?php echo app('translator')->getFromJson('global.Other'); ?>
                    </label>
                    <br>
                </div>

                <div class="form-group">
                    <label><?php echo app('translator')->getFromJson('global.Sales_serv'); ?></label><br>
                    <span><?php echo app('translator')->getFromJson('global.Network_sales'); ?></span><br>
                    <input type="checkbox" name="functions[]" id="name" value="<?php echo app('translator')->getFromJson('global.Categories'); ?>"/><label><?php echo app('translator')->getFromJson('global.Categories'); ?></label> <br>
                    <input type="checkbox" name="functions[]" id="name" value="<?php echo app('translator')->getFromJson('global.Pr_filter'); ?>"/>
                    <label><?php echo app('translator')->getFromJson('global.Pr_filter'); ?></label> <br>
                    <input type="checkbox" name="functions[]" id="name" value="<?php echo app('translator')->getFromJson('global.Extend_descr'); ?>"/><label><?php echo app('translator')->getFromJson('global.Extend_descr'); ?></label> <br>
                    <input type="checkbox" name="functions[]" id="name" value="<?php echo app('translator')->getFromJson('global.Basket'); ?>"/>
                    <label><?php echo app('translator')->getFromJson('global.Basket'); ?></label> <br>
                    <input type="checkbox" name="functions[]" id="name" value="<?php echo app('translator')->getFromJson('global.Discnt_calcul'); ?>"/><label><?php echo app('translator')->getFromJson('global.Discnt_calcul'); ?></label> <br>
                    <input type="checkbox" name="functions[]" id="name" value="<?php echo app('translator')->getFromJson('global.Cost_delivery'); ?>"/><label><?php echo app('translator')->getFromJson('global.Cost_delivery'); ?></label> <br>
                    <input type="checkbox" name="functions[]" id="name" value="<?php echo app('translator')->getFromJson('global.Online_pay'); ?>"/>
                    <label><?php echo app('translator')->getFromJson('global.Online_pay'); ?></label> <br>
                    <br>
                </div>

                <div class="form-group">
                    <label><?php echo app('translator')->getFromJson('global.Integr_servpr'); ?></label><br>
                    <span><?php echo app('translator')->getFromJson('global.Spec_servintegr'); ?></span><br>
                    <input type="checkbox" name="side_services[]" id="name" value="<?php echo app('translator')->getFromJson('global.Importprc_excel'); ?>"/><label><?php echo app('translator')->getFromJson('global.Importprc_excel'); ?></label> <br>
                    <input type="checkbox" name="side_services[]" id="name" value="<?php echo app('translator')->getFromJson('global.Integr_c1'); ?>"/><label><?php echo app('translator')->getFromJson('global.Integr_c1'); ?></label> <br>
                    <input type="checkbox" name="side_services[]" id="name" value="<?php echo app('translator')->getFromJson('global.Integr_corpdata'); ?>"/><label><?php echo app('translator')->getFromJson('global.Integr_corpdata'); ?></label> <br>
                    <br>
                </div>

                <div class="form-group">
                    <label><?php echo app('translator')->getFromJson('global.Lang_site'); ?></label><br>
                    <span><?php echo app('translator')->getFromJson('global.Lang_translate'); ?></span>
                    <input type="text" name="lang" class="form-control" id="name"/>
                </div>

                <div class="form-group">
                    <label><?php echo app('translator')->getFromJson('global.Other_purposes'); ?></label><br>
                    <span><?php echo app('translator')->getFromJson('global.Օther_serv'); ?></span>
                    <input type="text" name="other" class="form-control" id="name"/>
                </div>

                <h1><?php echo app('translator')->getFromJson('global.Site_struct'); ?></h1>

                <div class="form-group">
                    <label><?php echo app('translator')->getFromJson('global.Site_section'); ?></label><br>
                    <span><?php echo app('translator')->getFromJson('global.Desc_mainsect'); ?></span>
                    <input type="text" name="sections" class="form-control" id="name"/>
                </div>
                <div class="form-group">
                    <label><?php echo app('translator')->getFromJson('global.Site_navig'); ?></label><br>
                    <span><?php echo app('translator')->getFromJson('global.Menus_present'); ?></span>
                    <input type="text" name="navigation" class="form-control" id="name"/>
                </div>
                <div class="form-group">
                    <label><?php echo app('translator')->getFromJson('global.Inform_blocks'); ?></label><br>
                    <span><?php echo app('translator')->getFromJson('global.Present_pages'); ?></span>
                    <input type="text" name="information_blocks" class="form-control" id="name"/>
                </div>

                <div class="form-group">
                    <label><?php echo app('translator')->getFromJson('global.Design_require'); ?></label><br>
                    <span><?php echo app('translator')->getFromJson('global.Descr_require'); ?></span>
                    <input type="text" name="desires" class="form-control" id="name"/>
                </div>

                <h1><?php echo app('translator')->getFromJson('global.Cont_serv'); ?></h1>

                <div class="form-group">
                    <label><?php echo app('translator')->getFromJson('global.Cont_site'); ?></label><br>
                    <input type="radio" name="conten"
                           value="<?php echo app('translator')->getFromJson('global.Alr_ready'); ?>"><label><?php echo app('translator')->getFromJson('global.Alr_ready'); ?></label> <br>
                    <input type="radio" name="conten"
                           value="<?php echo app('translator')->getFromJson('global.Ser_writer'); ?>"><label><?php echo app('translator')->getFromJson('global.Ser_writer'); ?></label> <br>
                    <input type="radio" name="conten"
                           value="<?php echo app('translator')->getFromJson('global.Ph_required'); ?>"><label><?php echo app('translator')->getFromJson('global.Ph_required'); ?></label> <br>
                    <input type="radio" name="conten" id="name" value="<?php echo app('translator')->getFromJson('global.Tr_need'); ?>"/><label><?php echo app('translator')->getFromJson('global.Tr_need'); ?></label> <br>
                </div>

                <div class="form-group">
                    <label><?php echo app('translator')->getFromJson('global.Addit_serv'); ?></label><br>
                    <input type="checkbox" name="additional_services[]" id="name" value="<?php echo app('translator')->getFromJson('global.Fill_cont'); ?>"/><label><?php echo app('translator')->getFromJson('global.Fill_cont'); ?></label> <br>
                    <input type="checkbox" name="additional_services[]" id="name" value="<?php echo app('translator')->getFromJson('global.Tech_supp'); ?>"/><label><?php echo app('translator')->getFromJson('global.Tech_supp'); ?></label> <br>
                    <input type="checkbox" name="additional_services[]" id="name" value="<?php echo app('translator')->getFromJson('global.Site_maint'); ?>"/><label><?php echo app('translator')->getFromJson('global.Site_maint'); ?></label> <br>
                    <input type="checkbox" name="additional_services[]" id="name" value="<?php echo app('translator')->getFromJson('global.Context_advert'); ?>"/><label><?php echo app('translator')->getFromJson('global.Context_advert'); ?></label> <br>
                    <input type="checkbox" name="additional_services[]" id="name" value="<?php echo app('translator')->getFromJson('global.SEO_prom'); ?>"/><label><?php echo app('translator')->getFromJson('global.SEO_prom'); ?></label> <br>
                    <input type="checkbox" name="additional_services[]" id="name" value="<?php echo app('translator')->getFromJson('global.Corp_ident'); ?>"/><label><?php echo app('translator')->getFromJson('global.Corp_ident'); ?></label> <br>
                    <input type="checkbox" name="additional_services[]" id="name" value="<?php echo app('translator')->getFromJson('global.Logo_develop'); ?>"/><label><?php echo app('translator')->getFromJson('global.Logo_develop'); ?></label> <br>
                </div>
                <div class="text-center">
                    <input type="submit" class="btn-order" value="<?php echo app('translator')->getFromJson('global.Send'); ?>">
                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>