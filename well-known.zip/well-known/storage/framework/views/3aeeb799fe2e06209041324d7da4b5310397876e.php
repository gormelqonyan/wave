


<?php $__env->startSection('content'); ?>

<div class="sectionMargin row">
<div class="reg-form">
                        <form action="#" method="post" role="form" class="reg">

<h1><?php echo app('translator')->getFromJson('global.General_inform'); ?></h1>
  <div class="form-group">
  <label><?php echo app('translator')->getFromJson('global.Your_name'); ?></label><br>
                                <input type="text" name="name" class="form-control" id="name" placeholder="<?php echo app('translator')->getFromJson('global.Your_name'); ?>"
                                       data-rule="minlen:4" data-msg="Please enter at least 4 chars" required />
                                <!-- <div class="validation"></div> -->
                            </div>
                            <div class="form-group">
              <label><?php echo app('translator')->getFromJson('global.Your_email'); ?></label><br>
                                <input type="email" class="form-control" name="email" id="email"
                                       placeholder="<?php echo app('translator')->getFromJson('global.Your_email'); ?>" data-rule="email"
                                       data-msg="Please enter a valid email"  required />
                                <!-- <div class="validation"></div> -->
                            </div>
                            <div class="form-group">
              <label><?php echo app('translator')->getFromJson('global.Glb_phon'); ?></label><br>
                                <input type="text" class="form-control" name="phone" id="phone" placeholder="<?php echo app('translator')->getFromJson('global.Glb_phon'); ?>"
                                       data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject"  required />
                                <!-- <div class="validation"></div> -->
                            </div>
                            <div class="form-group">
              <label><?php echo app('translator')->getFromJson('global.Company_name'); ?></label><br>
              <!-- <span><?php echo app('translator')->getFromJson('global.Company_namecontent'); ?></span> -->
                                <input type="text" name="name" class="form-control" id="name" />
                                
                            </div>
                    <!-- <div class="form-group">
              <label><?php echo app('translator')->getFromJson('global.Company_website'); ?></label><br>
               <span><?php echo app('translator')->getFromJson('global.Company_adressweb'); ?></span> -->
                 <!-- <input type="text" name="web" class="form-control" id="web" />   
                   </div> -->
                     <div class="form-group">
              <label><?php echo app('translator')->getFromJson('global.Work_areas'); ?></label><br>
              <span><?php echo app('translator')->getFromJson('global.Work_areascontent'); ?></span>
                                <input type="text" name="ns" class="form-control" id="workarea" required />
                                
                            </div>
                    
                <h1><?php echo app('translator')->getFromJson('global.Site_design'); ?></h1>
        
            <div class="form-group">
              <label><?php echo app('translator')->getFromJson('global.Examp_likedesign'); ?></label><br>
              <span><?php echo app('translator')->getFromJson('global.Ardess_likedesign'); ?></span>
              <input type="text" name="name" class="form-control" id="name" />
            </div>
                     <!-- <div class="form-group"> -->
              <!-- <label><?php echo app('translator')->getFromJson('global.Name_Workgeography'); ?></label><br> -->
              <!-- <span><?php echo app('translator')->getFromJson('global.About_Workgeography'); ?></span> -->
                                <!-- <input type="text" name="name" class="form-control" id="name" /> 
                                
                            </div>-->
                         <!-- <div class="form-group"> -->
              <!-- <label><?php echo app('translator')->getFromJson('global.Develop_time'); ?></label><br> -->
              <!-- <span><?php echo app('translator')->getFromJson('global.Develop_content'); ?></span> -->
                                <!-- <input type="text" name="name" class="form-control" id="name" /> -->
                                
                            <!-- </div> -->
                         <!-- <div class="form-group"> -->
              <!-- <label><?php echo app('translator')->getFromJson('global.Budget'); ?></label><br> -->
              <!-- <span><?php echo app('translator')->getFromJson('global.Budget_content'); ?></span> -->
                                <!-- <input type="text" name="name" class="form-control" id="name" /> -->
                                
                            <!-- </div> -->
                          <!--<div class="form-group">
              <!-- <label><?php echo app('translator')->getFromJson('global.Respons_person'); ?></label><br> -->
              <!--<span><?php echo app('translator')->getFromJson('global.About_Respperson'); ?></span>
                                <input type="text" name="name" class="form-control" id="name" />
                                
                            </div>-->
  
      
  <h1><?php echo app('translator')->getFromJson('global.Site_function'); ?></h1>           
        <!--<div class="form-group">
              <!-- <label><?php echo app('translator')->getFromJson('global.Site_obj'); ?></label><br> -->
              <!--<span><?php echo app('translator')->getFromJson('global.Site_objcontent'); ?></span><br>
                            <!-- <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Attr_custom'); ?></label> <br> -->
                            <!--<input type="checkbox" name="name" id="name" />
                            <!-- <label><?php echo app('translator')->getFromJson('global.Awareness'); ?></label><br>  -->
              <!-- <input type="checkbox" name="name" id="name" /> -->
              <!--<label><?php echo app('translator')->getFromJson('global.Sale_services'); ?></label> <br>
              <input type="checkbox" name="name" id="name" />
              <!-- <label><?php echo app('translator')->getFromJson('global.Inf_accium'); ?></label> <br> -->
              <!-- <input type="checkbox" name="name" id="name" /> -->
              <!-- <label><?php echo app('translator')->getFromJson('global.Inf_productserv'); ?></label> <br> -->
              <!-- <input type="checkbox" name="name" id="name" /> -->
              <!-- <label><?php echo app('translator')->getFromJson('global.Inf_company'); ?></label> <br> -->
              <!-- <input type="checkbox" name="name" id="name" /> -->
              <!--<label><?php echo app('translator')->getFromJson('global.Post_news'); ?></label>  <br>            
                            </div>-->
        
        <div class="form-group">
              <label><?php echo app('translator')->getFromJson('global.Type_site'); ?></label><br>
              <span><?php echo app('translator')->getFromJson('global.Choose_site'); ?></span><br>

                           <input type="radio" name="site_type" value="<?php echo app('translator')->getFromJson('global.Corpor_site'); ?>"><label><?php echo app('translator')->getFromJson('global.Corpor_site'); ?></label> <br>
                            <input type="radio" name="site_type" value="<?php echo app('translator')->getFromJson('global.Corpor_catalog'); ?>"><label><?php echo app('translator')->getFromJson('global.Corpor_catalog'); ?></label> <br>
              <input type="radio" name="site_type" value="<?php echo app('translator')->getFromJson('global.Shop_online'); ?>"><label><?php echo app('translator')->getFromJson('global.Shop_online'); ?></label> <br>
              <input type="radio" name="site_type" value="<?php echo app('translator')->getFromJson('global.Lending'); ?>"><label><?php echo app('translator')->getFromJson('global.Lending'); ?></label> <br>
              <input type="radio" name="site_type" value="<?php echo app('translator')->getFromJson('global.Other'); ?>"><label><?php echo app('translator')->getFromJson('global.Other'); ?><label>
                <br>
        </div>
        <!--<div class="form-group">
               <label><?php echo app('translator')->getFromJson('global.Serv_communic'); ?></label><br> 
              <span><?php echo app('translator')->getFromJson('global.Comunic_visitor'); ?></span><br>-->
                            <!-- <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Feedback_form'); ?></label> <br>
                            <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Callback_form'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Question_answer'); ?></label> <br>
              <input type="checkbox" name="name" id="name" />
              <!-- <label><?php echo app('translator')->getFromJson('global.Voting'); ?></label> <br> -->
              <!-- <input type="checkbox" name="name" id="name" /> -->
              <!-- <label><?php echo app('translator')->getFromJson('global.Reviews'); ?></label> <br> -->
                            <!-- <input type="checkbox" name="name" id="name" /> 
                            <label><?php echo app('translator')->getFromJson('global.Comments'); ?></label> <br>-->
              <!--<input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Online_consult'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Booking_syst'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Subscr_newsl'); ?></label> <br>

                            <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.User_registr'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Pers_account'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.SMS_alerts'); ?></label><br>
        </div>-->
        <div class="form-group">
              <label><?php echo app('translator')->getFromJson('global.Sales_serv'); ?></label><br>
              <span><?php echo app('translator')->getFromJson('global.Network_sales'); ?></span><br>
                            <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Categories'); ?></label> <br>
                            <input type="checkbox" name="name" id="name" />
                            <!-- <label><?php echo app('translator')->getFromJson('global.Search_catalog'); ?></label> <br> -->
              <!-- <input type="checkbox" name="name" id="name" /> -->
              <label><?php echo app('translator')->getFromJson('global.Pr_filter'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Extend_descr'); ?></label> <br>
              <!--<input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Add_prod'); ?></label> <br> 
                            <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Req_price'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Compare_Prod'); ?></label> <br>-->
              <input type="checkbox" name="name" id="name" />

              <label><?php echo app('translator')->getFromJson('global.Basket'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Discnt_calcul'); ?></label> <br>
                            <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Cost_delivery'); ?></label> <br>
              <!--<input type="checkbox" name="name" id="name" />
              <!-- <label><?php echo app('translator')->getFromJson('global.Hist_userord'); ?></label> <br> -->
              <!-- <input type="checkbox" name="name" id="name" /> -->
              <!-- <label><?php echo app('translator')->getFromJson('global.Not_ordstat'); ?></label><br> -->
               <input type="checkbox" name="name" id="name" /> 
           <label><?php echo app('translator')->getFromJson('global.Online_pay'); ?></label> <br>

              <!--<input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Billing_pay'); ?></label>--><br>
        </div>
            <div class="form-group">
              <label><?php echo app('translator')->getFromJson('global.Integr_servpr'); ?></label><br>
              <span><?php echo app('translator')->getFromJson('global.Spec_servintegr'); ?></span><br>
                            <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Importprc_excel'); ?></label> <br>
                            <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Integr_c1'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Integr_corpdata'); ?></label> <br>
              <!--<input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Yandex_Market'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Farpost'); ?></label> --><br>
                            
        </div>
            <div class="form-group">
              <label><?php echo app('translator')->getFromJson('global.Lang_site'); ?></label><br>
              <span><?php echo app('translator')->getFromJson('global.Lang_translate'); ?></span>
                                <input type="text" name="name" class="form-control" id="name" />
        </div>
             <!--<div class="form-group">
              <label@lang('global.Cont_managesyst')</label><br>
              <span><?php echo app('translator')->getFromJson('global.Desired_managesyst'); ?></span><br>
                            <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.WordPress'); ?></label> <br>
                            <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.OpenCart'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.UMI_CMS'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Bitrix'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Other'); ?><label> <br>
                        </div>-->
            <!--<div class="form-group">
              <label><?php echo app('translator')->getFromJson('global.Mobile_version'); ?></label><br>
              
                            <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Answer_not'); ?></label> <br>
                            <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Need_mobvers'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Adap_design'); ?></label> <br>
                        </div> -->           
            <div class="form-group">
              <label><?php echo app('translator')->getFromJson('global.Other_purposes'); ?></label><br>
              <span><?php echo app('translator')->getFromJson('global.Օther_serv'); ?></span>
                                <input type="text" name="name" class="form-control" id="name" />
        </div>
        
        <h1><?php echo app('translator')->getFromJson('global.Site_struct'); ?></h1>
        
            <div class="form-group">
              <label><?php echo app('translator')->getFromJson('global.Site_section'); ?></label><br>
              <span><?php echo app('translator')->getFromJson('global.Desc_mainsect'); ?></span>
                                <input type="text" name="name" class="form-control" id="name" />
        </div>
        <div class="form-group">
              <label><?php echo app('translator')->getFromJson('global.Site_navig'); ?></label><br>
              <span><?php echo app('translator')->getFromJson('global.Menus_present'); ?></span>
                                <input type="text" name="name" class="form-control" id="name" />
        </div>
        <div class="form-group">
              <label><?php echo app('translator')->getFromJson('global.Inform_blocks'); ?></label><br>
              <span><?php echo app('translator')->getFromJson('global.Present_pages'); ?></span>
                                <input type="text" name="name" class="form-control" id="name" />
        </div>
        
       
        <!-- <div class="form-group">
              <label>Примеры сайтов, дизайн которых вам не нравится</label><br>
              <span>Напишите адреса сайтов, дизайн которых вам не нравится, напишите что именно нравится, почему</span>
                                <input type="text" name="name" class="form-control" id="name" />
        </div>
         -->
         <!-- <div class="form-group">
              <label><?php echo app('translator')->getFromJson('global.Elem_firmstyle'); ?></label><br>
              
                            <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Corp_stguide'); ?></label> <br>
                            <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Logo'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Brd_colors'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Brd_fonts'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Polygraphy'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Photo'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Catalogs'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Booklets'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Other'); ?><label> <br>
                        </div>-->
           <!--<div class="form-group">
              <label><?php echo app('translator')->getFromJson('global.Mood_assoc'); ?></label><br>
              
                            <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Strcorp_design'); ?></label> <br>
                            <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Bright_design'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Pos_fun'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Design_illustr'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Design_minimal'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Other'); ?></label> <br>
                        </div>-->
          <!--<div class="form-group">
              <label><?php echo app('translator')->getFromJson('global.Av_photos'); ?></label><br>
              
                            <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Thereis'); ?></label> <br>
                            <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Pick_designer'); ?></label> <br>
              <!-- <input type="checkbox" name="name" id="name" /> -->
              <!-- <label>Необходима фотосессия</label> <br> 
            </div>-->
            <div class="form-group">
              <label><?php echo app('translator')->getFromJson('global.Design_require'); ?></label><br>
              <span><?php echo app('translator')->getFromJson('global.Descr_require'); ?></span>
                                <input type="text" name="name" class="form-control" id="name" />
        </div>
        
            <h1><?php echo app('translator')->getFromJson('global.Cont_serv'); ?></h1>
          <div class="form-group">
              <label><?php echo app('translator')->getFromJson('global.Cont_site'); ?></label><br>
            
                            <input type="radio" name="site_content" value="<?php echo app('translator')->getFromJson('global.Alr_ready'); ?>"><label><?php echo app('translator')->getFromJson('global.Alr_ready'); ?></label> <br>
                            <input type="radio" name="site_content" value="<?php echo app('translator')->getFromJson('global.Ser_writer'); ?>"><label><?php echo app('translator')->getFromJson('global.Ser_writer'); ?></label> <br>
              <input type="radio" name="site_content" value="<?php echo app('translator')->getFromJson('global.Ph_required'); ?>"><label><?php echo app('translator')->getFromJson('global.Ph_required'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Tr_need'); ?></label> <br>

                        </div>
          <div class="form-group">
              <label><?php echo app('translator')->getFromJson('global.Addit_serv'); ?></label><br>
              
                            <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Fill_cont'); ?></label> <br>
                            <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Tech_supp'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Site_maint'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Context_advert'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.SEO_prom'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Corp_ident'); ?></label> <br>
              <input type="checkbox" name="name" id="name" /><label><?php echo app('translator')->getFromJson('global.Logo_develop'); ?></label> <br>
                        </div>
          <div class="text-center">
                                <button type="submit" class="btn-order"><?php echo app('translator')->getFromJson('global.Send'); ?></button>
                            </div>
          
                          
                        </form>

</div>
                    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>