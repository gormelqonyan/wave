<?php $__env->startSection('content'); ?>
<!-- Start Slider Area -->

<div class="bend niceties preview-2">

        <div id="ensign-nivoslider" class="slides carousel">
            
<!--  -->
<?php echo app('translator')->getFromJson('global.slides'); ?>
            <?php if(session()->has('SendMail')): ?>
                <div class="alert alert-success">
                    <script>alert('Նամակը Ուղղարկված է։ Շնորհակալություն'); </script>
                </div>
        <?php endif; ?>

			<!--<img src="img/slider/slider1.jpg" alt="Wave-it" height="550"/>
            <img src="img/slider/slider2.jpg" alt="Wave-it" height="550" title="#slider-direction-3"/>
            <img src="img/slider/slider3.jpg" alt="Wave-it" height="550"/>
            <img src="img/final/08.jpg" alt="Wave-it"  height="750"  />-->
            <!--<img src="img/final/slider9.png" alt="Wave-it"  height="750"  />-->
            <!--<img src="img/final/slider10.png" alt="Wave-it" height="750"  />-->
            <!--<img src="img/final/slider12.png" alt="Wave-it" height="750"  />-->
        </div>

        <!-- direction 1 -->
        <div id="slider-direction-1" class="slider-direction slider-one">
		
            <div class="container">
			<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
			<div class="slider-content">
            <!--&lt;!&ndash; layer 1 &ndash;&gt;-->
           <div class="layer-1-1 hidden-xs wow slideInDown" data-wow-duration="2s" data-wow-delay=".2s">
		  
		   </div>
		   
            <!--&lt;!&ndash; layer 2 &ndash;&gt;-->
            <div class="layer-1-2 wow slideInUp" data-wow-duration="2s" data-wow-delay=".1s">
			
			</div>
            <!--&lt;!&ndash; layer 3 &ndash;&gt;-->
			<div class="layer-1-3 wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">
			<a class="order" href="<?php echo e(route('order.index')); ?>"><?php echo app('translator')->getFromJson('global.order-site'); ?></a>
			<a class="order" href="#" data-toggle="modal" data-target="#call"><?php echo app('translator')->getFromJson('global.order-call'); ?></a>
			</div>
			</div>
			</div>
			</div>
			</div>
        </div>

        <!-- direction 2 -->
        <div id="slider-direction-2" class="slider-direction slider-two">
            <div class="container">
           <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="slider-content text-center">
            <!--&lt;!&ndash; layer 1 &ndash;&gt;-->
            <div class="layer-1-1 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">
            <h2 class="title1"></h2>
            </div>
            <!--&lt;!&ndash; layer 2 &ndash;&gt;-->
            <div class="layer-1-2 wow slideInUp" data-wow-duration="2s" data-wow-delay=".1s">
            <h1 class="title2"></h1>
			
            </div>
            <!--&lt;!&ndash; layer 3 &ndash;&gt;-->
            <div class="layer-1-3 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">
          <a href="" class="order">Order</a>
            <a class="ready-btn page-scroll" href="#about"></a>
           </div>
            </div>
            </div>
            </div>
            </div>
        </div>

        <!-- direction 3 -->
        <div id="slider-direction-3" class="slider-direction slider-two">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="slider-content">
                            <!-- layer 1 -->
                            <div class="layer-1-1 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">
                                <h2 class="title1"></h2>
                            </div>
                            <!-- layer 2 -->
                            <div class="layer-1-2 wow slideInUp" data-wow-duration="2s" data-wow-delay=".1s">
                                <h1 class="title2"></h1>
									
                            </div>
                            <!-- layer 3 -->
                            <!--<div class="layer-1-3 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">
                              <a class="ready-btn right-btn page-scroll" href="#services">See Services</a>
                              <a class="ready-btn page-scroll" href="#about">Learn More</a>
                            </div>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- direction 4 -->
<div id="slider-direction-4" class="slider-direction slider-two">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="slider-content">
                    <!-- layer 1 -->
                    <!--<div class="layer-1-1 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">-->
                    <!--    <h2 class="title1">The Best business Information </h2>-->
                    <!--</div>-->
                    <!-- layer 2 -->
                    <!--<div class="layer-1-2 wow slideInUp" data-wow-duration="2s" data-wow-delay=".1s">-->
                    <!--    <h1 class="title2">Helping Business Security & Peace of Mind for Your Family</h1>-->
                    <!--</div>-->
                    <!-- layer 3 -->
                    <!--<div class="layer-1-3 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">-->
                    <!--    <a class="ready-btn right-btn page-scroll" href="#services">See Services</a>-->
                    <!--    <a class="ready-btn page-scroll" href="#about">Learn More</a>-->
                    <!--</div>-->
                </div>
            </div>
        </div>
    </div>
</div>

<!-- End Slider Area -->
<section id="video">
<div class="container">
<div class="col-lg-6">
<?php echo app('translator')->getFromJson('global.video-intro'); ?>

</div>
<div class="col-lg-6">
<?php echo app('translator')->getFromJson('global.video-intro-text'); ?>
</div>
</div>
</section>
<!-- Start Service area -->
<div id="services" class="services-area area-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline services-head text-center">
                    <h2><?php echo app('translator')->getFromJson('global.Our_services'); ?></h2>
                </div>
            </div>
        </div>
        <div class="row text-center" id="servicesScrollLeft">
            <div class="services-contents">
                <!-- Start Left services -->
                <div class="col-md-4 col-sm-4 col-xs-10  d-flex justify-content-center">
                    <div class="about-move">
                        <div class="services-details">
                            <div class="single-services">
                                <h2><?php echo app('translator')->getFromJson('global.Web_services'); ?></h2>
                                <p><?php echo app('translator')->getFromJson('global.Web_dev'); ?></p>
                                <p><?php echo app('translator')->getFromJson('global.Web_design'); ?></p>
                                <p><?php echo app('translator')->getFromJson('global.Site_service'); ?></p>
                                <p><?php echo app('translator')->getFromJson('global.Technical_audit'); ?></p>
                            </div>
                        </div>
                        <!-- end about-details -->
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-10">
                    <div class="about-move">
                        <div class="services-details">
                            <div class="single-services">
                                <h2><?php echo app('translator')->getFromJson('global.SEO_optimization'); ?></h2>
                                <p><?php echo app('translator')->getFromJson('global.Key_words'); ?></p>
                                <p><?php echo app('translator')->getFromJson('global.Semantic_core'); ?></p>
                                <p><?php echo app('translator')->getFromJson('global.Internal_optimization'); ?></p>
                                <p><?php echo app('translator')->getFromJson('global.External_optimization'); ?></p>
                            </div>
                        </div>
                        <!-- end about-details -->
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-10">
                    <!-- end col-md-4 -->
                    <div class=" about-move">
                        <div class="services-details">
                            <div class="single-services">
                                <h2><?php echo app('translator')->getFromJson('global.Internet_marketing'); ?></h2>
                                <p><?php echo app('translator')->getFromJson('global.Social_media_marketing'); ?></p>
                                <p><?php echo app('translator')->getFromJson('global.Marketing_analysis'); ?></p>
                                <p><?php echo app('translator')->getFromJson('global.Internet_advertising'); ?></p>
                                
                                <!--<span><i class="fa fa-facebook"></i></span>-->
                                <!--<span><i class="fa fa-instagram"></i></span>-->
                                <!--<span><i class="fa fa-linkedin"></i></span>-->
                                <!--<span><i class="fa fa-youtube"></i></span>-->
                                <!--<span><i class="fa fa-vk"></i></span>-->
                            </div>
                        </div>
                        <!-- end about-details -->
                    </div>
                </div>
                <!-- end col-md-4 -->
            </div>
        </div>
        <div class="row text-center" id="servicesScrollRight">
            <div class="col-md-4 col-sm-4 col-xs-10">
                <div class="about-move">
                    <div class="services-details">
                        <div class="single-services">
                            <h2><?php echo app('translator')->getFromJson('global.Time_monitoring'); ?></h2>
                            <p><?php echo app('translator')->getFromJson('global.Host_server'); ?></p>
                            <p><?php echo app('translator')->getFromJson('global.Site_recovery'); ?></p>
                            <p><?php echo app('translator')->getFromJson('global.Domain_registration'); ?></p>
                        </div>
                    </div>
                    <!-- end about-details -->
                </div>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-10">
                <div class="about-move">
                    <div class="services-details">
                        <div class="single-services">
                            <h2><?php echo app('translator')->getFromJson('global.Graphic_design'); ?></h2>
                            <a href="<?php echo e(route('logo')); ?>"><i class="fa fa-arrow-right"></i><?php echo app('translator')->getFromJson('global.logo'); ?></a><br>
                            <a href="<?php echo e(route('card')); ?>"><i class="fa fa-arrow-right"></i><?php echo app('translator')->getFromJson('global.card'); ?></a><br>
							<a href="<?php echo e(route('design')); ?>"><i class="fa fa-arrow-right"></i><?php echo app('translator')->getFromJson('global.3d'); ?></a><br>
							<a href="<?php echo e(route('banners')); ?>"><i class="fa fa-arrow-right"></i><?php echo app('translator')->getFromJson('global.Banner_creation'); ?></a>
                        </div>
                    </div>
                    <!-- end about-details -->
                </div>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-10">
                <div class="about-move">
                    <div class="services-details">
                        <div class="single-services">
                            <h2><a href="#"><?php echo app('translator')->getFromJson('global.IOS_Android'); ?></a></h2>
                            <a href="https://play.google.com/store/apps/details?id=com.birthright" target="_blank"><i class="fa fa-arrow-right" aria-hidden="true"></i>Birthright Connect </a><br>
                            <a href="https://play.google.com/store/apps/details?id=com.hikearmenia" target="_blank"><i class="fa fa-arrow-right" aria-hidden="true"></i>HIKEArmenia</a><br>
                            <a href="https://play.google.com/store/apps/details?id=com.learnbat.showme" target="_blank"><i class="fa fa-arrow-right" aria-hidden="true"></i>ShowMe Interactive Whiteboard</a>
                        </div>
                    </div>
                    <!-- end about-details -->
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Service area -->

<!-- our-skill-area start -->
<div class="our-skill-area fix hidden-sm">
    <div class="test-overly"></div>
        <div class="container">
            <div class="col-xs-6 col-sm-6 col-md-4 about_info">
                <div class="about_item " >
                    <div class="about_radius">
                        <?php echo app('translator')->getFromJson('global.From_days'); ?>
                    </div>
                    <h4><?php echo app('translator')->getFromJson('global.Project_creation'); ?></h4>
                </div>
            </div>
           <!-- <div class="col-xs-6 col-sm-6 col-md-3 about_info">
                <div class="about_item " >
                    <div class="about_radius prepay_30">
                        <p>30%</p>
                    </div>
                    <h4><?php echo app('translator')->getFromJson('global.Prepayment'); ?></h4>
                </div>
            </div>-->
            <div class="col-xs-6 col-sm-6 col-md-4 about_info">
                <div class="about_item " >
                    <div class="about_radius">
                        <?php echo app('translator')->getFromJson('global.Over_projects'); ?>
                    </div>
                    <h4><?php echo app('translator')->getFromJson('global.Performed'); ?></h4>
                </div>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-4 about_info">
                <div class="about_item " >
                    <div class="about_radius">
                        24/7
                    </div>
                    <h4><?php echo app('translator')->getFromJson('global.Technical_support'); ?></h4>
                </div>
            </div>
        </div>
</div>
<script>

</script>
<!--
  <div class="modal fade bd-example-modal-lg pt-5" id="modalVideo" role="dialog">
    <div class="modal-dialog modal-lg">
     
      <div class="videoModalContent"  id="modalVideoMy">
        <button type="button" class="close videoX" id="pause_video" data-dismiss="modal">&times;</button>
        <div class="modal-body">
          <video width="100%" height="550px" controls autoplay>
   <?php echo app('translator')->getFromJson('global.video'); ?>

  </video>
        </div>
     
      </div>
    </div>
  </div>-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>