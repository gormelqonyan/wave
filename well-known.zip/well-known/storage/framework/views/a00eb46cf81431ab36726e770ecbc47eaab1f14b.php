<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Wave IT</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="разработчик, Развитие бизнеса, сайты, интернет-магазины, порталы, лэндинги, разработка сайтов,  продвижение в интернете, SEO – продвижение" name="keywords">
    <meta content="Нужен эксклюзивный сайт, интернет-магазин, блог или лендинг? Наша команда IT-специалистов "Wave IT" с удовольствием поможет Вам!
Мы разработаем уникальный дизайн для вашего сайта и сверстаем его, используя такие технологии, как HTML5, CSS3, Java Script + jQuery, PHP и базы данных MySQL. Далее последует оптимизация для различных устройств и продвижение вашего сайта в интернете на первый строки поисковых систем - эти действия принесут много лидов (заинтересованных людей) для вашей компании. Приятный бонус: вы всегда можете наблюдать онлайн за выполнением нашей работы и получать ежемесячную отчетность в Личном кабинете." name="description">
    <style>
        .carousel {
            /*max-height: 650px !important;*/
            width: 100% !important;
        }
    </style>

    <?php echo $__env->make('includes.head-links', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>

<body data-spy="scroll" data-target="#navbar-example">

<div id="preloader"></div>

<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('includes.body-links', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

</html>
