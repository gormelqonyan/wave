
    <h3>Hy</h3>\
   
    <p>Անուն:  <?php echo e($token['name']); ?></p>

    
    <br>
    <p>E-mail:  <?php echo e($token['email']); ?></p>

    
    
    <br>
    <p>Հեռ․ Համար:  <?php echo e($token['subject']); ?></p>
   
    <br>
    <p>Հաղորդագրություն:</p><p>  <?php echo e($token['message']); ?></p>


