<?php $__env->startSection('content'); ?>
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('message')); ?>

        </div>
    <?php endif; ?>
    <div class="panel-group" id="accordion">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h4 class="panel-title">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                        <i class="indicator glyphicon glyphicon-triangle-bottom"></i><h1 class="text-center"> Պատվերներ</h1>
                    </a>
                </h4>
            </div>
            <div id="collapseOne" class="panel-collapse collapse in">
                <div class="panel-body">
                    <div class="panel panel-default">

                        <div class="panel-body">
                            <table class="table table-condensed" style="border-collapse:collapse;">
                                <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tbody>

                                <tr data-toggle="collapse" data-target="#order<?php echo e($it->id); ?>" class="accordion-toggle">
                                    <td><span class="glyphicon glyphicon-triangle-top"></span> <?php echo e($it->name); ?></td>
                                    <td><?php echo e($it->mail); ?></td>
                                    <td><?php echo e($it->phone); ?></td>
                                    <td><?php echo e($it->created_at); ?></td>
                                    <td></td>
                                </tr>

                                <tr>
                                    <td colspan="12" class="hiddenRow">
                                        <div class="accordian-body collapse" id="order<?php echo e($it->id); ?>">
                                            <table class="table table-striped">
                                                <thead>
                                                <tr>
                                                    <th>Ընկերության անունը</th>
                                                    <th>Աշխատանքային ոլորտ</th>
                                                    <th>Կայքերի օրինակներ</th>
                                                    <th>Կայքի տեսակը</th>
                                                    <th>վաճառքի ծառայություններ</th>
                                                    <th><form action="<?php echo e(route('order.destroy', $it->id)); ?>" method="POST">
                                                            <?php echo e(method_field('DELETE')); ?>

                                                            <?php echo e(csrf_field()); ?>

                                                            <button onclick="return confirm('Համոզված եք, որ ցանկանում եք հեռացնել պատվերը?')" class="btn btn-danger">Հեռացնել</button>
                                                        </form></th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr data-toggle="collapse" data-target="#read" class="accordion-toggle">
                                                    <td><span class="glyphicon glyphicon-plus"></span> <?php echo e($it->company_name); ?></td>
                                                    <td><?php echo e($it->business); ?></td>
                                                    <td><?php echo e($it->design); ?></td>
                                                    <td><?php echo e($it->type); ?></td>
                                                    <td><?php echo e($it->functions); ?></td>
                                                </tr>
                                                <tr>
                                                    <td colspan="6" class="hiddenRow">
                                                        <div id="read" class="accordian-body collapse">
                                                            <p><b>ծառայությունները</b> : <?php echo e($it->side_services); ?></p>
                                                            <p><b>լեզվի տարբերակները</b> : <?php echo e($it->lang); ?></p>
                                                            <p><b>Այլ նպատակներ</b> : <?php echo e($it->other); ?></p>
                                                            <p><b>Կայքի բաժիններ</b> : <?php echo e($it->sections); ?></p>
                                                            <p><b>Կայքի նավիգացիա</b> : <?php echo e($it->navigation); ?></p>
                                                            <p><b>Տեղեկատվական բլոկներ</b> : <?php echo e($it->information_blocks); ?></p>
                                                            <p><b>պահանջները և ցանկությունները</b> : <?php echo e($it->desires); ?></p>
                                                            <p><b>Կայքի բովանդակությունը</b> : <?php echo e($it->conten); ?></p>
                                                            <p><b>Լրացուցիչ ծառայություններ</b> : <?php echo e($it->additional_services); ?></p>
                                                        </div>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>

                                        </div>
                                    </td>
                                </tr>

                                </tbody>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

<script>



    function toggleChevron(e) {
        $(e.target)
            .prev('.panel-heading')
            .find("i.indicator")
            .toggleClass('glyphicon-triangle-bottom glyphicon-triangle-top');
    }
    $('#accordion').on('hidden.bs.collapse', toggleChevron);
    $('#accordion').on('shown.bs.collapse', toggleChevron);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>