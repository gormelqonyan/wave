
<h3>Բարև </h3>

<p>Անուն: <?php echo e($data['name']); ?></p>
<p>Հեռ․ Համար:  <?php echo e($data['phone']); ?></p>




