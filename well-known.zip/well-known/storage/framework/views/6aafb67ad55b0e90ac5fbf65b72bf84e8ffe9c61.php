<?php $__env->startSection('content'); ?>
<section class="container" style="margin-top: 150px;">
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="section-headline text-center">
            <h2><?php echo app('translator')->getFromJson('global.logo'); ?></h2>
        </div>
    </div>
</div>

<div class="d-flex justify-content-around">

            <div id="contentWrapper">
                <ul>
                    <li style="background-image: url('img/logo/logo_1.jpg')"></li>
                    <li style="background-image: url('img/logo/logo_1.jpg')"></li>
                </ul>
            </div>
    		<div id="dark"></div>
    		<div id="lightbox"></div>
        </div>

</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('altlinks'); ?>


<!-- //js -->
<!-- simpleLightbox -->

<script>
    $("#contentWrapper li").click(function() {
// 	console.log($(this).css("background-image"));

	//grabs the image url of that particular image
	imgUrl = $(this).css("background-image");

		//replaces the image url of the last image shown in the lightbox with the current image
		$("#lightbox").css("background-image", imgUrl);
		//shows the updated lightbox that has been hidden
		$("#dark").fadeIn();
		$("#lightbox").fadeIn("slow");
});

$("#lightbox").click(function(){
	//hides the lightbox so we can go back to the page
	$("#dark").fadeOut();
	$("#lightbox").fadeOut("slow");
});


</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>