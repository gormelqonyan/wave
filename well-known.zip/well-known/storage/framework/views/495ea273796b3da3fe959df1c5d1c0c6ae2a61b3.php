<?php $__env->startSection('content'); ?>
    <!-- <a href="/posts" class="btn btn-default">Go Back</a> -->
    <div class="container">
      <h5>Անուն։ <?php echo e($contact->name); ?></h5>
      <h5>Էլ․ հասցե։ <?php echo e($contact->email); ?></h5>
      <h5>Ամսաթիվ։ <?php echo e($contact->created_at); ?></h5>
      <br>
      <p>Հաղորդագրություն։ <?php echo e($contact->message); ?></p>
      <hr>
      <div class="">
        <p>Հիշել   <input type="checkbox" class="rem" name="rem" data-id="<?php echo e($contact->id); ?>" value="<?php echo e($contact->rem); ?>"/></p>
      </div>


    <div class="row">
      <?php if(!Auth::guest()): ?>
        <?php echo Form::open(['action' => ['ContactController@destroy', $contact->id], 'method' => 'POST', 'class' => 'pull-right', 'onclick'=>'return confirm("Դուք համոզվա՞ծ եք։")']); ?>

            <?php echo e(Form::hidden('_method', 'DELETE')); ?>

            <?php echo e(Form::submit('Ջնջել', ['class' => 'btn btn-danger'])); ?>

        <?php echo Form::close(); ?>

      <?php endif; ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>