<div id="contact" class="contact-area">
    <div class="contact-inner area-padding">
        <div class="contact-overly"></div>
        <div class="container ">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="section-headline text-center">
                        <h2><?php echo app('translator')->getFromJson('global.Contact_us'); ?></h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <!-- Start contact icon column -->
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="contact-icon text-center">
                        <div class="single-icon">
                            <i class="fa fa-mobile"></i>
                            <p>
<!--                                Позвонить владельцу : +7 958 799 50 53<br>-->
<!--                                Позвонить менеджеру : +7 915 023 88 00-->
                                <?php echo app('translator')->getFromJson('global.Telephone'); ?> : +7 915 023 88 00<br>
                                       <span>+7 958 799 50 53</span>

                            </p>
                        </div>
                    </div>
                </div>
                <!-- Start contact icon column -->
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="contact-icon text-center">
                        <div class="single-icon">
                            <i class="fa fa-envelope-o"></i>
                            <p>
                                <?php echo app('translator')->getFromJson('global.Email'); ?>: info@wave-it.ru <br>
                                <?php echo app('translator')->getFromJson('global.Web'); ?>: www.wave-it.ru
                            </p>
                        </div>
                    </div>
                </div>
                <!-- Start contact icon column -->
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="contact-icon text-center">
                        <div class="single-icon">
                            <i class="fa fa-map-marker"></i>
                            <p>
                                <?php echo app('translator')->getFromJson('global.Location'); ?>

                                <span></span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">

                <!-- Start Google Map -->
                <div class="col-md-6 col-sm-6 col-xs-12 location">
                    <!-- Start Map -->
<!--                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3047.459778275848!2d44.4885341153893!3d40.19883437939109!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x406abd6beca25551%3A0x9192912c6f698e91!2s3+Hakob+Hakobyan+St%2C+Yerevan+0033!5e0!3m2!1sru!2s!4v1542179406201" style="border:0" allowfullscreen></iframe>-->
                    <?php if(Session::get('locale') == 'en'): ?>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3047.459778275848!2d44.4885341153893!3d40.19883437939109!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x406abd6beca25551%3A0x9192912c6f698e91!2s3+Hakob+Hakobyan+St%2C+Yerevan+0033!5e0!3m2!1sru!2s!4v1542179406201" style="border:0" allowfullscreen></iframe>
                    <?php else: ?>
                    <iframe src="https://yandex.ru/map-widget/v1/-/CBFZe6Rg9B" allowfullscreen="true" style="border:none;"></iframe>
                    <?php endif; ?>
                    <!--<iframe src="https://yandex.ru/map-widget/v1/-/CBBHZEuOPA" width="560" height="400" frameborder="0" allowfullscreen="true"></iframe>-->
                    <!--<iframe src="https://yandex.ru/map-widget/v1/-/CBBsMWeKOC" width="560" height="400" frameborder="0"
                            allowfullscreen="true"></iframe>
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3047.3832299675355!2d44.533456715545874!3d40.20053747939076!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x406abd2b1a589109%3A0x3b524ed217ab2cbb!2zMjMg1LTVodW-1avVqSDUsdW21bDVodWy1anVqyDWg9W41bLVuNaBLCDUtdaA1ofVodW2LCDVgNWh1bXVodW91b_VodW2!5e0!3m2!1shy!2s!4v1539942725022" style="border:0" allowfullscreen></iframe>-->

                    <!--Google map-->
                    <div id="map-container" class="z-depth-1-half map-container mb-5">
                        <!--<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3047.3832299675355!2d44.533456715545874!3d40.20053747939076!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x406abd2b1a589109%3A0x3b524ed217ab2cbb!2zMjMg1LTVodW-1avVqSDUsdW21bDVodWy1anVqyDWg9W41bLVuNaBLCDUtdaA1ofVodW2LCDVgNWh1bXVodW91b_VodW2!5e0!3m2!1shy!2s!4v1539942725022" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>-->
                    </div>
                    <!-- Uncomment below if you wan to use dynamic maps -->
                    <!-- End Map -->
                </div>
                <!-- End Google Map -->

                <!-- Start  contact -->
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <div class="form contact-form">
                        <form action="<?php echo e(action('ContactController@store')); ?>" method="post" role="form" class="">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <input type="text" name="name" class="form-control" id="name" placeholder="<?php echo app('translator')->getFromJson('global.Your_name'); ?>"
                                       data-rule="minlen:4" data-msg="Please enter at least 4 chars"/>
                                <!-- <div class="validation"></div> -->
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control" name="email" id="email"
                                       placeholder="<?php echo app('translator')->getFromJson('global.Your_email'); ?>" data-rule="email"
                                       data-msg="Please enter a valid email"/>
                                <!-- <div class="validation"></div> -->
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="subject" id="subject" placeholder="<?php echo app('translator')->getFromJson('global.Subject'); ?>"
                                       data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject"/>
                                <!-- <div class="validation"></div> -->
                            </div>
                            <div class="form-group">
                                <textarea class="form-control" name="message" rows="5" data-rule="required"
                                          data-msg="Please write something for us" placeholder="<?php echo app('translator')->getFromJson('global.Message'); ?>"></textarea>
                                <!-- <div class="validation"></div> -->
                            </div>
                            <div class="text-center">
                                <button type="submit"><?php echo app('translator')->getFromJson('global.Send_message'); ?></button>
                            </div>
                        </form>

                        <!--<div id="sendmessage">Your message has been sent. Thank you!</div>-->
                        <!--<div id="errormessage"></div>-->
                        <!--<form action="myform.php" method="post" role="form" class="contactForm">-->
                        <!--  <div class="form-group">-->
                        <!--    <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />-->
                        <!--    <div class="validation"></div>-->
                        <!--  </div>-->
                        <!--  <div class="form-group">-->
                        <!--    <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" />-->
                        <!--    <div class="validation"></div>-->
                        <!--  </div>-->
                        <!--  <div class="form-group">-->
                        <!--    <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />-->
                        <!--    <div class="validation"></div>-->
                        <!--  </div>-->
                        <!--  <div class="form-group">-->
                        <!--    <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>-->
                        <!--    <div class="validation"></div>-->
                        <!--  </div>-->
                        <!--  <div class="text-center"><button type="submit">Send Message</button></div>-->
                        <!--</form>-->
                    </div>
                </div>
                <!-- End Left contact -->
            </div>
        </div>
    </div>
</div>
<!-- End Contact Area -->
<!-- Start Footer bottom Area -->
<footer>
    <!--<div class="footer-area">-->
    <!--  <div class="container">-->
    <!--    <div class="row">-->
    <!--      <div class="col-md-4 col-sm-4 col-xs-12">-->
    <!--        <div class="footer-content">-->
    <!--          <div class="footer-head">-->
    <!--            <div class="footer-logo">-->
    <!--              <h2>Wave IT</h2>-->
    <!--            </div>-->
    <!--            <p></p>-->

    <!--          </div>-->
    <!--        </div>-->
    <!--      </div>-->
    <!--      <div class="col-md-4 col-md-offset-4 col-sm-4 col-sm-offset-4 col-xs-12">-->
    <!--        <div class="footer-content">-->
    <!--          <div class="footer-head">-->
    <!--            <h4>information</h4>-->
    <!--            <p>-->
    <!--              The price can always be negotiated. Excellent quality is guaranteed. All sites are exclusive.-->
    <!--              We use only unique developments and tools.-->
    <!--            </p>-->
    <!--            <div class="footer-contacts">-->
    <!--              <p><span>Tel:</span> +374 77 78 97 86</p>-->
    <!--              <p><span>Tel:</span> +7 915 023 88 00 </p>-->

    <!--              <p><span>Email:</span> waveitinbox@gmail.com</p>-->
    <!--              <p><span>Working Hours:</span> 10am-00pm</p>-->
    <!--            </div>-->
    <!--          </div>-->
    <!--        </div>-->
    <!--      </div>-->
    <!--    </div>-->
    <!--  </div>-->
    <!--</div>-->
    <div class="footer-area-bottom">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="footer-icons">
                        <ul>
                            <li>
                                <a href="https://www.facebook.com/Wave-It-180752426136908/" target="_blank"><i
                                            class="fa fa-facebook"></i></a>
                            </li>
                            <li>
                                <a href="https://www.instagram.com/wave_it.ru/?hl=ru" target="_blank"><i
                                            class="fa fa-instagram"></i></a>
                            </li>
                            <li>
                                <a href="#" target="_blank"><i class="fa fa-google"></i></a>
                            </li>
                            <li>
                                <a href="https://vk.com/it_wave_it" target="_blank"><i class="fa fa-vk"></i></a>
                            </li>
                        </ul>
                    </div>
                    <div class="copyright text-center">
                        <p>
                            &copy; 2018 <?php echo app('translator')->getFromJson('global.Company'); ?><strong> <a href="#">Wave IT</a> </strong>
                        </p>
                    </div>
                    <div class="credits">

                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
