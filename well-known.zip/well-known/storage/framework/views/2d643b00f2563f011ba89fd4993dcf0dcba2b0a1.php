<?php $__env->startSection('content'); ?>

<section class="courses-1">
	<div class="container">	
			<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('global.Home'); ?></a>
    </li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('web')); ?>"><?php echo app('translator')->getFromJson('global.Courses'); ?></a></li>
	 <li class="breadcrumb-item active">HTML, CSS և BootStrap դասընթացներ</li>
</ol>
<div class="panel-group" id="accordion">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson1">
		  <span>Դաս 1</span>
            <p>Ի՞նչ է վեբ ծրագրավորումը</p>
            <p>HTML, CSS, JavaScript, PHP</p></a>
        </h4>
      </div>
      <div id="lesson1" class="panel-collapse collapse in">
        <div class="panel-body">
	<h2 class="npatak">HTML, CSS, BootStrap դասընթացի նպատակը</h2>
	<p class="npatak-p">Դասի ընթացքում կուսումնասիրենք</p>
					<p class="how-to">1. Ի՞նչ է վեբ ծրագրավորումը</p>
					<p class="how-to">2. Ի՞նչ է վեբ կայքը, ինչպես է այն աշխատում</p>
					<p class="how-to">3. Ի՞նչ է HTML - ը, HTML - ի կիրառությունը</p>
					<p class="how-to">4. Ի՞նչ է CSS - ը, CSS - ի կիրառությունը</p>
					<p class="how-to">5. Ի՞նչ է JavaScript -ը , JavaScript - ի կիրառությունը</p>
					<p class="how-to">6. Ի՞նչ է Php - ն, Php - ի կիրառությունը</p>
		</div>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson2">
		  <span>Դաս 2</span>
            <p>HTML ներածություն</p>
            <p>HTML ներածություն, թեգեր, ատրիբուտներ, մի քանի թեգեր</p>
		  </a>
        </h4>
      </div>
      <div id="lesson2" class="panel-collapse collapse">
        <div class="panel-body">
	<h2 class="npatak">HTML, CSS, BootStrap դասընթացի նպատակը</h2>
					<h2 class="npatak2">Դասի ընթացքում կուսումնասիրենք՝ </h2>
					<p class="how-to">Ի՞նչ է HTML – ը </p>
					<p class="how-to">Ի՞նչ է թեգը, թեգերի տեսակները </p>
					<p class="how-to">Ինչ է ատրիբուտը </p>
					<p class="how-to">HTML էջի հիմնական կառուցվածքը </p>
					<p class="how-to">Մի քանի թեգեր </p>
	</div>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson3">
		  <span>Դաս 3</span>
            <p>Նշագրում․ Առաջին քայլեր</p>
            <p>Հատուկ սիմվոլներ, աղյուսակներ, ֆորմաներ, նշագրում աղյուսակների միջոցով</p>
		  </a>
        </h4>
      </div>
      <div id="lesson3" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">HTML, CSS, BootStrap դասընթացի նպատակը</h2>
		<p class="web4">Դասի ընթացքում կուսումնասիրենք՝</p>
					<p class="web4">Հատուկ նշաններ</p>
					<p class="web4">Աղյուսակներ</p>
					<p class="web4">Ֆորմաներ</p>
		</div>
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson4">
		  <span>Դաս 4</span>
            <p>Նշագրում</p>
            <p>div էլեմենտ, կայքերի կառուցվածքը, photoshop ներածություն, psd էջի նշագրում </p>
		  </a>
        </h4>
      </div>
      <div id="lesson4" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">HTML, CSS, BootStrap դասընթացի նպատակը</h2>
			<p class="web3">Դասի ընթացքում կուսումնասիրենք՝</p>
					<p class="web3">Կայքերի հիմնական ստռուկտուռան</p>
					<p class="web3">Գրաֆիկական խմբագրիչներ, Adobe PhotoShop</p>
					<p class="web3">div էլեմենտ</p>
					<p class="web3">Նշագրում div էլեմենտներով</p>
		</div>
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson5">
		  <span>Դաս 5</span>
             <p>CSS ներածություն</p>
            <p>CSS ներածություն, մի քանի հատկություններ</p>
		  </a>
        </h4>
      </div>
      <div id="lesson5" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">HTML, CSS, BootStrap դասընթացի նպատակը</h2>
		<p class="web4">Այս դասի ընթացքում կսովորեք</p>
					<p class="web4">Ի՞նչ է CSS - ը</p>
					<p class="web4">CSS – ի սինտաքսիսը</p>
					<p class="web4">CSS ֊ ի հայտարարման եղանակները</p>
					<p class="web4">Սելեկտորներ</p>
					<p class="web4"> Ժարանգություն, հատկությունների խմբավոտում</p>
		</div>
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson6">
		  <span>Դաս 6</span>
            <p>CSS ներածություն</p>
            <p>OverFlow , Position</p>
		  </a>
        </h4>
      </div>
      <div id="lesson6" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">HTML, CSS, BootStrap դասընթացի նպատակը</h2>
		<p class="web4">Այս դասի ընթացքում կուսումնասիրենք՝</p>
					<p class="web4">Overflow, position, top, right, left, bottom հատկություններ</p>
					<p class="web4">Psd ֆայլի նշագրում</p>
		</div>
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson7">
		  <span>Դաս 7</span>
            <p>Media հարցումներ</p>
            <p>Ադապտացվող դիզայն, media հարցումներ</p>
		  </a>
        </h4>
      </div>
      <div id="lesson7" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">HTML, CSS, BootStrap դասընթացի նպատակը</h2>
		<p class="web4">Դասի ընթացքում կուսումնասիրենք՝</p>
					<p class="web4">1.Ինչի համար են գրաֆիկական խմբագրիչները</p>
					<p class="web4">2.Adobe Photoshop գրաֆիկական խմբագրիչ</p>
					<p class="web4">3.Շերտեր</p>
					<p class="web4">4.Ինչպես ճիշտ կտրել նկարներ նշագրման համար</p>
					<p class="web4">5.Ադապտացվող դիզայն, Media հարցումներ</p>
		</div>
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson8">
		  <span>Դաս 8</span>
           <p>BootStrap ներածություն</p>
            <p>Ցանցեր, կոմպոնենտներ</p>
		  </a>
        </h4>
      </div>
      <div id="lesson8" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">HTML, CSS, BootStrap դասընթացի նպատակը</h2>
			<p class="web4">Դասի ընթացքում կուսումնասիրենք՝</p>
					<p class="web4">Ի՞նչ է BootStrap – ը և ինչի համար է այն կիրառվում</p>
					<p class="web4">Ինչպես տեղադրել BootStrap 4 հենքը (FrameWork)</p>
					<p class="web4">Ցանցեր</p>
					<p class="web4">Կոմպոնենտներ</p>
		</div>
      </div>
    </div>
		<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson9">
		  <span>Դաս 9</span>
           <p>BootStrap customization: SASS</p>
            <p>SASS, Less, BootStrap customization</p>
		  </a>
        </h4>
      </div>
      <div id="lesson9" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">HTML, CSS, BootStrap դասընթացի նպատակը</h2>
		<p class="web4">Դասի ընթացքում կուսումնասիրենք՝</p>
					<p class="web4">BootStrap. Customization. SASS  ​</p>
		</div>
      </div>
    </div>
		<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson10">
		  <span>Դաս 10</span>
          <p>BootStrap</p>
            <p>Պրակտիկ աշխատանք</p>
		  </a>
        </h4>
      </div>
      <div id="lesson10" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">BootStrap պրակտիկա</h2>
		
		</div>
      </div>
    </div>
		<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson11">
		  <span>Դաս 11</span>
           <p>HTML 5</p>
            <p>Նոր թեգեր HTML5 -ում</p>
		  </a>
        </h4>
      </div>
      <div id="lesson11" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">HTML, CSS, BootStrap դասընթացի նպատակը</h2>
		<p class="web4">Դասի ընթացքում կուսումնասիրենք՝</p>
					<p class="web4">1. Ի՞նչ է HTML5 –ը</p>
					<p class="web4">2. HTML5 – ի մի քանի թեգեր​</p>
		</div>
      </div>
    </div>
		<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#lesson12">
		  <span>Դաս 12</span>
           <p>CSS3 ներածություն</p>
            <p>Box-shadow , Word wrap , Transform</p>
		  </a>
        </h4>
      </div>
      <div id="lesson12" class="panel-collapse collapse">
        <div class="panel-body">
		<h2 class="npatak">HTML, CSS, BootStrap դասընթացի նպատակը</h2>
		<p class="web3"> Այս դասի ընթացքում կուսումնասիրենք CSS3 տեխնալոգիան</p>
		</div>
      </div>
    </div>
	
	
	
	
	
  </div> 
</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.hbase', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>