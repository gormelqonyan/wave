<!--Start of Tawk.to Script-->
<!--
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5bfa83cc40105007f3797c5e/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
-->

<!--End of Tawk.to Script-->

<script src="<?php echo e(asset('lib/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('lib/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('lib/owlcarousel/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('lib/venobox/venobox.min.js')); ?>"></script>
<script src="<?php echo e(asset('lib/knob/jquery.knob.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/swiper.min.js')); ?>"></script>
<script src="<?php echo e(asset('lib/wow/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('lib/parallax/parallax.js')); ?>"></script>
<script src="<?php echo e(asset('lib/easing/easing.min.js')); ?>"></script>
<script src="<?php echo e(asset('lib/nivo-slider/js/jquery.nivo.slider.js')); ?>"></script>
<script src="<?php echo e(asset('lib/appear/jquery.appear.js')); ?>"></script>
<script src="<?php echo e(asset('lib/isotope/isotope.pkgd.min.js')); ?>"></script>


<!-- MDB core JavaScript -->
<script src="<?php echo e(asset('js/mdb.js')); ?>"></script>
<!-- Uncomment below if you want to use dynamic Google Maps -->
<script src="https://maps.google.com/maps/api/js"></script>
<!--<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD8HeI8o-c1NppZA-92oYlXakhDPYR7XMY"></script>-->

<!-- Contact Form JavaScript File -->
<!-- <script src="<?php echo e(asset('contactform/contactform.js')); ?>"></script> -->

<script src="<?php echo e(asset('js/main.js')); ?>"></script>

<script type="text/javascript">
        $(window).on('load',function(){
            // alert('aaa');
            // $('#modalVideo').modal('show');
        });
</script>
<script src="<?php echo e(asset('js/simpleLightbox.js')); ?>"></script>

