<?php $__env->startSection('content'); ?>
<!-- Start Slider Area -->
<div id="home" class="slider-area">
    <div class="bend niceties preview-2">
        <div id="ensign-nivoslider" class="slides carousel">
            <img src="img/final/01.jpg" alt="" height="750" title="#slider-direction-1"/>
            <img src="img/final/02.jpg" alt="" height="750"/>
            <img src="img/final/03.jpg" alt="" height="750" title="#slider-direction-3"/>
            <!--<img src="img/final/04.jpg" alt=""  height="750"  />-->
            <img src="img/final/05.jpg" alt="" height="750"/>
            <!--<img src="img/final/08.jpg" alt=""  height="750"  />-->
            <!--<img src="img/final/slider9.png" alt=""  height="750"  />-->
            <!--<img src="img/final/slider10.png" alt="" height="750"  />-->
            <!--<img src="img/final/slider12.png" alt="" height="750"  />-->
        </div>

        <!-- direction 1 -->
        <div id="slider-direction-1" class="slider-direction slider-one">
            <!--<div class="container">-->
            <!--<div class="row">-->
            <!--<div class="col-md-12 col-sm-12 col-xs-12">-->
            <!--<div class="slider-content">-->
            <!--&lt;!&ndash; layer 1 &ndash;&gt;-->
            <!--<div class="layer-1-1 hidden-xs wow slideInDown" data-wow-duration="2s" data-wow-delay=".2s">-->
            <!--<h2 class="title1">The Best Business Information </h2>-->
            <!--</div>-->
            <!--&lt;!&ndash; layer 2 &ndash;&gt;-->
            <!--<div class="layer-1-2 wow slideInUp" data-wow-duration="2s" data-wow-delay=".1s">-->
            <!--<h1 class="title2">We're In The Business Of Helping You Start Your Business</h1>-->
            <!--</div>-->
            <!--&lt;!&ndash; layer 3 &ndash;&gt;-->
            <!--<div class="layer-1-3 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">-->
            <!--<a class="ready-btn right-btn page-scroll" href="#services">See Services</a>-->
            <!--<a class="ready-btn page-scroll" href="#about">Learn More</a>-->
            <!--</div>-->
            <!--</div>-->
            <!--</div>-->
            <!--</div>-->
            <!--</div>-->
        </div>

        <!-- direction 2 -->
        <div id="slider-direction-2" class="slider-direction slider-two">
            <!--<div class="container">-->
            <!--<div class="row">-->
            <!--<div class="col-md-12 col-sm-12 col-xs-12">-->
            <!--<div class="slider-content text-center">-->
            <!--&lt;!&ndash; layer 1 &ndash;&gt;-->
            <!--<div class="layer-1-1 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">-->
            <!--<h2 class="title1">The Best Business Information </h2>-->
            <!--</div>-->
            <!--&lt;!&ndash; layer 2 &ndash;&gt;-->
            <!--<div class="layer-1-2 wow slideInUp" data-wow-duration="2s" data-wow-delay=".1s">-->
            <!--<h1 class="title2">We're In The Business Of Get Quality Business Service</h1>-->
            <!--</div>-->
            <!--&lt;!&ndash; layer 3 &ndash;&gt;-->
            <!--<div class="layer-1-3 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">-->
            <!--<a class="ready-btn right-btn page-scroll" href="#services">See Services</a>-->
            <!--<a class="ready-btn page-scroll" href="#about">Learn More</a>-->
            <!--</div>-->
            <!--</div>-->
            <!--</div>-->
            <!--</div>-->
            <!--</div>-->
        </div>

        <!-- direction 3 -->
        <div id="slider-direction-3" class="slider-direction slider-two">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="slider-content">
                            <!-- layer 1 -->
                            <div class="layer-1-1 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">
                                <h2 class="title1"></h2>
                            </div>
                            <!-- layer 2 -->
                            <div class="layer-1-2 wow slideInUp" data-wow-duration="2s" data-wow-delay=".1s">
                                <h1 class="title2"></h1>
                            </div>
                            <!-- layer 3 -->
                            <!--<div class="layer-1-3 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">
                              <a class="ready-btn right-btn page-scroll" href="#services">See Services</a>
                              <a class="ready-btn page-scroll" href="#about">Learn More</a>
                            </div>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- direction 4 -->
<div id="slider-direction-4" class="slider-direction slider-two">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="slider-content">
                    <!-- layer 1 -->
                    <!--<div class="layer-1-1 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">-->
                    <!--    <h2 class="title1">The Best business Information </h2>-->
                    <!--</div>-->
                    <!-- layer 2 -->
                    <!--<div class="layer-1-2 wow slideInUp" data-wow-duration="2s" data-wow-delay=".1s">-->
                    <!--    <h1 class="title2">Helping Business Security & Peace of Mind for Your Family</h1>-->
                    <!--</div>-->
                    <!-- layer 3 -->
                    <!--<div class="layer-1-3 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">-->
                    <!--    <a class="ready-btn right-btn page-scroll" href="#services">See Services</a>-->
                    <!--    <a class="ready-btn page-scroll" href="#about">Learn More</a>-->
                    <!--</div>-->
                </div>
            </div>
        </div>
    </div>
</div>

<!-- End Slider Area -->

<!-- Start About area -->
<div id="about" class="about-area area-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h2>О нас</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <!-- single-well start-->
            <div class="col-md-6 col-sm-6 col-xs-12" id="aboutScrollLeft">
                <div class="well-left">
                    <div class="single-well">
                        <a href="#">
                            <img src="img/about/web-manjeri1-min.jpg" alt="WEB MANJERI">
                        </a>
                    </div>
                </div>
            </div>
            <!-- single-well end-->
            <div class="col-md-6 col-sm-6 col-xs-12" id="aboutScrollRigth">
                <div class="well-middle">
                    <div class="single-well">
                        <a href="#">
                            <h4 class="sec-head"><?php echo app('translator')->getFromJson('global.Project_maintenance'); ?></h4>
                        </a>
                        <!--<p>-->
                        <!--  Верстка web-проектов используя технологий HTML5 / CSS3 + JavaScript,-->
                        <!--</p>-->

                        <ul>
                            <li>
                                <i class="fa fa-check"></i>
                                <?php echo app('translator')->getFromJson('global.Proj'); ?>
                            </li>
                            <li>
                                <i class="fa fa-check"></i>
                                <?php echo app('translator')->getFromJson('global.Proj1'); ?>
                            </li>
                            <li>
                                <i class="fa fa-check"></i>
                                <?php echo app('translator')->getFromJson('global.Proj2'); ?>
                            </li>
                            <li>
                                <i class="fa fa-check"></i>
                                <?php echo app('translator')->getFromJson('global.Proj3'); ?>
                            </li>
                            <li>
                                <i class="fa fa-check"></i>
                                <?php echo app('translator')->getFromJson('global.Proj4'); ?>
                            </li>
                            <li>
                                <i class="fa fa-check"></i>
                                <?php echo app('translator')->getFromJson('global.Proj5'); ?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- End col-->
        </div>
    </div>
</div>
<!-- End About area -->

<!-- Start Service area -->
<div id="services" class="services-area area-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline services-head text-center">
                    <h2><?php echo app('translator')->getFromJson('global.Our_services'); ?></h2>
                </div>
            </div>
        </div>
        <div class="row text-center" id="servicesScrollLeft">
            <div class="services-contents">
                <!-- Start Left services -->
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="about-move">
                        <div class="services-details">
                            <div class="single-services">
                                <h4><?php echo app('translator')->getFromJson('global.Web_services'); ?></h4>
                                <p><?php echo app('translator')->getFromJson('global.Web_dev'); ?></p>
                                <p><?php echo app('translator')->getFromJson('global.Web_design'); ?></p>
                                <p><?php echo app('translator')->getFromJson('global.Banner_creation'); ?></p>
                                <p><?php echo app('translator')->getFromJson('global.Technical_audit'); ?></p>
                                <p><?php echo app('translator')->getFromJson('global.Site_service'); ?></p>
                            </div>
                        </div>
                        <!-- end about-details -->
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="about-move">
                        <div class="services-details">
                            <div class="single-services">
                                <h4><?php echo app('translator')->getFromJson('global.SEO_optimization'); ?></h4>
                                <p><?php echo app('translator')->getFromJson('global.Key_words'); ?></p>
                                <p><?php echo app('translator')->getFromJson('global.Semantic_core'); ?></p>
                                <p><?php echo app('translator')->getFromJson('global.Internal_optimization'); ?></p>
                                <p><?php echo app('translator')->getFromJson('global.External_optimization'); ?></p>
                            </div>
                        </div>
                        <!-- end about-details -->
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <!-- end col-md-4 -->
                    <div class=" about-move">
                        <div class="services-details">
                            <div class="single-services">
                                <h4><?php echo app('translator')->getFromJson('global.Internet_marketing'); ?></h4>
                                <p><?php echo app('translator')->getFromJson('global.Social_media_marketing'); ?></p>
                                <p><?php echo app('translator')->getFromJson('global.Marketing_analysis'); ?></p>
                                <p><?php echo app('translator')->getFromJson('global.Internet_advertising'); ?></p>
                            </div>
                        </div>
                        <!-- end about-details -->
                    </div>
                </div>
                <!-- end col-md-4 -->
            </div>
        </div>
        <div class="row text-center" id="servicesScrollRight">
            <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="about-move">
                    <div class="services-details">
                        <div class="single-services">
                            <h4><?php echo app('translator')->getFromJson('global.Time_monitoring'); ?></h4>
                            <p><?php echo app('translator')->getFromJson('global.Host_server'); ?></p>
                            <p><?php echo app('translator')->getFromJson('global.Site_recovery'); ?></p>
                            <p><?php echo app('translator')->getFromJson('global.Domain_registration'); ?></p>
                        </div>
                    </div>
                    <!-- end about-details -->
                </div>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="about-move">
                    <div class="services-details">
                        <div class="single-services">
                            <h4><?php echo app('translator')->getFromJson('global.Social_media_marketing'); ?></h4>
                            <span><i class="fa fa-facebook"></i></span>
                            <span><i class="fa fa-instagram"></i></span>
                            <span><i class="fa fa-linkedin"></i></span>
                            <span><i class="fa fa-youtube"></i></span>
                            <span><i class="fa fa-vk"></i></span>
                        </div>
                    </div>
                    <!-- end about-details -->
                </div>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="about-move">
                    <div class="services-details">
                        <div class="single-services">
                            <h4><a href="#"><?php echo app('translator')->getFromJson('global.IOS_Android'); ?></a></h4>
                            <a href="https://play.google.com/store/apps/details?id=com.birthright" target="_blank"><i class="fa fa-arrow-right" aria-hidden="true"></i>Birthright Connect </a><br>
                            <a href="https://play.google.com/store/apps/details?id=com.hikearmenia" target="_blank"><i class="fa fa-arrow-right" aria-hidden="true"></i>HIKEArmenia</a><br>
                            <a href="https://play.google.com/store/apps/details?id=com.learnbat.showme" target="_blank"><i class="fa fa-arrow-right" aria-hidden="true"></i>ShowMe Interactive Whiteboard</a>
                        </div>
                    </div>
                    <!-- end about-details -->
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Service area -->

<!-- our-skill-area start -->
<div class="our-skill-area fix hidden-sm">
    <div class="test-overly"></div>
        <div class="container">
            <div class="col-xs-6 col-sm-6 col-md-3 about_info">
                <div class="about_item " >
                    <div class="about_radius">
                        <?php echo app('translator')->getFromJson('global.From_days'); ?>
                    </div>
                    <h4><?php echo app('translator')->getFromJson('global.Project_creation'); ?></h4>
                </div>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-3 about_info">
                <div class="about_item " >
                    <div class="about_radius">
                        30%
                    </div>
                    <h4><?php echo app('translator')->getFromJson('global.Prepayment'); ?></h4>
                </div>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-3 about_info">
                <div class="about_item " >
                    <div class="about_radius">
                        <?php echo app('translator')->getFromJson('global.Over_projects'); ?>
                    </div>
                    <h4><?php echo app('translator')->getFromJson('global.Performed'); ?></h4>
                </div>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-3 about_info">
                <div class="about_item " >
                    <div class="about_radius">
                        24/7
                    </div>
                    <h4><?php echo app('translator')->getFromJson('global.Technical_support'); ?></h4>
                </div>
            </div>
        </div>
</div>
<!-- our-skill-area end -->

<!-- Start team Area -->
<div id="team" class="our-team-area area-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h2><?php echo app('translator')->getFromJson('global.Special_team'); ?></h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="team-top clearfix swiper-container">
                <div class="swiper-wrapper swiper_items">
                    <div class="swiper-slide team_item">
                        <div class="single-team-member">
                            <div class="team-img">
                                <a href="#">
                                    <img src="img/team/1.jpg" alt="TEAM">
                                </a>
                                <div class="team-social-icon text-center">
                                    <ul>
                                        <li>
                                            <a href="https://www.facebook.com/arshbabayan" target="_blank">
                                                <i class="fa fa-facebook"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="https://vk.com/id307266562" target="_blank">
                                                <i class="fa fa-vk"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="https://www.instagram.com/arshak_babayan91/?hl=ru" target="_blank">
                                                <i class="fa fa-instagram"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#" target="_blank">
                                                <i class="fa fa-linkedin"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="team-content text-center">
                                <h4><?php echo app('translator')->getFromJson('global.Arshak'); ?></h4>
                                <p><?php echo app('translator')->getFromJson('global.Arshak_pos'); ?></p>
                                <div class="team_description"><?php echo app('translator')->getFromJson('global.Arshak_desc'); ?></div>
                            </div>
                        </div>
                    </div>
                    <!-- End column -->
                    <div class="swiper-slide team_item">
                        <div class="single-team-member">
                            <div class="team-img">
                                <a href="#">
                                    <img src="img/team/3.jpg" alt="">
                                </a>
                                <div class="team-social-icon text-center">
                                    <ul>
                                        <li>
                                            <a href="https://www.facebook.com/vahagn.tadevosyan.71" target="_blank">
                                                <i class="fa fa-facebook"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#" target="_blank">
                                                <i class="fa fa-vk"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#" target="_blank">
                                                <i class="fa fa-instagram"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#" target="_blank">
                                                <i class="fa fa-linkedin"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="team-content text-center">
                                <h4><?php echo app('translator')->getFromJson('global.Vahag'); ?></h4>
                                <p><?php echo app('translator')->getFromJson('global.Vahag_pos'); ?></p>
                                <div class="team_description"><?php echo app('translator')->getFromJson('global.Vahag_desc'); ?></div>
                            </div>
                        </div>
                    </div>
                    <!-- End column -->
                    <div class="swiper-slide team_item">
                        <div class="single-team-member">
                            <div class="team-img">
                                <a href="#">
                                    <img src="img/team/2.jpg" alt="">
                                </a>
                                <div class="team-social-icon text-center">
                                    <ul>
                                        <li>
                                            <a href="https://www.facebook.com/violetta.urazaeva" target="_blank">
                                                <i class="fa fa-facebook"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="https://vk.com/eweretti" target="_blank">
                                                <i class="fa fa-vk"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#" target="_blank">
                                                <i class="fa fa-instagram"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="team-content text-center">
                                <h4><?php echo app('translator')->getFromJson('global.Violetta'); ?></h4>
                                <p><?php echo app('translator')->getFromJson('global.Violetta_pos'); ?></p>
                                <div class="team_description"><?php echo app('translator')->getFromJson('global.Violetta_desc'); ?></div>
                            </div>
                        </div>
                    </div>
                    <!-- End column -->
                    <div class="swiper-slide team_item">
                    <div class="single-team-member">
                        <div class="team-img">
                            <a href="#">
                                <img src="img/team/5.jpg" alt="">
                            </a>
                            <div class="team-social-icon text-center">
                                <ul>
                                    <li>
                                        <a href="https://www.facebook.com/may.movsisyan" target="_blank">
                                            <i class="fa fa-facebook"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" target="_blank">
                                            <i class="fa fa-vk"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.instagram.com/may_movsisyan/?hl=ru" target="_blank">
                                            <i class="fa fa-instagram"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="team-content text-center">
                            <h4><?php echo app('translator')->getFromJson('global.Mariam'); ?></h4>
                            <p><?php echo app('translator')->getFromJson('global.Mariam_pos'); ?></p>
                            <div class="team_description"><?php echo app('translator')->getFromJson('global.Mariam_desc'); ?></div>
                        </div>
                    </div>
                </div>
                <!-- End column -->
                </div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    </div>
</div>
<!-- End Team Area -->


<!-- <div class="container">-->
<!--        <div class="row">-->
<!--            <div class="col-md-12 col-sm-12 col-xs-12">-->
<!--                <div class="section-headline text-center">-->
<!--                    <h2>Квалификация</h2>-->
<!--                </div>-->
<!--            </div>-->
<!--       </div>-->
<!--       <div class="card-deck row m-auto">-->
<!--          <div class="card col-lg-4">-->
<!--            <img class="card-img-top" src="img/diplom/Arshak_diplom.jpg" alt="Card image cap">-->
<!--            <div class="card-body">-->
<!--              <h5 class="card-title">Аршак Бабаян</h5>-->
<!--              <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>-->
<!--            </div>-->
<!--          </div>-->
<!--          <div class="card col-lg-4">-->
<!--            <img class="card-img-top" src="img/diplom/Arshak_diplom.jpg" alt="Card image cap">-->
<!--            <div class="card-body">-->
<!--              <h5 class="card-title">Card title</h5>-->
<!--              <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>-->
<!--            </div>-->
<!--          </div>-->
<!--          <div class="card col-lg-4">-->
<!--            <img class="card-img-top" src="img/diplom/Arshak_diplom.jpg" alt="Card image cap">-->
<!--            <div class="card-body">-->
<!--              <h5 class="card-title">Card title</h5>-->
<!--              <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content.</p>-->
<!--            </div>-->
<!--          </div>-->
<!--        </div>-->
<!--</div>-->



<!-- Start portfolio Area -->
<div id="portfolio" class="portfolio-area area-padding fix">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h2><?php echo app('translator')->getFromJson('global.Our_portfolio'); ?></h2>
                </div>
            </div>
        </div>
        <div class="row">
            <!-- Start Portfolio -page -->
            <div class="awesome-project-1 fix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="awesome-menu ">
                        <ul class="project-menu">
                            <li>
                                <a href="#" class="active" data-filter="*"><?php echo app('translator')->getFromJson('global.All'); ?></a>
                            </li>
                            <li>
                                <a href="#" data-filter=".development"><?php echo app('translator')->getFromJson('global.Development'); ?></a>
                            </li>
                            <li>
                                <a href="#" data-filter=".design"><?php echo app('translator')->getFromJson('global.Design'); ?></a>
                            </li>
                            <li>
                                <a href="#" data-filter=".photo"><?php echo app('translator')->getFromJson('global.Photoshop'); ?></a>
                            </li>
                            <li>
                                <a href="#" data-filter=".seo"><?php echo app('translator')->getFromJson('global.SEO'); ?></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="awesome-project-content">
                <!-- single-awesome-project start -->
                <div class="col-md-4 col-sm-4 col-xs-12 seo development">
                    <div class="single-awesome-project">
                        <div class="awesome-img">
                            <a href="#"><img src="img/portfolio/syshevskiydvor-min-min.jpg" alt="SYSHEVSKIDVOR"
                                             height="600"/></a>
                            <div class="add-actions text-center">
                                <div class="project-dec">
                                    <!--<a class="venobox" data-gall="Syshevskiydvor" href="img/portfolio/syshevskiydvor.png">-->
                                    <!--  <h4>Сущевский двор</h4>-->
                                    <!--</a>-->
                                    <a class="" data-gall="Syshevskiydvor" href="http://syshevskiydvor.ru/"
                                       target="_blank">
                                        <h4>Сущевский двор</h4>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- single-awesome-project end -->
                <!-- single-awesome-project start -->
                <div class="col-md-4 col-sm-4 col-xs-12 photo">
                    <div class="single-awesome-project">
                        <div class="awesome-img">
                            <a href="#"><img src="img/portfolio/screencapture-min-min.jpg" alt="" height="600"/></a>
                            <div class="add-actions text-center">
                                <div class="project-dec">
                                    <a class="venobox" data-gall="myGallery" href="img/portfolio/screencapture-min-min.jpg">
                                        <h4>Car Rental In Germany</h4>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- single-awesome-project end -->
                <!-- single-awesome-project start -->
                <!--<div class="col-md-4 col-sm-4 col-xs-12 design">-->
                <!--  <div class="single-awesome-project">-->
                <!--    <div class="awesome-img">-->
                <!--      <a href="#"><img src="img/portfolio/evakuator.png" alt="" /></a>-->
                <!--      <div class="add-actions text-center">-->
                <!--        <div class="project-dec">-->
                <!--          <a class="venobox" data-gall="myGallery" href="img/portfolio/evakuator.png">-->
                <!--            <h4>Частный Эвакуатор</h4>-->
                <!--            <span>Web Design</span>-->
                <!--          </a>-->
                <!--        </div>-->
                <!--      </div>-->
                <!--    </div>-->
                <!--  </div>-->
                <!--</div>-->
                <!-- single-awesome-project end -->
                <!-- single-awesome-project start -->
                <!--<div class="col-md-4 col-sm-4 col-xs-12 photo development">-->
                <!--    <div class="single-awesome-project">-->
                <!--        <div class="awesome-img">-->
                <!--            <a href="#"><img src="img/portfolio/enfolink.png" alt=""/></a>-->
                <!--            <div class="add-actions text-center">-->
                <!--                <div class="project-dec">-->
                <!--                    <a class="venobox" data-gall="myGallery" href="img/portfolio/enfolink.png">-->
                <!--                        <h4>Enfolink</h4>-->
                <!--                        <span>Web design</span>-->
                <!--                    </a>-->
                <!--                </div>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <!-- single-awesome-project end -->
                <!-- single-awesome-project start -->
                <!--<div class="col-md-4 col-sm-4 col-xs-12 development">-->
                <!--    <div class="single-awesome-project">-->
                <!--        <div class="awesome-img">-->
                <!--            <a href="#"><img src="img/portfolio/cryptoversal.png" alt=""/></a>-->
                <!--            <div class="add-actions text-center text-center">-->
                <!--                <div class="project-dec">-->
                <!--                    <a class="venobox" data-gall="myGallery" href="img/portfolio/cryptoversal.png">-->
                <!--                        <h4>Cryptoversal</h4>-->
                <!--                        <span>Web Development</span>-->
                <!--                    </a>-->
                <!--                </div>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <!-- single-awesome-project end -->
                <!-- single-awesome-project start -->
                <div class="col-md-4 col-sm-4 col-xs-12 design photo">
                    <div class="single-awesome-project">
                        <div class="awesome-img">
                            <a href="#"><img src="img/portfolio/ideal-min-min.jpg" alt=""/></a>
                            <div class="add-actions text-center">
                                <div class="project-dec">
                                    <a class="venobox" data-gall="myGallery" href="http://idealtrotuar.ru/">
                                        <h4>Идеал Tротуар</h4>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- single-awesome-project end -->
                <!-- single-awesome-project start -->
                <div class="col-md-4 col-sm-4 col-xs-12 design photo">
                    <div class="single-awesome-project">
                        <div class="awesome-img">
                            <a href="#"><img src="img/portfolio/anau-min-min.jpg" alt=""/></a>
                            <div class="add-actions text-center">
                                <div class="project-dec">
                                    <!--<a class="venobox" data-gall="myGallery" href="img/portfolio/anau.png">-->
                                    <!--  <h4>ANAU</h4>-->
                                    <!--  <span>Photoshop</span>-->
                                    <!--</a>-->
                                    <a class="" data-gall="myGallery" href="http://anau.am/" target="_blank">
                                        <h4>ANAU</h4>
                                        <span>Photoshop</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- single-awesome-project end -->
                <!-- single-awesome-project start -->
                <div class="col-md-4 col-sm-4 col-xs-12 design photo">
                    <div class="single-awesome-project">
                        <div class="awesome-img">
                            <a href="#"><img src="img/portfolio/lesbijoux-min-min.jpg" alt=""/></a>
                            <div class="add-actions text-center">
                                <div class="project-dec">
                                    <!--<a class="venobox" data-gall="myGallery" href="img/portfolio/lesbijoux.png">-->
                                    <!--  <h4>Les Bijoux</h4>-->
                                    <!--  <span>Photoshop</span>-->
                                    <!--</a>-->
                                    <a class="" data-gall="myGallery" href="http://lesbijoux.ru/" target="_blank">
                                        <h4>Les Bijoux</h4>
                                        <span>Photoshop</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12 design photo">
                    <div class="single-awesome-project">
                        <div class="awesome-img">
                            <a href="#"><img src="img/portfolio/tntesakan-min.jpg" alt=""/></a>
                            <div class="add-actions text-center">
                                <div class="project-dec">
                                    <a class="" data-gall="myGallery" href="http://tntesakan.am/" target="_blank">
                                        <h4>Tntesakan</h4>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12 design photo">
                    <div class="single-awesome-project">
                        <div class="awesome-img">
                            <a href="#"><img src="img/portfolio/tata.jpg" alt=""/></a>
                            <div class="add-actions text-center">
                                <div class="project-dec">
                                    <a class="" data-gall="myGallery" href="http://tata-parikmakherski.ru/?fbclid=IwAR3_tpKjz3kJQMODd-PW8DA8Sh7bGh7LXkcZE-yxfU-ZEo7M2asbdxm-PdE" target="_blank">
                                        <h4>tata-parikmakherski</h4>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- single-awesome-project end -->
                 <!-- single-awesome-project start -->
                <div class="col-md-4 col-sm-4 col-xs-12 design photo">
                    <div class="single-awesome-project">
                        <div class="awesome-img">
                            <a href="#"><img src="img/portfolio/screen-apc-personal.jpg" alt="" height="600"/></a>
                            <div class="add-actions text-center">
                                <div class="project-dec">
                                    <!--<a class="venobox" data-gall="Syshevskiydvor" href="img/portfolio/syshevskiydvor.png">-->
                                    <!--  <h4>Сущевский двор</h4>-->
                                    <!--</a>-->
                                    <a class="" data-gall="myGallery" href="http://apc-personal.ru/" target="_blank">
                                        <h4>APC Personal</h4>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- single-awesome-project end -->
            </div>
        </div>
    </div>
</div>

<!-- awesome-portfolio end -->
<!-- start pricing area -->
<!--<div id="pricing" class="pricing-area area-padding">-->
<!--<div class="container">-->
<!--<div class="row">-->
<!--<div class="col-md-12 col-sm-12 col-xs-12">-->
<!--<div class="section-headline text-center">-->
<!--<h2>Pricing Table</h2>-->
<!--</div>-->
<!--</div>-->
<!--</div>-->
<!--<div class="row">-->
<!--<div class="col-md-4 col-sm-4 col-xs-12">-->
<!--<div class="pri_table_list">-->
<!--<h3>basic <br/> <span>$80 / month</span></h3>-->
<!--<ol>-->
<!--<li class="check">Online system</li>-->
<!--<li class="check cross">Full access</li>-->
<!--<li class="check">Free apps</li>-->
<!--<li class="check">Multiple slider</li>-->
<!--<li class="check cross">Free domin</li>-->
<!--<li class="check cross">Support unlimited</li>-->
<!--<li class="check">Payment online</li>-->
<!--<li class="check cross">Cash back</li>-->
<!--</ol>-->
<!--<button>sign up now</button>-->
<!--</div>-->
<!--</div>-->
<!--<div class="col-md-4 col-sm-4 col-xs-12">-->
<!--<div class="pri_table_list active">-->
<!--<span class="saleon">top sale</span>-->
<!--<h3>standard <br/> <span>$110 / month</span></h3>-->
<!--<ol>-->
<!--<li class="check">Online system</li>-->
<!--<li class="check">Full access</li>-->
<!--<li class="check">Free apps</li>-->
<!--<li class="check">Multiple slider</li>-->
<!--<li class="check cross">Free domin</li>-->
<!--<li class="check">Support unlimited</li>-->
<!--<li class="check">Payment online</li>-->
<!--<li class="check cross">Cash back</li>-->
<!--</ol>-->
<!--<button>sign up now</button>-->
<!--</div>-->
<!--</div>-->
<!--<div class="col-md-4 col-sm-4 col-xs-12">-->
<!--<div class="pri_table_list">-->
<!--<h3>premium <br/> <span>$150 / month</span></h3>-->
<!--<ol>-->
<!--<li class="check">Online system</li>-->
<!--<li class="check">Full access</li>-->
<!--<li class="check">Free apps</li>-->
<!--<li class="check">Multiple slider</li>-->
<!--<li class="check">Free domin</li>-->
<!--<li class="check">Support unlimited</li>-->
<!--<li class="check">Payment online</li>-->
<!--<li class="check">Cash back</li>-->
<!--</ol>-->
<!--<button>sign up now</button>-->
<!--</div>-->
<!--</div>-->
<!--</div>-->
<!--</div>-->
<!--</div>-->
<!-- End pricing table area -->
<!-- Start Testimonials -->

<div class="testimonials-area">
    <div class="testi-inner area-padding">
        <div class="testi-overly"></div>
        <div class="container ">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <!-- Start testimonials Start -->
                    <div class="testimonial-content text-center">
                        <!--<a class="quate" href="#"><i class="fa fa-quote-right"></i></a>-->
                        <!-- start testimonial carousel -->
                        <div class="testimonial-carousel">
                            <!-- <div class="single-testi">
                               <div class="testi-text">
                                 <p>
                                   Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed pulvinar luctus est eget congue.<br>consectetur adipiscing elit. Sed pulvinar luctus est eget congue.
                                 </p>
                                 <h6>Boby</h6>
                               </div>
                             </div> -->
                            <!-- End single item -->
                            <!--  <div class="single-testi">
                                <div class="testi-text">
                                  <p>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed pulvinar luctus est eget congue.<br>consectetur adipiscing elit. Sed pulvinar luctus est eget congue.
                                  </p>
                                  <h6>Jhon</h6>
                                </div>
                              </div> -->
                            <!-- End single item -->
                            <!--  <div class="single-testi">
                                <div class="testi-text">
                                  <p>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed pulvinar luctus est eget congue.<br>consectetur adipiscing elit. Sed pulvinar luctus est eget congue.
                                  </p>
                                  <h6>Fleming</h6>
                                </div>
                              </div> -->
                            <!-- End single item -->
                        </div>
                    </div>
                    <!-- End testimonials end -->
                </div>
                <!-- End Right Feature -->
            </div>
        </div>
    </div>
</div>

<!-- End Testimonials -->
<!-- Start Blog Area -->
<!--<div id="blog" class="blog-area">-->
<!--<div class="blog-inner area-padding">-->
<!--<div class="blog-overly"></div>-->
<!--<div class="container ">-->
<!--<div class="row">-->
<!--<div class="col-md-12 col-sm-12 col-xs-12">-->
<!--<div class="section-headline text-center">-->
<!--<h2>Latest News</h2>-->
<!--</div>-->
<!--</div>-->
<!--</div>-->
<!--<div class="row">-->
<!--&lt;!&ndash; Start Left Blog &ndash;&gt;-->
<!--<div class="col-md-4 col-sm-4 col-xs-12">-->
<!--<div class="single-blog">-->
<!--<div class="single-blog-img">-->
<!--<a href="blog.html">-->
<!--<img src="img/blog/1.jpg" alt="">-->
<!--</a>-->
<!--</div>-->
<!--<div class="blog-meta">-->
<!--<span class="comments-type">-->
<!--<i class="fa fa-comment-o"></i>-->
<!--<a href="#">13 comments</a>-->
<!--</span>-->
<!--<span class="date-type">-->
<!--<i class="fa fa-calendar"></i>2016-03-05 / 09:10:16-->
<!--</span>-->
<!--</div>-->
<!--<div class="blog-text">-->
<!--<h4>-->
<!--<a href="blog.html">Assumenda repud eum veniam</a>-->
<!--</h4>-->
<!--<p>-->
<!--Lorem ipsum dolor sit amet conse adipis elit Assumenda repud eum veniam optio modi sit explicabo nisi magnam quibusdam.sit amet conse adipis elit Assumenda repud eum veniam optio modi sit explicabo nisi magnam quibusdam.-->
<!--</p>-->
<!--</div>-->
<!--<span>-->
<!--<a href="blog.html" class="ready-btn">Read more</a>-->
<!--</span>-->
<!--</div>-->
<!--&lt;!&ndash; Start single blog &ndash;&gt;-->
<!--</div>-->
<!--&lt;!&ndash; End Left Blog&ndash;&gt;-->
<!--&lt;!&ndash; Start Left Blog &ndash;&gt;-->
<!--<div class="col-md-4 col-sm-4 col-xs-12">-->
<!--<div class="single-blog">-->
<!--<div class="single-blog-img">-->
<!--<a href="blog.html">-->
<!--<img src="img/blog/2.jpg" alt="">-->
<!--</a>-->
<!--</div>-->
<!--<div class="blog-meta">-->
<!--<span class="comments-type">-->
<!--<i class="fa fa-comment-o"></i>-->
<!--<a href="#">130 comments</a>-->
<!--</span>-->
<!--<span class="date-type">-->
<!--<i class="fa fa-calendar"></i>2016-03-05 / 09:10:16-->
<!--</span>-->
<!--</div>-->
<!--<div class="blog-text">-->
<!--<h4>-->
<!--<a href="blog.html">Explicabo magnam quibusdam.</a>-->
<!--</h4>-->
<!--<p>-->
<!--Lorem ipsum dolor sit amet conse adipis elit Assumenda repud eum veniam optio modi sit explicabo nisi magnam quibusdam.sit amet conse adipis elit Assumenda repud eum veniam optio modi sit explicabo nisi magnam quibusdam.-->
<!--</p>-->
<!--</div>-->
<!--<span>-->
<!--<a href="blog.html" class="ready-btn">Read more</a>-->
<!--</span>-->
<!--</div>-->
<!--&lt;!&ndash; Start single blog &ndash;&gt;-->
<!--</div>-->
<!--&lt;!&ndash; End Left Blog&ndash;&gt;-->
<!--&lt;!&ndash; Start Right Blog&ndash;&gt;-->
<!--<div class="col-md-4 col-sm-4 col-xs-12">-->
<!--<div class="single-blog">-->
<!--<div class="single-blog-img">-->
<!--<a href="blog.html">-->
<!--<img src="img/blog/3.jpg" alt="">-->
<!--</a>-->
<!--</div>-->
<!--<div class="blog-meta">-->
<!--<span class="comments-type">-->
<!--<i class="fa fa-comment-o"></i>-->
<!--<a href="#">10 comments</a>-->
<!--</span>-->
<!--<span class="date-type">-->
<!--<i class="fa fa-calendar"></i>2016-03-05 / 09:10:16-->
<!--</span>-->
<!--</div>-->
<!--<div class="blog-text">-->
<!--<h4>-->
<!--<a href="blog.html">Lorem ipsum dolor sit amet</a>-->
<!--</h4>-->
<!--<p>-->
<!--Lorem ipsum dolor sit amet conse adipis elit Assumenda repud eum veniam optio modi sit explicabo nisi magnam quibusdam.sit amet conse adipis elit Assumenda repud eum veniam optio modi sit explicabo nisi magnam quibusdam.-->
<!--</p>-->
<!--</div>-->
<!--<span>-->
<!--<a href="blog.html" class="ready-btn">Read more</a>-->
<!--</span>-->
<!--</div>-->
<!--</div>-->
<!--&lt;!&ndash; End Right Blog&ndash;&gt;-->
<!--</div>-->
<!--</div>-->
<!--</div>-->
<!--</div>-->
<!-- End Blog -->
<!-- Start Suscrive Area -->
<!--<div class="suscribe-area">-->
<!--<div class="container">-->
<!--<div class="row">-->
<!--<div class="col-lg-12 col-md-12 col-sm-12 col-xs=12">-->
<!--<div class="suscribe-text text-center">-->
<!--<h3>Welcome to our eBusiness company</h3>-->
<!--<a class="sus-btn" href="#">Get A quate</a>-->
<!--</div>-->
<!--</div>-->
<!--</div>-->
<!--</div>-->
<!--</div>-->
<!-- End Suscrive Area -->
<!-- Start contact Area -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>