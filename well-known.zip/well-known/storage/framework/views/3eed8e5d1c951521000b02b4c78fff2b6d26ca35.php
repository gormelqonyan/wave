<?php $__env->startSection('content'); ?>
<div id="portfolio" class="portfolio-area area-padding fix sectionMargin">
    <div class="container">
        <div class="row">
		<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('global.Home'); ?></a>
    </li>
    <li class="breadcrumb-item active"><?php echo app('translator')->getFromJson('global.Portfolio'); ?></li>
</ol>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h2><?php echo app('translator')->getFromJson('global.Our_portfolio'); ?></h2>
                </div>
            </div>
        </div>
        <div class="row">
            <!-- Start Portfolio -page -->
            <div class="awesome-project-1 fix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="awesome-menu ">
                        <ul class="project-menu">
                            <li>
                                <a href="#" class="active" data-filter="*"><?php echo app('translator')->getFromJson('global.All'); ?></a>
                            </li>
                            <li>
                                <a href="#" data-filter=".development"><?php echo app('translator')->getFromJson('global.Development'); ?></a>
                            </li>
                            <li>
                                <a href="#" data-filter=".design"><?php echo app('translator')->getFromJson('global.Design'); ?></a>
                            </li>
                            <li>
                                <a href="#" data-filter=".mobile">Mobile</a>
                            </li>
                            <li>
                                <a href="#" data-filter=".seo">SEO-SMM</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="awesome-project-content">
                <!-- single-awesome-project start -->
                <div class="col-md-4 col-sm-4 col-xs-12 seo development">
                    <div class="single-awesome-project">
                        <div class="awesome-img">
                            <a href="#"><img src="img/portfolio/syshevskiydvor-min-min.jpg" alt="վեբ կայքի պատվեր SYSHEVSKIDVOR"
                                             height="600"/></a>
                            <div class="add-actions text-center">
                                <div class="project-dec">
                                    <!--<a class="venobox" data-gall="Syshevskiydvor" href="img/portfolio/syshevskiydvor.png">-->
                                    <!--  <h4>Сущевский двор</h4>-->
                                    <!--</a>-->
                                    <a class="" data-gall="Syshevskiydvor" href="http://syshevskiydvor.ru/"
                                       target="_blank">
                                        <h4>Сущевский двор</h4>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- single-awesome-project end -->
                <!-- single-awesome-project start -->
                <div class="col-md-4 col-sm-4 col-xs-12 photo">
                    <div class="single-awesome-project">
                        <div class="awesome-img">
                            <a href="#"><img src="img/portfolio/screencapture-min-min.jpg" alt="պատրաստած լոգոներ Car Rental In Germany" height="600"/></a>
                            <div class="add-actions text-center">
                                <div class="project-dec">
                                    <a class="venobox" data-gall="myGallery" href="img/portfolio/screencapture-min-min.jpg">
                                        <h4>Car Rental In Germany</h4>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
               
                <!-- single-awesome-project start -->
                <div class="col-md-4 col-sm-4 col-xs-12 design photo">
                    <div class="single-awesome-project">
                        <div class="awesome-img">
                            <a href="#"><img src="img/portfolio/ideal-min-min.jpg" alt="պատրաստած լոգոներ Идеал Tротуар"/></a>
                            <div class="add-actions text-center">
                                <div class="project-dec">
                                    <a class="venobox" data-gall="myGallery" href="http://idealtrotuar.ru/">
                                        <h4>Идеал Tротуар</h4>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- single-awesome-project end -->
                <!-- single-awesome-project start -->
                <div class="col-md-4 col-sm-4 col-xs-12 design photo">
                    <div class="single-awesome-project">
                        <div class="awesome-img">
                            <a href="#"><img src="img/portfolio/anau-min-min.jpg" alt="պատրաստած լոգոներ ANAU"/></a>
                            <div class="add-actions text-center">
                                <div class="project-dec">
                                    <!--<a class="venobox" data-gall="myGallery" href="img/portfolio/anau.png">-->
                                    <!--  <h4>ANAU</h4>-->
                                    <!--  <span>Photoshop</span>-->
                                    <!--</a>-->
                                    <a class="" data-gall="myGallery" href="http://anau.am/" target="_blank">
                                        <h4>ANAU</h4>
                                        <span>Photoshop</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- single-awesome-project end -->
                <!-- single-awesome-project start -->
                <div class="col-md-4 col-sm-4 col-xs-12 design photo">
                    <div class="single-awesome-project">
                        <div class="awesome-img">
                            <a href="#"><img src="img/portfolio/lesbijoux-min-min.jpg" alt="ֆլեշ բաններներ Les Bijoux"/></a>
                            <div class="add-actions text-center">
                                <div class="project-dec">
                                    <!--<a class="venobox" data-gall="myGallery" href="img/portfolio/lesbijoux.png">-->
                                    <!--  <h4>Les Bijoux</h4>-->
                                    <!--  <span>Photoshop</span>-->
                                    <!--</a>-->
                                    <a class="" data-gall="myGallery" href="http://lesbijoux.ru/" target="_blank">
                                        <h4>Les Bijoux</h4>
                                        <span>Photoshop</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12 design photo">
                    <div class="single-awesome-project">
                        <div class="awesome-img">
                            <a href="#"><img src="img/portfolio/tntesakan-min.jpg" alt="ֆլեշ բաններներ Tntesakan"/></a>
                            <div class="add-actions text-center">
                                <div class="project-dec">
                                    <a class="" data-gall="myGallery" href="http://tntesakan.am/" target="_blank">
                                        <h4>Tntesakan</h4>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12 design photo">
                    <div class="single-awesome-project">
                        <div class="awesome-img">
                            <a href="#"><img src="img/portfolio/tata.jpg" alt="ֆլեշ բաններներ tata-parikmakherski"/></a>
                            <div class="add-actions text-center">
                                <div class="project-dec">
                                    <a class="" data-gall="myGallery" href="http://tata-parikmakherski.ru/?fbclid=IwAR3_tpKjz3kJQMODd-PW8DA8Sh7bGh7LXkcZE-yxfU-ZEo7M2asbdxm-PdE" target="_blank">
                                        <h4>tata-parikmakherski</h4>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- single-awesome-project end -->
                 <!-- single-awesome-project start -->
                <div class="col-md-4 col-sm-4 col-xs-12 design photo">
                    <div class="single-awesome-project">
                        <div class="awesome-img">
                            <a href="#"><img src="img/portfolio/siongroup.png" alt="պատրաստած կայքեր APC Personal" height="600"/></a>
                            <div class="add-actions text-center">
                                <div class="project-dec">
                                    <!--<a class="venobox" data-gall="Syshevskiydvor" href="img/portfolio/syshevskiydvor.png">-->
                                    <!--  <h4>Сущевский двор</h4>-->
                                    <!--</a>-->
                                    <a class="" data-gall="myGallery" href="https://siongroup.am" target="_blank">
                                        <h4>Sion Group</h4>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- single-awesome-project end -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portbase', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>