var red = [0,0,0];
var orange = [0,0,0];
var green = [0,0,0];
var blue = [40,100,60];
var purple = [40,100,60];
var color = [red,orange,green,blue,purple,red]
var beeoncode = "WAVE IT";
drawName(beeoncode,color);
// bubbleShape= "square";
bounceBubbles();
