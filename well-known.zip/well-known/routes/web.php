<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'IndexController@index')->name('index');
Route::get('/logoneri-patrastum', 'IndexController@logo')->name('logo');
Route::get('/ayceqarteri-patrastum', 'IndexController@card')->name('card');
Route::get('/web-kayqer-yev-logoner', 'IndexController@portfolio')->name('portfolio');
Route::get('/web-kayqeri-patrastum', 'IndexController@about')->name('about');
Route::get('/web-kayqeri-spasarkum', 'IndexController@team')->name('team');
Route::get('/order', 'IndexController@order')->name('order');
Route::get('/javascript-dasyntacner', 'IndexController@js')->name('js');
Route::get('/web-dasyntacner', 'IndexController@web')->name('web');
Route::get('/html-dasyntacner', 'IndexController@html')->name('html');
Route::get('/php-dasyntacner', 'IndexController@php')->name('php');
Route::get('/oop', 'IndexController@oop')->name('oop');
Route::get('/bnakarani-3d-design', 'IndexController@design')->name('design');
Route::get('/flesh-banneri-patrastum', 'IndexController@banners')->name('banners');


Route::get('getip', function () {
	$ip = \Request::ip();
    $data = \Location::get($ip);
    // dd($data->countryCode);
});


Route::get('language/{locale}', function ($locale) {

    // dd($locale);

    Session::put('locale', $locale);
    // dd(Session::get('locale'));
    return redirect()->back();

    //
})->name('lanuage');

Route::get('/ba', function () {
    return view('ba');
});

Auth::routes();

Route::group(['prefix'=>'admin'], function() {
    Route::get('/', 'HomeController@index')->name('home');
    Route::resource('contact', 'ContactController');
    Route::put('contact', 'ContactController@rem')->name('rem');
    Route::get('rem_contacts', 'ContactController@rem_contacts')->name('rem_contacts');
    Route::resource('order', 'OrderController');

});


Route::post('mail/send', 'OrderMailController@send')->name('order_mail_post');
